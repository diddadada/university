package com.example.demo.mapper;
import com.example.demo.entity.Reader;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;
import java.util.List;

@Mapper   //映射器接口,因为Spring BOOT项目已经没有配置文件了
@Repository  //组件注解
public interface ReaderMapper {
	@Select("select * from reader where rdID=#{un} and rdPwd=#{pwd} ")
		/* 根据id和密码2个参数查找时，参数必须在接口方法定义里注解 根据用户名和密码查找用户*/
	Reader getReaderByrdIDAndrdPwd(@Param("un") int un, @Param("pwd") String pwd);

	@Select("select * from reader where rdID=#{un}")
		/* 根据id查找时，参数必须在接口方法定义里注解 根据用户名查找用户*/
	Reader getReaderByrdID(@Param("un") int un);

	@Select("select * from reader where rdStatus=1")
		/* 查找所有有效用户 */
	List<Reader> getAllReaders();

	@Select("select * from reader where rdStatus=1 or rdStatus=2")
		/* 查找所有有效或者挂失用户 */
	List<Reader> getAllgjReaders();

	@Update("update reader set rdType=#{rdType},rdName=#{rdName},rdSex=#{rdSex},rdDept=#{rdDept},rdPhone=#{rdPhone},rdEmail=#{rdEmail},rdDateReg=#{rdDateReg},rdPhoto=#{rdPhoto},rdStatus=#{rdStatus},rdBorrowQty=#{rdBorrowQty},rdPwd=#{rdPwd},rdAdminRoles=#{rdAdminRoles} where rdID=#{rdID}")
		//修改用户
	int updateReader(Reader reader);

	@Insert("insert reader(rdName,rdSex,rdDept,rdPhone,rdEmail,rdPhoto,rdDateReg) values(#{rdName},#{rdSex},#{rdDept},#{rdPhone},#{rdEmail},#{rdPhoto},#{rdDateReg})")
	int addReader(Reader reader);

	@Delete("delete from reader where rdID=#{rdID}")
		//删除用户
	int deleteReader(int rdID);
}
