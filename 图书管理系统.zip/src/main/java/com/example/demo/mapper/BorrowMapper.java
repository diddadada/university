package com.example.demo.mapper;
import com.example.demo.entity.Borrow;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;
import java.util.List;

@Mapper
@Repository
public interface BorrowMapper {

    @Insert("insert borrow(rdID,bkID,ldDateOut,ldDateRetPlan,OperatorBorrow) values(#{rdID},#{bkID},#{ldDateOut},#{ldDateRetPlan},#{OperatorBorrow})")
    int addBorrow(Borrow borrow);

    @Select("select * from borrow where lsHasReturn=0")
    List<Borrow> getAllBorrows();

    @Select("select * from borrow where BorrowID=#{BorrowID}")
        /* 根据id查找时，参数必须在接口方法定义里注解 根据用户名查找用户*/
    Borrow getBorrowByBorrowID(@Param("BorrowID") int BorrowID);

    @Update("update borrow set ldDateRetPlan=#{ldDateRetPlan},ldContinueTimes=#{ldContinueTimes},ldDateRetAct=#{ldDateRetAct} ,lsHasReturn=#{lsHasReturn},OperatorReturn=#{OperatorReturn}where borrowID=#{borrowID}")
    int updateBorrow(Borrow borrow);

    @Delete("delete from borrow where BorrowID=#{BorrowID}")
        //删除
    int deleteBorrow(int BorrowID);
}
