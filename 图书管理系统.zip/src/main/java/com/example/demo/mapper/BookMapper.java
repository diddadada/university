package com.example.demo.mapper;
import com.example.demo.entity.Book;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;
import java.util.List;

@Mapper
@Repository  //组件注解
public interface BookMapper {

    @Update("update book set bkCode=#{bkCode},bkName=#{bkName},bkAuthor=#{bkAuthor},bkPress=#{bkPress},bkDatePress=#{bkDatePress},bkISBN=#{bkISBN},bkCatalog=#{bkCatalog},bkLanguage=#{bkLanguage},bkPages=#{bkPages},bkPrice=#{bkPrice},bkDateIn=#{bkDateIn},bkBrief=#{bkBrief},bkCover=#{bkCover} ,bkStatus=#{bkStatus}where bkID=#{bkID}")
        //修改
    int updateBook(Book book);

    @Insert("insert book(bkCode,bkName,bkAuthor,bkPress,bkDatePress,bkISBN,bkCatalog,bkLanguage,bkPages,bkPrice,bkDateIn,bkBrief,bkCover) values(#{bkCode},#{bkName},#{bkAuthor},#{bkPress},#{bkDatePress},#{bkISBN},#{bkCatalog},#{bkLanguage},#{bkPages},#{bkPrice},#{bkDateIn},#{bkBrief},#{bkCover})")
    int addBook(Book book);

    @Select("select * from book ")
    List<Book> getAllBooks();

    @Select("select * from book where bkID=#{bkID}")
    Book getBookBybkID(@Param("bkID") int bkID);
}
