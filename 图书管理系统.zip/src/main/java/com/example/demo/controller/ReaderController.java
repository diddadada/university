package com.example.demo.controller;
import com.example.demo.entity.Reader;
import com.example.demo.service.ReaderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.List;

@Controller
@RequestMapping("/reader")
public class ReaderController {
	@Autowired
	private ReaderService readerService;  //注入服务层对象

	@RequestMapping("/rLogin")
	public String toLogin() {
		//页面登录控制器
		System.out.println("准备进入登录表单页面...");
		return "reader/Login";
	}

	@RequestMapping("/login")
	public String login(int rdID, String rdPwd, HttpSession session, Model model) {
		//下面的方法参数rdID和rdPwd是表单元素名，即属性驱动——http请求传参（post和get方式相同）
		System.out.println("rdID=" + rdID + "" + "   rdPwd=" + rdPwd);  //测试接收表单数据
		Reader reader = readerService.queryReaderByrdIDAndrdPwd(rdID, rdPwd);//调用服务层方法
		if (reader != null) {  //查找成功创建会话对象
			session.setAttribute("RdName", reader.getRdName()); // 前台用户会话属性设置
			session.setAttribute("RdID", reader.getRdID()); // 前台用户会话属性设置
			session.setAttribute("RdAdminRoles", reader.getRdAdminRoles());//前台区分身份
			System.out.println("前台用户会话 rdID:" + session.getAttribute("RdID"));
			return "reader/center";//转发用户中心
		} else {
			model.addAttribute("cmessage", "提示：用户名或密码错误!");
			return "reader/login";  //转发至消息视图，提示错误并退回主页
		}
	}
	@RequestMapping("/bl")
	public String tobl() {
		return "reader/bl";
	}//借书证办理页面跳转控制
	@RequestMapping("/bll")
	public String bll(Reader reader, Model model) throws Exception {
		if ("".equals(reader.getRdName()) ) { // 防止空提交
			model.addAttribute("rmessage", "姓名不能为空!");
			return "reader/message";
		} else {
				readerService.addReader(reader);
				model.addAttribute("rmessage", "提交成功");
				return "reader/message"; // 转向控制
			}
		}
	@RequestMapping("/bg")
	public String bg(HttpServletRequest request, String rdID,  HttpSession session) throws Exception {
		//借书证信息变更
		System.out.println("管理员会话信息："+ rdID);
		if (rdID!=null) {
			session.setAttribute("rdID",rdID ); // 前台用户会话属性设置
			return "reader/bgg";
		}
		List<Reader> readers =  readerService.getAllReaders();
		request.setAttribute("readerList", readers);
		return "reader/bg";
	}
	@RequestMapping("/bgg")
	public String bgg(HttpServletRequest request, Reader reader, Model model) throws Exception {
		////根据rdID将提交的表单进行修改
		try {
			String rdID = (String) request.getSession().getAttribute("rdID");
			Reader reader1 = readerService.queryReaderByrdID(Integer.parseInt(rdID));
			reader1.setRdName(reader.getRdName());
			reader1.setRdSex(reader.getRdSex());
			reader1.setRdDept(reader.getRdDept());
			reader1.setRdPhone(reader.getRdPhone());
			reader1.setRdEmail(reader.getRdEmail());
			reader1.setRdPhoto(reader.getRdPhoto());
			reader1.setRdDateReg(reader.getRdDateReg());
			System.out.println(reader1);//测试
			readerService.updateReader(reader1);
		} catch (Exception e) {
			e.printStackTrace();
		}
		model.addAttribute("rmessage", "提交成功");
		return "reader/message"; // 转向控制
	}
	@RequestMapping("/gj")
	//借书证挂失与解除
	public String gj(HttpServletRequest request, String rdID, HttpSession session) throws Exception {
		//通过传来的rdID查找数据并修改证件状态达到办理功能
		System.out.println("管理员会话信息："+ rdID);
		if (rdID!=null) {
			Reader reader = readerService.queryReaderByrdID(Integer.parseInt(rdID));
			if(reader.getRdStatus()==1){
				reader.setRdStatus(2);
			}else {
				reader.setRdStatus(1);
			}
			System.out.println(reader);//测试
			readerService.updateReader(reader);
		}
		List<Reader> readers =  readerService.getAllgjReaders();
		request.setAttribute("readerList", readers);
		return "reader/gj";
	}
	@RequestMapping("/zx")
	//借书证注销
	public String zx(HttpServletRequest request, String rdID) throws Exception {
		System.out.println("管理员会话信息："+ rdID);
		if (rdID!=null) {
			Reader reader = readerService.queryReaderByrdID(Integer.parseInt(rdID));
			readerService.deleteReader(reader);
		}
		List<Reader> readers =  readerService.getAllReaders();
		request.setAttribute("readerList", readers);
		return "reader/zx";
	}
	@RequestMapping("/lx")
	//读者类型管理
	public String lx(HttpServletRequest request, String rdID,String rdType) throws Exception {
		//通过传来的rdID查找数据并修改证件状态达到办理功能
		System.out.println("管理员会话信息："+ rdID);
		if (rdID!=null) {
			Reader reader = readerService.queryReaderByrdID(Integer.parseInt(rdID));
			reader.setRdType(Integer.parseInt(rdType));
			System.out.println(reader);//测试
			readerService.updateReader(reader);
		}
		List<Reader> readers =  readerService.getAllReaders();
		request.setAttribute("readerList", readers);
		return "reader/lx";
	}
	@RequestMapping("/qx")
	//用户权限管理
	public String qx(HttpServletRequest request, String rdID,String rdAdminRoles) throws Exception {
		//通过传来的rdID查找数据并修改证件状态达到办理功能
		System.out.println("管理员会话信息："+ rdID);
		if (rdID!=null) {
			Reader reader = readerService.queryReaderByrdID(Integer.parseInt(rdID));
			reader.setRdAdminRoles(Integer.parseInt(rdAdminRoles));
			System.out.println(reader);//测试
			readerService.updateReader(reader);
		}
		List<Reader> readers =  readerService.getAllReaders();
		request.setAttribute("readerList", readers);
		return "reader/qx";
	}
	@RequestMapping("/mm")
	//用户密码修改
	public String mm(HttpServletRequest request) throws Exception {
		List<Reader> readers =  readerService.getAllReaders();
		request.setAttribute("readerList", readers);
		return "reader/mm";
	}
	@RequestMapping("/mmm")
	public String mmm(HttpServletRequest request, String rdID,String rdPwd,Model model) throws Exception {
		//通过传来的rdID查找数据并修改证件状态达到办理功能
		System.out.println("管理员会话信息："+ rdID);
		System.out.println("会话信息："+ rdPwd);
		Reader reader = readerService.queryReaderByrdID(Integer.parseInt(rdID));
		if (reader!=null) {
			reader.setRdPwd(rdPwd);
			System.out.println(reader);//测试
			readerService.updateReader(reader);
		}else {
			model.addAttribute("rmessage", "请输入有效id");
			return "reader/message";
		}
		List<Reader> readers =  readerService.getAllReaders();
		request.setAttribute("readerList", readers);
		return "reader/mm";
	}
}
