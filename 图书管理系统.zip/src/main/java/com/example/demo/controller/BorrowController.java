package com.example.demo.controller;
import com.example.demo.entity.Book;
import com.example.demo.entity.Borrow;
import com.example.demo.entity.Reader;
import com.example.demo.mapper.BookMapper;
import com.example.demo.mapper.ReaderMapper;
import com.example.demo.service.BorrowService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.List;

@Controller
@RequestMapping("/borrow")
public class BorrowController {
	@Autowired
	private BorrowService borrowService;  //注入服务层对象
	@Autowired
	private ReaderMapper readerDao;
	@Autowired
	private BookMapper bookDao;

	@RequestMapping("/js")
	//借书
	public String tojs() {
		return "borrow/js";
	}
	@RequestMapping("/jss")
	public String jss(HttpSession session, Borrow borrow, Model model) throws Exception {
		String un = (String) session.getAttribute("RdName");
		System.out.println(un);//测试
		Book book = bookDao.getBookBybkID(borrow.getBkID());
		Reader reader = readerDao.getReaderByrdID(borrow.getRdID());
		System.out.println(reader);//测试
		System.out.println(book);//测试
		if (book==null ) {
			model.addAttribute("rmessage", "图书序号不存在!");
			return "reader/message";
		} else if (reader==null ) {
			model.addAttribute("rmessage", "读者序号不存在!");
			return "reader/message";
		} else if ("1".equals(book.getBkStatus())) {
			borrow.setOperatorBorrow(un);
			System.out.println(borrow);//测试
			borrowService.addBorrow(borrow);
			book.setBkStatus(String.valueOf(2));
			bookDao.updateBook(book);
			model.addAttribute("rmessage", "添加成功");
			return "reader/message"; // 转向控制
		} else {
		model.addAttribute("rmessage", "图书不在馆");
		return "reader/message"; // 转向控制
	}
}
	@RequestMapping("/xj")
	//续借
	public String xj(HttpServletRequest request) throws Exception {
		List<Borrow> borrows =  borrowService.getAllBorrows();
		request.setAttribute("borrowList", borrows);
		return "borrow/xj";
	}
	@RequestMapping("/xjj")
	public String xjj(HttpServletRequest request,Borrow borrow,Model model) throws Exception {
		//通过传来的rdID查找数据并修改证件状态达到办理功能
		System.out.println("管理员会话信息："+ borrow.getBorrowID());
		System.out.println("会话信息："+ borrow.getLdDateRetPlan());
		Borrow borrow1 = borrowService.queryBorrowByBorrowID(borrow.getBorrowID());
		if (borrow1!=null) {
			borrow1.setLdDateRetPlan(borrow.getLdDateRetPlan());
			borrow1.setLdContinueTimes(borrow.getLdContinueTimes()+1);
			System.out.println(borrow1);//测试
			borrowService.updateBorrow(borrow1);
		}else {
			model.addAttribute("rmessage", "请输入有效借阅号");
			return "reader/message";
		}
		List<Borrow> borrows =  borrowService.getAllBorrows();
		request.setAttribute("borrowList", borrows);
		return "borrow/xj";
	}
	@RequestMapping("/hs")
	//还书
	public String hs(HttpServletRequest request,String borrowID,HttpSession session) throws Exception {
		String un = (String) session.getAttribute("RdName");
		System.out.println(borrowID);//测试
		if (borrowID!=null) {
			Borrow borrow = borrowService.queryBorrowByBorrowID(Integer.parseInt(borrowID));
			Book book = bookDao.getBookBybkID(borrow.getBkID());
			borrow.setOperatorReturn(un);
			System.out.println(borrow);//测试
			borrowService.deleteBorrow(borrow);
			book.setBkStatus(String.valueOf(1));
			bookDao.updateBook(book);
		}
		List<Borrow> borrows =  borrowService.getAllBorrows();
		request.setAttribute("borrowList", borrows);
		return "borrow/hs";
	}
}
