package com.example.demo.controller;
import com.example.demo.entity.Book;
import com.example.demo.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.List;

@Controller
@RequestMapping("/book")
public class BookController {
	@Autowired
	private BookService bookService;  //注入服务层对象

	@RequestMapping("/xs")
	//新书入库
	public String toxs() {
		return "book/xs";
	}
	@RequestMapping("/xsrk")
	public String xsrk(Book book, Model model) throws Exception {
		System.out.println(book);//测试
		if ("".equals(book.getBkLanguage()) ) {
			model.addAttribute("rmessage", "语言不能为空!");
			return "reader/message";
		} else if ("".equals(book.getBkPages()) ) {
			model.addAttribute("rmessage", "书页不能为空!");
			return "reader/message";
		} else {
			bookService.addBook(book);
			model.addAttribute("rmessage", "添加成功");
			return "reader/message"; // 转向控制
		}
	}
	@RequestMapping("/wh")
	//图书信息维护
	public String wh(HttpServletRequest request, String bkID,  HttpSession session) throws Exception {
		//通过传来的rdID查找数据
		System.out.println("管理员会话信息："+ bkID);
		if (bkID!=null) {
			session.setAttribute("bkID",bkID ); // 前台用户会话属性设置
			return "book/whh";
		}
		List<Book> books =  bookService.getAllBooks();
		request.setAttribute("bookList", books);
		return "book/wh";
	}
	@RequestMapping("/whh")
	public String bgg(HttpServletRequest request, Book book, Model model) throws Exception {
		try {
			String bkID = (String) request.getSession().getAttribute("bkID");
			book.setBkID(Integer.parseInt(bkID));
			System.out.println(book);//测试
			bookService.updateBook(book);
		} catch (Exception e) {
			e.printStackTrace();
		}
		model.addAttribute("rmessage", "修改成功");
		return "reader/message"; // 转向控制
	}
}
