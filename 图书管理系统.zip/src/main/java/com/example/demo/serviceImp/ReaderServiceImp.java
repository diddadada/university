package com.example.demo.serviceImp;
import com.example.demo.entity.Reader;
import com.example.demo.mapper.ReaderMapper;
import com.example.demo.service.ReaderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class ReaderServiceImp implements ReaderService {
	@Autowired
	private ReaderMapper readerDao;

	public Reader queryReaderByrdID(int rdID) {
		return readerDao.getReaderByrdID(rdID);
	}

	public Reader queryReaderByrdIDAndrdPwd(int rdID, String rdPwd) {
		return readerDao.getReaderByrdIDAndrdPwd(rdID, rdPwd);
	}

	public void updateReader(Reader reader) {
		readerDao.updateReader(reader);
	}

	@Override
	public List<Reader> getAllReaders() {
		return readerDao.getAllReaders();
	}
	@Override
	public List<Reader> getAllgjReaders() {
		return readerDao.getAllgjReaders();
	}
	@Override
	public void addReader(Reader reader) {
		readerDao.addReader(reader);
	}

	@Override
	public void deleteReader(Reader reader) {
		readerDao.deleteReader(reader.getRdID());
	}
}
