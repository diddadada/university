package com.example.demo.serviceImp;
import com.example.demo.entity.Borrow;
import com.example.demo.mapper.BorrowMapper;
import com.example.demo.service.BorrowService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BorrowServiceImp implements BorrowService {
	@Autowired
	private BorrowMapper borrowDao;

	@Override
	public void addBorrow(Borrow borrow) {
		borrowDao.addBorrow(borrow);
	}

	@Override
	public List<Borrow> getAllBorrows() {
		return borrowDao.getAllBorrows();
	}

	public Borrow queryBorrowByBorrowID(int BorrowID) {
		return borrowDao.getBorrowByBorrowID(BorrowID);
	}

	public void updateBorrow(Borrow borrow) {
		borrowDao.updateBorrow(borrow);
	}

	@Override
	public void deleteBorrow(Borrow borrow) {
		borrowDao.deleteBorrow(borrow.getBorrowID());
	}
}
