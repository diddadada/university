package com.example.demo.serviceImp;
import com.example.demo.entity.Book;
import com.example.demo.mapper.BookMapper;
import com.example.demo.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class BookServiceImp implements BookService {
	@Autowired
	private BookMapper bookDao;

	@Override
	public void addBook(Book book) {
		bookDao.addBook(book);
	}

	public void updateBook(Book book) {
		bookDao.updateBook(book);
	}

	@Override
	public List<Book> getAllBooks() {
		return bookDao.getAllBooks();
	}
}
