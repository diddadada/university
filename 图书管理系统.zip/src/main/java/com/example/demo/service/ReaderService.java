package com.example.demo.service;
import com.example.demo.entity.Reader;
import java.util.List;

public interface ReaderService {

	Reader queryReaderByrdID(int rdID);
//根据id

	Reader queryReaderByrdIDAndrdPwd(int rdID, String rdPwd);
	//根据id和密码
	void updateReader(Reader reader);
//修改
	List<Reader> getAllReaders();

	List<Reader> getAllgjReaders();

	void addReader(Reader reader);
	//添加
	void deleteReader(Reader reader);
//删除
}
