package com.example.demo.service;
import com.example.demo.entity.Book;
import java.util.List;

public interface BookService {

    void addBook(Book book);
    //添加
    List<Book> getAllBooks();

    void updateBook(Book book);
}
