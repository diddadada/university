package com.example.demo.service;
import com.example.demo.entity.Borrow;
import java.util.List;

public interface BorrowService {

    void addBorrow(Borrow borrow);
    //添加

    List<Borrow> getAllBorrows();

    Borrow queryBorrowByBorrowID(int BorrowID);

    void updateBorrow(Borrow borrow);
//修改
void deleteBorrow(Borrow borrow);
//删除
}
