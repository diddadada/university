package com.example.demo.entity;
import lombok.Data;
import org.springframework.stereotype.Repository;

@Repository
@Data
public class Borrow {  //模型层里的实体
    private int borrowID;  //借阅顺序号
    private int rdID;  //读者序号
    private int bkID;     //图书序号
    private int ldContinueTimes;   //续借次数（第一次借时，记为0）
    private String ldDateOut;     //借书日期
    private String ldDateRetPlan;  //应还日期
    private String ldDateRetAct;     //实际还书日期
    private int ldOverDay;   //超期天数，缺省为0
    private String ldOverMoney;     //超期金额（应罚款金额），缺省为0
    private String ldPunishMoney;     //罚款金额，缺省为0
    private String lsHasReturn;  //是否已经还书，缺省为0-未还
    private String OperatorBorrow;     //借书操作员
    private String OperatorReturn;    //还书操作员

    @Override
    public String toString() {
        return "Borrow [borrowID=" + borrowID + ", rdID=" + rdID +
                ",bkID=" + bkID + ", ldContinueTimes=" + ldContinueTimes +
                ",ldDateOut=" + ldDateOut + ", ldDateRetPlan=" + ldDateRetPlan +
                ",ldDateRetAct=" + ldDateRetAct + ", ldOverDay=" + ldOverDay+
                ",ldOverMoney=" + ldOverMoney + ", ldPunishMoney=" + ldPunishMoney+
                ",lsHasReturn=" + lsHasReturn + ", OperatorBorrow=" + OperatorBorrow+
                ",OperatorReturn=" + OperatorReturn+"]";
    }
}
