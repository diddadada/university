package com.example.demo.entity;
import lombok.Data;
import org.springframework.stereotype.Repository;

@Repository
@Data
public class Book {  //模型层里的实体
    private int bkID;  //图书序号
    private String bkCode;  //图书编号或条码号
    private String bkName;     //书名
    private String bkAuthor;   //作者
    private String bkPress;     //出版社
    private String bkDatePress;  //出版日期
    private String bkISBN;     //ISBN书号
    private String bkCatalog;   //分类号（如：TP316-21/123)
    private int bkLanguage;     //语言：0-中文，1-英文，2-日文，3-俄文
    private int bkPages;     //页数
    private String bkPrice;  //价格
    private String bkDateIn;     //入馆日期
    private String bkBrief;    //内容简介
    private String bkCover;       //图书封面照片
    private String bkStatus;      //图书状态：在馆、借出、遗失、变卖、销毁

    @Override
    public String toString() {
        return "Book [bkID=" + bkID + ", bkCode=" + bkCode +
                ",bkName=" + bkName + ", bkAuthor=" + bkAuthor +
                ",bkPress=" + bkPress + ", bkDatePress=" + bkDatePress +
                ",bkISBN=" + bkISBN + ", bkCatalog=" + bkCatalog+
                ",bkLanguage=" + bkLanguage + ", bkPages=" + bkPages+
                ",bkPrice=" + bkPrice + ", bkDateIn=" + bkDateIn+
                ",bkBrief=" + bkBrief + ", bkCover=" + bkCover+
                ",bkStatus=" + bkStatus+"]";
    }
}
