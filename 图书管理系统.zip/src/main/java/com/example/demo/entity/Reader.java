package com.example.demo.entity;
import lombok.Data;
import org.springframework.stereotype.Repository;

@Repository
@Data
public class Reader {  //模型层里的实体
    private int rdID;  //读者编号/借书证号
    private int rdType;  //读者类别
    private String rdName="";     //读者姓名
    private String rdSex;   //性别：男/女
    private String rdDept;     //单位代码/单位名称
    private String rdPhone;  //电话号码
    private String rdEmail;     //电子邮箱
    private String rdDateReg;   //读者登记日期/办证日
    private String rdPhoto;     //读者照片
    private int rdStatus;     //证件状态，3个：有效、挂失、注销
    private int rdBorrowQty;  //已借书数量（缺省值0）
    private String rdPwd;     //读者密码（初值123），可加密存储
    private int rdAdminRoles;    //管理角色：0-读者、1-借书证管理、2-图书管理、4-借阅管理、8-系统管理，可组合

    @Override
    public String toString() {
        return "Book [rdID=" + rdID + ", rdType=" + rdType +
                ",rdName=" + rdName + ", rdSex=" + rdSex +
                ",rdDept=" + rdDept + ", rdPhone=" + rdPhone +
                ",rdEmail=" + rdEmail + ", rdDateReg=" + rdDateReg+
                ",rdPhoto=" + rdPhoto + ", rdStatus=" + rdStatus+
                ",rdBorrowQty=" + rdBorrowQty + ", rdPwd=" + rdPwd+
                ",rdAdminRoles=" + rdAdminRoles+"]";
    }
}
