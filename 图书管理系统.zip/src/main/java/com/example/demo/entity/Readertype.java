package com.example.demo.entity;
import lombok.Data;
import org.springframework.stereotype.Repository;

@Repository
@Data
public class Readertype {  //模型层里的实体
    private int rdType;  //读者类别
    private String rdTypeName;  //读者类别名称
    private int canLendQty;     //可借书数量
    private int canLendDay;   //可借书天数
    private int CanContinueTimes;     //可续借的次数
    private String PunishRate;  //罚款率（元/天)
    private int DateValid;     //证书有效期（年）【非空，0表示永久有效】

    @Override
    public String toString() {
        return "Book [rdType=" + rdType + ", rdTypeName=" + rdTypeName +
                ",canLendQty=" + canLendQty + ", canLendDay=" + canLendDay +
                ",CanContinueTimes=" + CanContinueTimes + ", PunishRate=" + PunishRate +
                ",DateValid=" + DateValid+"]";
    }
}
