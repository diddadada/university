package com.example.demo.mapper;

import com.example.demo.entity.User;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;
import java.util.List;

@Mapper   //映射器接口（Spring BOOT项目可以不写配置文件，即使用默认配置）
@Repository  //组件注解
public interface IUserMapper {

	@Select("select * from user where username=#{un}and k!=0") /* 根据用户名查找 */
	//包含会员和一般管理员
	User getUserByUsername(@Param("un") String un);  //便于扩展（多个参数）

	@Select("select * from user where username=#{un}and k=0") /* 根据用户名查找 */
	//注册未通过
	User getxUserByUsername(@Param("un") String un);  //便于扩展（多个参数）

	@Select("select * from user where username=#{un} and password=#{pwd} and k!=0")
	/* 根据用户名和密码2个参数查找时，参数必须在接口方法定义里注解 根据用户名和密码查找用户（会员和一般管理员）*/
	User getUserByUsernameAndPassword(@Param("un") String un, @Param("pwd") String pwd);

	@Select("select * from user where k!=0")
	/* 查找所有用户 包含会员和一般管理员*/
	List<User> getAllUsers();

	@Select("select * from user where k=1")
	/* 查找所有会员用户 */
	List<User> getAllmUsers();

	@Select("select * from user where k=2")
	/* 查找所有一般管理用户 */
	List<User> getAllnUsers();

	@Select("select * from user where k=0")
	/* 查找所有未审核用户 */
	List<User> getUsers();

	@Insert("insert ignore into user(username,password,age,realname,k,mobile) values(#{username},#{password},#{k},#{age},#{realname},#{mobile})")
	//关键字ignore：忽略主键重复，添加用户
	int addUser(User user);

	@Update("update user set password=#{password},realname=#{realname},mobile=#{mobile},k=#{k},age=#{age} where username=#{username} ")
	//修改用户
	int updateUser(User user);

	@Delete("delete from user where username=#{un}")
	//删除用户
	int deleteUser(String username);
}
