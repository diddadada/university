package com.example.demo.mapper;

import com.example.demo.entity.Note;
import com.example.demo.entity.User;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
@Repository  //组件注解
public interface INoteMapper {
    @Select("select * from note where username=#{un}")
        //根据用户名找到笔记
    Note queryNoteByUsername(String un);

    @Insert("insert ignore into note(username,name,lable,permission,write) values(#{username},#{name},#{lable},#{permission},#{write})")
        //关键字ignore：忽略主键重复，添加用户
    int addNote(Note note);

    @Select("select * from note where username=#{un}")
        /* 查找所有个人笔记 */
    List<Note> getNotes();
}
