package com.example.demo.controller;
/*
 * 控制层控制器，调用服务层
 */

import com.example.demo.entity.Note;
import com.example.demo.entity.User;
import com.example.demo.service.NoteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.List;

@Controller
@RequestMapping("/Note")
public class NoteController {
    @Autowired
    private NoteService noteService;  //注入服务层对象

    @RequestMapping("/rnote")
    public String tomRegisternote( Model model, HttpSession session) {
        String username=(String)session.getAttribute("username"); //获取会话信息
        if ("".equals(username)) { // 防止未登录
            model.addAttribute("message", "未登录!");
            return "public/message";
        }
        return "note/rnote";
    }//注册页面跳转控制
    @RequestMapping("/registernote")
    public String registernote(Note note, HttpSession session) {
        //通过表单创建日志
        String username=(String)session.getAttribute("username"); //获取会话信息
        System.out.println("username=" + username);  //测试
        note.setUsername(username);
        Note notes = noteService.queryNoteByUsername(note.getUsername());
        noteService.addNote(notes);
        return "note/mRegisternote"; // 跳转用户中心
    }
    @RequestMapping("/noteInfo")
    public String memInfo(HttpServletRequest request) throws Exception {
        //查看所有笔记
        List<Note> notes =noteService.getNotes();
        request.setAttribute("userList", notes);
        return "note/noteInfo";
    }
}