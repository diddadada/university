package com.example.demo.service;

import com.example.demo.entity.Note;

import java.util.List;

public interface NoteService {

    Note queryNoteByUsername(String username);
    //根据用户名查找
    void addNote(Note note);

    List<Note> getNotes();
}
