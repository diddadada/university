package com.example.demo.service;

import com.example.demo.entity.User;

public interface UserService {

	User queryUserByUsername(String username);
//根据用户名
	User queryUserByUserNameAndPassword(String username, String password);
//根据用户名和密码
	void addUser(User user);
//添加
	void updateUser(User user);
//修改
	void deleteUser(User user);
//删除
}