package com.example.demo.serviceImp;

import com.example.demo.entity.Note;
import com.example.demo.mapper.INoteMapper;
import com.example.demo.service.NoteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class NoteServiceImp implements NoteService {
	@Autowired
	private INoteMapper noteDao;

	public Note queryNoteByUsername(String username) {
		return noteDao.queryNoteByUsername(username);
	}

	public void addNote(Note note) {
		noteDao.addNote(note);
	}
	public List<Note> getNotes(){
		return noteDao.getNotes();
	}
}
