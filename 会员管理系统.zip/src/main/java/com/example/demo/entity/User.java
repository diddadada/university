package com.example.demo.entity;
import lombok.Data;
import org.springframework.stereotype.Repository;

@Repository
@Data  //需要先安装Lombok插件，然后开启自动注解处理（Enable annotation processing）功能，以便省去属性的getter/settter/toString()等
public class User {  //模型层里的实体
    private String username;  //类属性
    private String password = "";  //设置空串以保证按主键值删除会员时不报对象属性值异常
    private String realname;//真名
    private String mobile;//手机号
    private Integer age;//年龄
    private int k;//身份

    @Override
    public String toString() {
        return "User [username=" + username + ", password=" + password
                + ", realname=" + realname + ", mobile=" + mobile
                + ", age=" + age + ", k=" + k +"]";
    }
}
