package com.example.demo.entity;
import lombok.Data;
import org.springframework.stereotype.Repository;

@Repository
@Data  //安装Lombok插件，然后开启自动注解处理（Enable annotation processing）功能，省去属性的getter/settter/toString()等
public class Note {
    //包装属性
    private String username;//作者名
    private String name;//笔记名
    private String lable;//存放标签
    private String permission;//权限
    private String write;//笔记内容

    @Override
    public String toString() {
        return "Note [username=" + username + ", name=" + name
                + ", lable=" + lable + ", permission=" + permission
                + ", write=" + write + "]";
    }
}

