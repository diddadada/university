package com.molo.molo.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.molo.molo.entity.Admin;
import com.molo.molo.service.AdminService;
import com.molo.molo.mapper.AdminMapper;
import org.springframework.stereotype.Service;

import java.util.UUID;

/**
 * @author Alee
 * @description 针对表【admin】的数据库操作Service实现
 * @createDate 2023-07-20 16:06:23
 */
@Service
public class AdminServiceImpl extends ServiceImpl<AdminMapper, Admin>
        implements AdminService{

    @Override
    public Admin login(String adminAccount, String adminPassword) {
        LambdaQueryWrapper<Admin> wrapper = new LambdaQueryWrapper<>();//构建条件
        wrapper.eq(Admin::getAdminAccount,adminAccount);//管理员账号是否正确
        wrapper.eq(Admin::getAdminPassword,adminPassword);//密码是否正确
        Admin admin = this.getOne(wrapper);//查询
        if (admin!=null){ //账号密码正确
            admin.setAdminPassword(null);//,admin返回浏览器,清空密码,确保安全
        }
        return admin;
    }

}




