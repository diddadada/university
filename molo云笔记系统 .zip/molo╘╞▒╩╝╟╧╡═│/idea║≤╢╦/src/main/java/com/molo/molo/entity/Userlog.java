package com.molo.molo.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import lombok.Data;

/**
 * 
 * @TableName userlog
 */
@TableName(value ="userlog")
@Data
public class Userlog implements Serializable {
    /**
     * 用户日志id
     */
    @TableId(type = IdType.AUTO)
    private Integer userlogId;

    /**
     * 用户id
     */
    private Integer userId;

    /**
     * 日志时间
     */
    private String userlogTime;

    /**
     * 日志详情
     */
    private String userlogDescription;

    @TableField(exist = false)
    private static final long serialVersionUID = 1L;

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        Userlog other = (Userlog) that;
        return (this.getUserlogId() == null ? other.getUserlogId() == null : this.getUserlogId().equals(other.getUserlogId()))
            && (this.getUserId() == null ? other.getUserId() == null : this.getUserId().equals(other.getUserId()))
            && (this.getUserlogTime() == null ? other.getUserlogTime() == null : this.getUserlogTime().equals(other.getUserlogTime()))
            && (this.getUserlogDescription() == null ? other.getUserlogDescription() == null : this.getUserlogDescription().equals(other.getUserlogDescription()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getUserlogId() == null) ? 0 : getUserlogId().hashCode());
        result = prime * result + ((getUserId() == null) ? 0 : getUserId().hashCode());
        result = prime * result + ((getUserlogTime() == null) ? 0 : getUserlogTime().hashCode());
        result = prime * result + ((getUserlogDescription() == null) ? 0 : getUserlogDescription().hashCode());
        return result;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", userlogId=").append(userlogId);
        sb.append(", userId=").append(userId);
        sb.append(", userlogTime=").append(userlogTime);
        sb.append(", userlogDescription=").append(userlogDescription);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}