package com.molo.molo.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class P { //分页对象
    /**
     * 页码
     * 总条数
     */
    private Long pageNum;
    private Long pageSize;

    String token;
    String userName;
    String moloTitle;
    String moloContent;
}
