package com.molo.molo.service;

import com.molo.molo.entity.Mtype;
import com.baomidou.mybatisplus.extension.service.IService;

/**
* @author Alee
* @description 针对表【mtype】的数据库操作Service
* @createDate 2023-07-20 16:06:23
*/
public interface MtypeService extends IService<Mtype> {

}
