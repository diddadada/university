package com.molo.molo.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.molo.molo.entity.Mtype;
import com.molo.molo.service.MtypeService;
import com.molo.molo.mapper.MtypeMapper;
import org.springframework.stereotype.Service;

/**
* @author Alee
* @description 针对表【mtype】的数据库操作Service实现
* @createDate 2023-07-20 16:06:23
*/
@Service
public class MtypeServiceImpl extends ServiceImpl<MtypeMapper, Mtype>
    implements MtypeService{

}




