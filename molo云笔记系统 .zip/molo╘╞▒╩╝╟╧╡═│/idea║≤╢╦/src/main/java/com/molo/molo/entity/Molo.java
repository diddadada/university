package com.molo.molo.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 * @TableName molo
 */
@TableName(value ="molo")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Molo implements Serializable {
    /**
     * molo索引
     */
    @TableId(type = IdType.AUTO)
    private Integer moloId;

    /**
     * molo创建者id
     */
    private Integer moloOwnerId;

    /**
     * molo类型id
     */
    private Integer moloTypeId;

    /**
     * molo标题
     */
    private String moloTitle;

    /**
     * molo内容
     */
    private String moloContent;

    /**
     * star数量
     */
    private Integer moloStarNum;

    @TableField(exist = false)
    private static final long serialVersionUID = 1L;

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        Molo other = (Molo) that;
        return (this.getMoloId() == null ? other.getMoloId() == null : this.getMoloId().equals(other.getMoloId()))
            && (this.getMoloOwnerId() == null ? other.getMoloOwnerId() == null : this.getMoloOwnerId().equals(other.getMoloOwnerId()))
            && (this.getMoloTypeId() == null ? other.getMoloTypeId() == null : this.getMoloTypeId().equals(other.getMoloTypeId()))
            && (this.getMoloTitle() == null ? other.getMoloTitle() == null : this.getMoloTitle().equals(other.getMoloTitle()))
            && (this.getMoloContent() == null ? other.getMoloContent() == null : this.getMoloContent().equals(other.getMoloContent()))
            && (this.getMoloStarNum() == null ? other.getMoloStarNum() == null : this.getMoloStarNum().equals(other.getMoloStarNum()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getMoloId() == null) ? 0 : getMoloId().hashCode());
        result = prime * result + ((getMoloOwnerId() == null) ? 0 : getMoloOwnerId().hashCode());
        result = prime * result + ((getMoloTypeId() == null) ? 0 : getMoloTypeId().hashCode());
        result = prime * result + ((getMoloTitle() == null) ? 0 : getMoloTitle().hashCode());
        result = prime * result + ((getMoloContent() == null) ? 0 : getMoloContent().hashCode());
        result = prime * result + ((getMoloStarNum() == null) ? 0 : getMoloStarNum().hashCode());
        return result;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", moloId=").append(moloId);
        sb.append(", moloOwnerId=").append(moloOwnerId);
        sb.append(", moloTypeId=").append(moloTypeId);
        sb.append(", moloTitle=").append(moloTitle);
        sb.append(", moloContent=").append(moloContent);
        sb.append(", moloStarNum=").append(moloStarNum);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}