package com.molo.molo.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import lombok.Data;

/**
 * 
 * @TableName mololog
 */
@TableName(value ="mololog")
@Data
public class Mololog implements Serializable {
    /**
     * molo日志id
     */
    @TableId(type = IdType.AUTO)
    private Integer molologId;

    /**
     * molo索引
     */
    private Integer moloId;

    /**
     * 日志时间
     */
    private String molologTime;

    /**
     * 日志详情
     */
    private String molologDescription;

    @TableField(exist = false)
    private static final long serialVersionUID = 1L;

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        Mololog other = (Mololog) that;
        return (this.getMolologId() == null ? other.getMolologId() == null : this.getMolologId().equals(other.getMolologId()))
            && (this.getMoloId() == null ? other.getMoloId() == null : this.getMoloId().equals(other.getMoloId()))
            && (this.getMolologTime() == null ? other.getMolologTime() == null : this.getMolologTime().equals(other.getMolologTime()))
            && (this.getMolologDescription() == null ? other.getMolologDescription() == null : this.getMolologDescription().equals(other.getMolologDescription()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getMolologId() == null) ? 0 : getMolologId().hashCode());
        result = prime * result + ((getMoloId() == null) ? 0 : getMoloId().hashCode());
        result = prime * result + ((getMolologTime() == null) ? 0 : getMolologTime().hashCode());
        result = prime * result + ((getMolologDescription() == null) ? 0 : getMolologDescription().hashCode());
        return result;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", molologId=").append(molologId);
        sb.append(", moloId=").append(moloId);
        sb.append(", molologTime=").append(molologTime);
        sb.append(", molologDescription=").append(molologDescription);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}