package com.molo.molo.mapper;

import com.molo.molo.entity.Mtype;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author Alee
* @description 针对表【mtype】的数据库操作Mapper
* @createDate 2023-07-20 16:06:23
* @Entity com.molo.molo.entity.Mtype
*/
public interface MtypeMapper extends BaseMapper<Mtype> {

}




