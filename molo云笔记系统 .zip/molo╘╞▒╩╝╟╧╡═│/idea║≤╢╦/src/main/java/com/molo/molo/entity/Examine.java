package com.molo.molo.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import lombok.Data;

/**
 * 
 * @TableName examine
 */
@TableName(value ="examine")
@Data
public class Examine implements Serializable {
    /**
     * 审核表id
     */
    @TableId(type = IdType.AUTO)
    private Integer examineId;

    /**
     * 申请用户名
     */
    private String examineUsername;

    /**
     * 申请用户密码
     */
    private String examinePassword;

    /**
     * 申请状态（0：待审核，1：通过，2：拒绝）
     */
    private Integer examineStatus;

    /**
     * 申请类型（1：申请账号，2：申请成为UP）
     */
    private Integer examineType;

    @TableField(exist = false)
    private static final long serialVersionUID = 1L;

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        Examine other = (Examine) that;
        return (this.getExamineId() == null ? other.getExamineId() == null : this.getExamineId().equals(other.getExamineId()))
            && (this.getExamineUsername() == null ? other.getExamineUsername() == null : this.getExamineUsername().equals(other.getExamineUsername()))
            && (this.getExaminePassword() == null ? other.getExaminePassword() == null : this.getExaminePassword().equals(other.getExaminePassword()))
            && (this.getExamineStatus() == null ? other.getExamineStatus() == null : this.getExamineStatus().equals(other.getExamineStatus()))
            && (this.getExamineType() == null ? other.getExamineType() == null : this.getExamineType().equals(other.getExamineType()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getExamineId() == null) ? 0 : getExamineId().hashCode());
        result = prime * result + ((getExamineUsername() == null) ? 0 : getExamineUsername().hashCode());
        result = prime * result + ((getExaminePassword() == null) ? 0 : getExaminePassword().hashCode());
        result = prime * result + ((getExamineStatus() == null) ? 0 : getExamineStatus().hashCode());
        result = prime * result + ((getExamineType() == null) ? 0 : getExamineType().hashCode());
        return result;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", examineId=").append(examineId);
        sb.append(", examineUsername=").append(examineUsername);
        sb.append(", examinePassword=").append(examinePassword);
        sb.append(", examineStatus=").append(examineStatus);
        sb.append(", examineType=").append(examineType);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}