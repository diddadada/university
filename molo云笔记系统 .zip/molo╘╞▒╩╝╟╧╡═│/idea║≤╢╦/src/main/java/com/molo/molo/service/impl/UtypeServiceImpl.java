package com.molo.molo.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.molo.molo.entity.Utype;
import com.molo.molo.service.UtypeService;
import com.molo.molo.mapper.UtypeMapper;
import org.springframework.stereotype.Service;

/**
* @author Alee
* @description 针对表【utype】的数据库操作Service实现
* @createDate 2023-07-20 16:06:23
*/
@Service
public class UtypeServiceImpl extends ServiceImpl<UtypeMapper, Utype>
    implements UtypeService{

}




