package com.molo.molo.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.molo.molo.entity.*;
import com.molo.molo.service.*;
import com.molo.molo.mapper.UserMapper;
import com.molo.molo.vo.P;
import com.molo.molo.vo.PX;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * @author Alee
 * @description 针对表【user】的数据库操作Service实现
 * @createDate 2023-07-20 15:43:51
 */
@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User>
        implements UserService{
    @Autowired
    ExamineService examineService;
    @Autowired
    UserlogService userlogService;
    @Autowired
    MoloService moloService;
    @Autowired
    MolologService molologService;

    //    判断是否存在同名用户
    @Override
    public boolean havaSameNameUser(User user) {
        LambdaQueryWrapper<User> queryWrapper=new LambdaQueryWrapper<>();
        queryWrapper.eq(User::getUserName,user.getUserName());
        if(list(queryWrapper).size()!=0){
            return true;
        }
        LambdaQueryWrapper<Examine> queryWrapper1=new LambdaQueryWrapper<>();
        queryWrapper1.eq(Examine::getExamineUsername,user.getUserName());
        if (examineService.list(queryWrapper1).size()!=0){
            return true;
        }
        return false;
    }
    @Override
    public PX searchUser(Map<String, Object> map) {
        //多条件查询  id  用户类型  用户状态
        LambdaQueryWrapper<User> wrapper = new LambdaQueryWrapper<>();//mybatisplus构建条件对象
        wrapper.eq(map.containsKey("userId")&&!StringUtils.isEmpty(map.get("userId").toString()),User::getUserId,map.get("userId"));//判断map中是否包含userId条件,包含ze比较
        wrapper.eq(map.containsKey("userTypeId")&&!StringUtils.isEmpty(map.get("userTypeId").toString()),User::getUserTypeId,map.get("userTypeId"));
        wrapper.eq(map.containsKey("userStatus")&&!StringUtils.isEmpty(map.get("userStatus").toString()),User::getUserStatus,map.get("userStatus"));

        //判断是否包含分页对象  page表示当前页,size表示每页条数
        if(map.containsKey("page")){
            //存在分页,进行分页查询  get()是object ->string->long
            long current = Long.parseLong(map.get("page").toString());//当前页
            long size = Long.parseLong(map.get("size").toString());//每页条数
            Page<User> page = new Page<>(current,size);//创建分页对象
            page = this.page(page,wrapper);//多条件分页查询
            return new PX(page.getTotal(),page.getRecords());//传入总条数, 分页后的集合
        }else{
            return new PX(0L,this.list(wrapper));//传入总条数0 , 集合:多条件查询后的集合
        }


    }


//    注册
    @Override
    public boolean regist(User user) {
        if (havaSameNameUser(user)){
            return false;
        }
        //        初始化examine对象
        Examine examine=new Examine();
        examine.setExamineUsername(user.getUserName());
        examine.setExaminePassword(new BCryptPasswordEncoder().encode(user.getUserPassword()).toString());
        examine.setExamineType(user.getUserTypeId());
        examine.setExamineStatus(0);
        return examineService.save(examine);
    }
//    登录
@Override
//    用户登录
    public User login(User user) {
    LambdaQueryWrapper<User> queryWrapper=new LambdaQueryWrapper<>();
    queryWrapper.eq(User::getUserName,user.getUserName());
    User temp=this.getOne(queryWrapper);
    System.out.println(temp);
//        判断账户是否存在
    if(temp!=null){
        //        判断账户是否被封禁
        if (temp.getUserStatus()==1){
            BCryptPasswordEncoder bCryptPasswordEncoder=new BCryptPasswordEncoder();
//            验证密码
            boolean flag=bCryptPasswordEncoder.matches(user.getUserPassword(),temp.getUserPassword());
            System.out.println("密码"+flag);
            if(flag){
                temp.setToken(UUID.randomUUID().toString()+System.currentTimeMillis());
                updateById(temp);
                temp.setUserPassword(null);
//                存日志
                LocalDateTime nowDateTime = LocalDateTime.now();
                DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
                String now=dateTimeFormatter.format(nowDateTime);
                Userlog userlog=new Userlog();
                userlog.setUserId(temp.getUserId());
                userlog.setUserlogDescription("login");
                userlog.setUserlogTime(now);
                userlogService.save(userlog);
//                返回删除密码之后的user对象
                return temp;
            }
        }
    }
    return null;
}

//根据token判断用户登录状态
    public boolean checkToken(User user){
        LambdaQueryWrapper<User> queryWrapper=new LambdaQueryWrapper<>();
        queryWrapper.eq(User::getToken,user.getToken());
        if (this.getOne(queryWrapper)!=null){
            return true;
        }
        return false;
    }

//更新用户
    @Override
    public boolean updateUser(User user) {
        if (checkToken(user)){
            BCryptPasswordEncoder bCryptPasswordEncoder=new BCryptPasswordEncoder();
            user.setUserPassword(bCryptPasswordEncoder.encode(user.getUserPassword()));
            user.setUserId(getUserByToken(user.getToken()).getUserId());
            this.updateById(user);
            //                存日志
            LambdaQueryWrapper<User> queryWrapper=new LambdaQueryWrapper<>();
            queryWrapper.eq(User::getToken,user.getToken());
            User temp=this.getOne(queryWrapper);
            LocalDateTime nowDateTime = LocalDateTime.now();
            DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            String now=dateTimeFormatter.format(nowDateTime);
            Userlog userlog=new Userlog();
            userlog.setUserId(temp.getUserId());
            userlog.setUserlogDescription("updatePassword");
            userlog.setUserlogTime(now);
            userlogService.save(userlog);
            return true;
        }
        return false;
    }



//    通过token获取用户
   public User getUserByToken(String token){
        LambdaQueryWrapper<User> queryWrapper=new LambdaQueryWrapper<>();
        queryWrapper.eq(User::getToken,token);
        return getOne(queryWrapper);
    }

    @Override
    public boolean deleteMolo(String token, int id) {
        User user=new User();
        user.setToken(token);
        if(checkToken(user)){
            Mololog mololog=new Mololog();
            mololog.setMoloId(id);
            mololog.setMolologDescription("delete");
            LocalDateTime nowDateTime = LocalDateTime.now();
            DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            String now=dateTimeFormatter.format(nowDateTime);
            mololog.setMolologTime(now);
            molologService.save(mololog);
            removeAllStarById(id);
            return moloService.removeById(id);
        }
        return false;
    }

    @Override
    public Molo viewMolo(String token, int id) {
        User user=new User();
        user.setToken(token);
        if(checkToken(user)){
            LambdaQueryWrapper<Molo> queryWrapper=new LambdaQueryWrapper<>();
            queryWrapper.eq(Molo::getMoloId,id);
            Molo molo=moloService.getOne(queryWrapper);
            return molo;

        }
        return null;
    }

    @Override
    public boolean updateMolo(User user, Molo molo) {
        if(checkToken(user)){
            LambdaQueryWrapper<Star> queryWrapper=new LambdaQueryWrapper<>();





            LocalDateTime nowDateTime = LocalDateTime.now();
            DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            String now=dateTimeFormatter.format(nowDateTime);
            Mololog mololog=new Mololog();
            mololog.setMolologDescription("update");
            mololog.setMoloId(molo.getMoloId());
            mololog.setMolologTime(now);
            molologService.save(mololog);
            return moloService.updateById(molo);
        }
        return false;
    }

    @Override
    public boolean applyForUP(User user) {
        if (user.getUserTypeId()==2){
            return false;
        }else if (checkToken(user)){
//            查询是否已经提交申请
            LambdaQueryWrapper<Examine> queryWrapper=new LambdaQueryWrapper<>();
            queryWrapper.eq(Examine::getExamineUsername,user.getUserName());
            queryWrapper.eq(Examine::getExamineType,2);
            Examine t=examineService.getOne(queryWrapper);
            if (t !=null) {
                return false;
            }







            Examine examine=new Examine();
            examine.setExamineType(2);
            examine.setExamineUsername(user.getUserName());
            examine.setExamineStatus(0);
            boolean flag= examineService.save(examine);
            LocalDateTime nowDateTime = LocalDateTime.now();
            DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            String now=dateTimeFormatter.format(nowDateTime);
            Userlog userlog=new Userlog();
            userlog.setUserId(user.getUserId());
            userlog.setUserlogDescription("applyForUP");
            userlog.setUserlogTime(now);
            userlogService.save(userlog);
            return flag;
        }
        return false;
    }



//    申诉
    @Override
    public boolean appeal(User user) {
        System.out.println("appeal "+ user);
        if (user.getUserStatus() != 0) {
            return false;
        } else {

//            查询是否已经提交申请
            LambdaQueryWrapper<Examine> queryWrapper = new LambdaQueryWrapper<>();
            queryWrapper.eq(Examine::getExamineUsername, user.getUserName());
            queryWrapper.eq(Examine::getExamineType, 3);
            queryWrapper.eq(Examine::getExamineStatus, 1);
            Examine t = examineService.getOne(queryWrapper);
            if (t != null) {
                return false;
            }


            Examine examine = new Examine();
            examine.setExamineType(3);
            examine.setExamineUsername(user.getUserName());
            examine.setExamineStatus(0);
            System.out.println(examine);
            boolean flag = examineService.save(examine);

            LocalDateTime nowDateTime = LocalDateTime.now();
            DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            String now = dateTimeFormatter.format(nowDateTime);
            Userlog userlog = new Userlog();
            userlog.setUserId(user.getUserId());
            userlog.setUserlogDescription("appeal");
            userlog.setUserlogTime(now);
            userlogService.save(userlog);
            return flag;
        }
    }

    @Override
    public Page getPrivateMolo(P p) {
        System.out.println(p);
        User temp=getUserByToken(p.getToken());
        if (temp==null){
            return null;
        }

        if (checkToken(temp)){//核对token
            p.setUserName(temp.getUserName());
            LambdaQueryWrapper<Molo> queryWrapper=new LambdaQueryWrapper<>();
            LambdaQueryWrapper<User> queryWrapper1=new LambdaQueryWrapper<>();
            queryWrapper.eq(Molo::getMoloOwnerId,temp.getUserId());
            if (p.getMoloTitle()!=null){
                queryWrapper.like(Molo::getMoloTitle,"%"+p.getMoloTitle()+"%");
            }
            if (p.getMoloContent()!=null){
                queryWrapper.like(Molo::getMoloContent,"%"+p.getMoloContent()+"%");
            }
            System.out.println(p);
            Page page=new Page(p.getPageNum(), p.getPageSize());
            page = moloService.page(page,queryWrapper);
            return page;
        }
        return null;
    }

    @Override
    public Page getPublicMolo(P p) {
            LambdaQueryWrapper<Molo> queryWrapper=new LambdaQueryWrapper<>();
            LambdaQueryWrapper<User> queryWrapper1=new LambdaQueryWrapper<>();
            if (p.getUserName()!=null){
                queryWrapper1.eq(User::getUserName,p.getUserName());
                User user=getOne(queryWrapper1);
                queryWrapper.eq(Molo::getMoloOwnerId,user.getUserId());
            }
            if (p.getMoloTitle()!=null){
                queryWrapper.like(Molo::getMoloTitle,"%"+p.getMoloTitle()+"%");
            }
            if (p.getMoloContent()!=null){
                queryWrapper.like(Molo::getMoloContent,"%"+p.getMoloContent()+"%");
            }
            queryWrapper.eq(Molo::getMoloTypeId,2);
            System.out.println(p);
            Page page=new Page(p.getPageNum(), p.getPageSize());
            page = moloService.page(page,queryWrapper);
            System.out.println(page);
            return page;

    }

    @Override
    public Object getLatestMolo() {
        return null;
    }

    @Override
    public List getAllPrivateMolo(String token) {
        User temp=getUserByToken(token);
        System.out.println(token);
        if (temp!=null){
            System.out.println(temp);
            LambdaQueryWrapper<Molo> queryWrapper=new LambdaQueryWrapper();
            queryWrapper.eq(Molo::getMoloOwnerId,temp.getUserId());
            List<Molo> list=moloService.list(queryWrapper);
            System.out.println(list);
            return list;
        }

        return null;
    }
    @Autowired
    StarService starServiceservice;
    @Override
    public boolean starMolo(StarMoloEntity starMolo) {
        System.out.println(starMolo);
        User temp=getUserByToken(starMolo.getToken());
        if (temp!=null){


            LambdaQueryWrapper<Star> queryWrapper1=new LambdaQueryWrapper<>();
            queryWrapper1.eq(Star::getStarMoloId,starMolo.getMoloId());
            queryWrapper1.eq(Star::getStarUserId,temp.getUserId());

            Star star1=starServiceservice.getOne(queryWrapper1);
            if ((star1!=null)){
                return false;
            }



            Star star=new Star();
            star.setStarUserId(temp.getUserId());
            star.setStarMoloId(starMolo.getMoloId());


            LocalDateTime nowDateTime = LocalDateTime.now();
            DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            String now=dateTimeFormatter.format(nowDateTime);
            Mololog mololog=new Mololog();
            mololog.setMolologDescription("star");
            mololog.setMoloId(starMolo.getMoloId());
            mololog.setMolologTime(now);
            molologService.save(mololog);

            LambdaQueryWrapper<Molo> queryWrapper=new LambdaQueryWrapper<>();
            queryWrapper.eq(Molo::getMoloId,starMolo.getMoloId());
            Molo molo=moloService.getOne(queryWrapper);
            molo.setMoloStarNum(molo.getMoloStarNum()+1);
            moloService.updateById(molo);
            return starServiceservice.save(star);
        }

        return false;
    }


    public boolean removeAllStarById(Integer id){
        LambdaQueryWrapper<Star> queryWrapper=new LambdaQueryWrapper<>();
        queryWrapper.eq(Star::getStarMoloId,id);
        return starServiceservice.remove(queryWrapper);
    }

    @Override
    public List getStarMolo(String token) {
        User user=getUserByToken(token);
        if(user==null){
            return null;
        }else {
            LambdaQueryWrapper<Star> lambdaQueryWrapper=new LambdaQueryWrapper<>();
            lambdaQueryWrapper.eq(Star::getStarUserId,user.getUserId());
            List<Star> list=starServiceservice.list(lambdaQueryWrapper);
            List<UserStarMolo> list1=new ArrayList<>();
            for (int i = 0; i < list.size(); i++) {
                LambdaQueryWrapper<Molo> lambdaQueryWrapper1=new LambdaQueryWrapper<>();
                lambdaQueryWrapper1.eq(Molo::getMoloId,list.get(i).getStarMoloId());
                UserStarMolo temp=new UserStarMolo();
                Molo tempMolo=moloService.getOne(lambdaQueryWrapper1);
                temp.setToken(token);
                temp.setMolo(tempMolo);
                list1.add(temp);

            }
            return list1;
        }
    }

    @Override
    public boolean removeStarMolo(DeleteMoloEntity deleteMoloEntity) {
        User user=getUserByToken(deleteMoloEntity.getToken());
        if (user==null){
            return false;
        }
        LambdaQueryWrapper<Star> queryWrapper=new LambdaQueryWrapper<>();
        queryWrapper.eq(Star::getStarUserId,user.getUserId());
        queryWrapper.eq(Star::getStarMoloId,deleteMoloEntity.getId());

        return starServiceservice.remove(queryWrapper);

    }


    //新增molo
    @Override
    public boolean insertMolo(User user, Molo molo) {
        if (checkToken(user)){

            Mololog mololog=new Mololog();
            molo.setMoloStarNum(0);
            boolean flag=moloService.save(molo);
            mololog.setMoloId(molo.getMoloId());
            mololog.setMolologDescription("Insert");
            LocalDateTime nowDateTime = LocalDateTime.now();
            DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            String now=dateTimeFormatter.format(nowDateTime);
            mololog.setMolologTime(now);
            molologService.save(mololog);


            return flag;
        }
        return false;
    }


}




