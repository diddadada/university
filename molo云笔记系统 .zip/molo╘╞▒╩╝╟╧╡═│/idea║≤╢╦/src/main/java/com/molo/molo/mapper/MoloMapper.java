package com.molo.molo.mapper;

import com.molo.molo.entity.Molo;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author Alee
* @description 针对表【molo】的数据库操作Mapper
* @createDate 2023-07-20 16:06:23
* @Entity com.molo.molo.entity.Molo
*/
public interface MoloMapper extends BaseMapper<Molo> {

}




