package com.molo.molo.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import lombok.Data;

/**
 * 
 * @TableName mtype
 */
@TableName(value ="mtype")
@Data
public class Mtype implements Serializable {
    /**
     * molo类型id
     */
    @TableId
    private Integer moloTypeId;

    /**
     * molo类型名
     */
    private String moloTypeName;

    @TableField(exist = false)
    private static final long serialVersionUID = 1L;

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        Mtype other = (Mtype) that;
        return (this.getMoloTypeId() == null ? other.getMoloTypeId() == null : this.getMoloTypeId().equals(other.getMoloTypeId()))
            && (this.getMoloTypeName() == null ? other.getMoloTypeName() == null : this.getMoloTypeName().equals(other.getMoloTypeName()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getMoloTypeId() == null) ? 0 : getMoloTypeId().hashCode());
        result = prime * result + ((getMoloTypeName() == null) ? 0 : getMoloTypeName().hashCode());
        return result;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", moloTypeId=").append(moloTypeId);
        sb.append(", moloTypeName=").append(moloTypeName);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}