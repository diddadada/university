package com.molo.molo.service;

import com.molo.molo.entity.Molo;
import com.baomidou.mybatisplus.extension.service.IService;
import com.molo.molo.vo.PX;

import java.util.Map;

/**
 * @author Alee
 * @description 针对表【molo】的数据库操作Service
 * @createDate 2023-07-20 16:06:23
 */
public interface MoloService extends IService<Molo> {
    PX searchMolo(Map<String, Object> map);

}
