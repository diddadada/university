package com.molo.molo.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.molo.molo.entity.Examine;
import com.molo.molo.service.ExamineService;
import com.molo.molo.mapper.ExamineMapper;
import org.springframework.stereotype.Service;

/**
* @author Alee
* @description 针对表【examine】的数据库操作Service实现
* @createDate 2023-07-20 16:06:23
*/
@Service
public class ExamineServiceImpl extends ServiceImpl<ExamineMapper, Examine>
    implements ExamineService{

}




