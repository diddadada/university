package com.molo.molo.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class R {//结果对象
    /**
     * 编码
     */
    private Integer code;
    /**
     * 信息
     */
    private String msg;
    /**
     * 数据
     */
    private Object data;

    /**
     * 响应成功
     * @return
     */
    public static  R ok(){
        return new R(200,"success",null);
    }

    /**
     * 响应成功并返回数据
     * @return
     */
    public static  R ok(Object data){
        return new R(200,"success",data);
    }

    /**
     * 响应失败
     * @return
     */
    public static  R error(){
        return new R(400,"fail",null);
    }
}
