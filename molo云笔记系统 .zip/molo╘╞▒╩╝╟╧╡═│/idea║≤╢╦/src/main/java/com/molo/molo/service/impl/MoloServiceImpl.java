package com.molo.molo.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.molo.molo.entity.Molo;
import com.molo.molo.service.MoloService;
import com.molo.molo.mapper.MoloMapper;
import com.molo.molo.vo.PX;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.Map;

/**
 * @author Alee
 * @description 针对表【molo】的数据库操作Service实现
 * @createDate 2023-07-20 16:06:23
 */
@Service
public class MoloServiceImpl extends ServiceImpl<MoloMapper, Molo>
        implements MoloService{
    @Override
    public PX searchMolo(Map<String, Object> map) {
        //多条件查询   molo创建者id  molo类型id
        LambdaQueryWrapper<Molo> wrapper = new LambdaQueryWrapper<>();//mybatisplus构建条件对象
        wrapper.eq(map.containsKey("moloOwnerId")&&!StringUtils.isEmpty(map.get("moloOwnerId").toString()),Molo::getMoloOwnerId,map.get("moloOwnerId"));//判断map中是否包含userId条件,包含ze比较
        wrapper.eq(map.containsKey("moloTypeId")&&!StringUtils.isEmpty(map.get("moloTypeId").toString()),Molo::getMoloTypeId,map.get("moloTypeId"));

        //判断是否包含分页对象  page表示当前页,size表示每页条数
        if(map.containsKey("page")){
            //存在分页,进行分页查询  get()是object ->string->long
            long current = Long.parseLong(map.get("page").toString());//当前页
            long size = Long.parseLong(map.get("size").toString());//每页条数
            Page<Molo> page = new Page<>(current,size);//创建分页对象
            page = this.page(page,wrapper);//多条件分页查询
            System.out.println(page.getTotal());
            return new PX(page.getTotal(),page.getRecords());//传入总条数, 分页后的集合
        }else{
            return new PX(0L,this.list(wrapper));//传入总条数0 , 集合:多条件查询后的集合
        }


    }



}




