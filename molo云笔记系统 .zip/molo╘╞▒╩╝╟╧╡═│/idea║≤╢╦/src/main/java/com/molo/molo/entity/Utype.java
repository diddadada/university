package com.molo.molo.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import lombok.Data;

/**
 * 
 * @TableName utype
 */
@TableName(value ="utype")
@Data
public class Utype implements Serializable {
    /**
     * 用户类型id
     */
    @TableId
    private Integer userTypeId;

    /**
     * 用户类型名
     */
    private String userTypeName;

    @TableField(exist = false)
    private static final long serialVersionUID = 1L;

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        Utype other = (Utype) that;
        return (this.getUserTypeId() == null ? other.getUserTypeId() == null : this.getUserTypeId().equals(other.getUserTypeId()))
            && (this.getUserTypeName() == null ? other.getUserTypeName() == null : this.getUserTypeName().equals(other.getUserTypeName()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getUserTypeId() == null) ? 0 : getUserTypeId().hashCode());
        result = prime * result + ((getUserTypeName() == null) ? 0 : getUserTypeName().hashCode());
        return result;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", userTypeId=").append(userTypeId);
        sb.append(", userTypeName=").append(userTypeName);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}