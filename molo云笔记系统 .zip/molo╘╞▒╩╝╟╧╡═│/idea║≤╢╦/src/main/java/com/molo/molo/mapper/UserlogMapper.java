package com.molo.molo.mapper;

import com.molo.molo.entity.Userlog;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author Alee
* @description 针对表【userlog】的数据库操作Mapper
* @createDate 2023-07-20 16:06:23
* @Entity com.molo.molo.entity.Userlog
*/
public interface UserlogMapper extends BaseMapper<Userlog> {

}




