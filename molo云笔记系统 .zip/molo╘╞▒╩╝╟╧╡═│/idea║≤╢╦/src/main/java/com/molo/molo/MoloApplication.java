package com.molo.molo;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan(basePackages={"com.molo.molo.mapper"})
public class MoloApplication {

    public static void main(String[] args) {
        SpringApplication.run(MoloApplication.class, args);
    }

}
