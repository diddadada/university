package com.molo.molo.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.molo.molo.entity.*;
import com.molo.molo.service.UserService;
import com.molo.molo.vo.P;
import com.molo.molo.vo.R;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;


/**
*
* ━━━━━━神兽出没━━━━━━
* 　　 ┏┓     ┏┓
* 　　┏┛┻━━━━━┛┻┓
* 　　┃　　　　　 ┃
* 　　┃　　━　　　┃
* 　　┃　┳┛　┗┳  ┃
* 　　┃　　　　　 ┃
* 　　┃　　┻　　　┃
* 　　┃　　　　　 ┃
* 　　┗━┓　　　┏━┛　Code is far away from bug with the animal protecting
* 　　　 ┃　　　┃    神兽保佑,代码无bug
* 　　　　┃　　　┃
* 　　　　┃　　　┗━━━┓
* 　　　　┃　　　　　　┣┓
* 　　　　┃　　　　　　┏┛
* 　　　　┗┓┓┏━┳┓┏┛
* 　　　　 ┃┫┫ ┃┫┫
* 　　　　 ┗┻┛ ┗┻┛
*/
/**
 * 　　　　　　　 ┏┓　　　┏┓
 * 　　　　　　　┏┛┻━━━━━┛┻┓
 * 　　　　　　　┃　　　　　　┃ 　
 * 　　　　　　　┃　　　━　　 ┃
 * 　　　　　　　┃　＞　　＜　 ┃
 * 　　　　　　　┃　　　　　　 ┃
 * 　　　　　　　┃... ⌒ ... ┃
 * 　　　　　　　┃　　　　　　┃
 * 　　　　　　　┗━┓　　　┏━┛
 * 　　　　　　　　 ┃　　　┃　Code is far away from bug with the animal protecting　　　　　　　　　　
 * 　　　　　　　　 ┃　　　┃   神兽保佑,代码无bug
 * 　　　　　　　　 ┃　　　┃　　　　　　　　　　　
 * 　　　　　　　　 ┃　　　┃  　　　　　　
 * 　　　　　　　　 ┃　　　┃
 * 　　　　　　　　 ┃　　　┃　　　　　　　　　　　
 * 　　　　　　　　 ┃　　　┗━━━┓
 * 　　　　　　　　 ┃　　　　　　　┣┓
 * 　　　　　　　　 ┃　　　　　　　┏┛
 * 　　　　　　　　 ┗┓┓┏━┳┓┏┛
 * 　　　　　　　　　┃┫┫　┃┫┫
 * 　　　　　　　　　┗┻┛　┗┻┛
 */

/**
 *　　　　　　　 ┏┓　 ┏┓+ +
 *　　　　　　　┏┛┻━━━┛┻┓ + +
 *　　　　　　　┃　　　　　　┃ 　
 *　　　　　　　┃　　　━　　 ┃ ++ + + +
 *　　　　　　 ████━████  ┃+
 *　　　　　　　┃　　　　　　　┃ +
 *　　　　　　　┃　　　┻　　　┃
 *　　　　　　　┃　　　　　　┃ + +
 *　　　　　　　┗━┓　　　┏━┛
 *　　　　　　　　 ┃　　　┃　　　　　　　　　　　
 *　　　　　　　　 ┃　　　┃ + + + +
 *　　　　　　　　 ┃　　　┃　　　　Code is far away from bug with the animal protecting　　　　　　　
 *　　　　　　　　 ┃　　　┃ + 　　　　神兽保佑,代码无bug　　
 *　　　　　　　　 ┃　　　┃
 *　　　　　　　　 ┃　　　┃　　+　　　　　　　　　
 *　　　　　　　　 ┃　 　 ┗━━━┓ + +
 *　　　　　　　　 ┃ 　　　　   ┣┓
 *　　　　　　　　 ┃ 　　　　　 ┏┛
 *　　　　　　　　 ┗┓┓┏━┳┓┏┛ + + + +
 *　　　　　　　　  ┃┫┫ ┃┫┫
 *　　　　　　　　  ┗┻┛ ┗┻┛+ + + +
 */
@RestController
@CrossOrigin(origins = {"http://127.0.0.1:8080"}, allowCredentials = "true")
public class UserController {
    @Autowired
    UserService userService;

    @PostMapping("/user/getLatestMolo")
    public R getLatestMolo(){
        return R.ok(userService.getLatestMolo());
    }

//    传入参数：input:name,password,type;null:else
    //    用户注册
    @PostMapping("/user/register")
    public R register(@RequestBody User user){
        System.out.println(user);
        if(userService.regist(user)){
            return R.ok();
        }
        return R.error();
    }
//    传入参数：input：username,password;null:else
    //    用户登录
    @PostMapping("/user/login")
    public R login(@RequestBody User user) {
        System.out.println(user);
        User temp=userService.login(user);
        if (temp==null){
            return R.error();
        }
        return R.ok(temp);
    }
//    查询个人信息
//    传入参数：input：token,password;null:else
//    修改个人密码
    @PostMapping("/user/updateUser")
    public R updateUser(@RequestBody User user){
        System.out.println(user);
        boolean flag=userService.updateUser(user);
        if(flag){
            return R.ok();
        }
        return R.error();
    }




    @GetMapping("/user/getAllPrivateMolo")
    public R getAllPrivateMolo(String token){
        System.out.println(token);
        List list=userService.getAllPrivateMolo(token);
        return R.ok(list);
    }

//    查看个人仓库
    @PostMapping("/user/getPrivateMolo")
    public R getPrivateMolo(@RequestBody P p){
        Page page=userService.getPrivateMolo(p);
        if (page!=null)
        return R.ok(page);
        else return R.error();
    }
//    查看公共仓库
@PostMapping("/user/getPublicMolo")
public R getPublicMolo(@RequestBody P p){
    Page list=userService.getPublicMolo(p);
    if (list != null)
    return R.ok(list);
    else  return R.error();
}

//    新增MOLO
    @PostMapping("/user/insertMolo")
    public R insertMolo(@RequestBody InsertMoloEntity insertMoloEntity){
        String token=insertMoloEntity.getToken();
        String title=insertMoloEntity.getTitle();
        String content=insertMoloEntity.getContent();
        Integer type=insertMoloEntity.getType();
        User user=userService.getUserByToken(token);
        if (user==null){
            return R.error();
        }
        Molo molo=new Molo(null,user.getUserId(),type,title,content,0);

        boolean flag=userService.insertMolo(user,molo);
        if(flag){
            return R.ok();
        }
        return R.error();
    }
//    删除MOLO
    @PostMapping("/user/deleteMolo")
    public  R deleteMolo(@RequestBody DeleteMoloEntity deleteMoloEntity){
        System.out.println(deleteMoloEntity);
        boolean flag=userService.deleteMolo(deleteMoloEntity.getToken(),deleteMoloEntity.getId());
        if(flag){
            return R.ok();
        }
        return R.error();
    }
//    读取MOLO
@PostMapping("/user/viewMolo")
public  R viewMolo(@Param("token")String token,@Param("id")int id){
    Molo molo=userService.viewMolo(token,id);
    if(molo!=null){
        return R.ok(molo);
    }
    return R.error();
}


//    修改MOLO
    @PostMapping("/user/updateMolo")
    public R updateMolo(@RequestBody UpdateMoloEntity updateMoloEntity){
        String token=updateMoloEntity.getToken();
        int id= updateMoloEntity.getId();
        int type=updateMoloEntity.getType();
        String title=updateMoloEntity.getTitle();
        String content=updateMoloEntity.getContent();
        User user=userService.getUserByToken(token);
        if (user==null){
            return R.error();
        }
        Molo molo=new Molo(id,user.getUserId(),type,title,content,null);
        boolean flag=userService.updateMolo(user,molo);
        if(flag){
            return R.ok();
        }
        return R.error();

    }

//    提交UP申请
    @GetMapping("/user/applyForUP")
    public R applyForUP(String token){
        User user=userService.getUserByToken(token);
        if (user==null) return R.error();
        boolean flag=userService.applyForUP(user);
        if(flag){
            return R.ok();
        }
        return R.error();

    }

//    申诉
@GetMapping("/user/appeal")
public R appeal(String username){
    LambdaQueryWrapper<User> queryWrapper=new LambdaQueryWrapper();
    queryWrapper.eq(User::getUserName,username);
    User user=userService.getOne(queryWrapper);
    if (user==null) return R.error();
    boolean flag=userService.appeal(user);
    if(flag){
        return R.ok();
    }
    return R.error();

}


@PostMapping("/user/starMolo")
public R starMolo(@RequestBody StarMoloEntity starMolo){
        boolean flag=userService.starMolo(starMolo);
        if (flag){
            return R.ok();
        }return R.error();
}


@GetMapping("/user/getStarMolo")
public R getStarMolo(String token){

        System.out.println("getStarMolo by "+ token);
        List list=userService.getStarMolo(token);
        if (list!=null){
            System.out.println("return "+list);
            return R.ok(list);
        }
        return R.error();

}

@PostMapping("/user/removeStarMolo")
public R removeStarMolo(@RequestBody DeleteMoloEntity deleteMoloEntity){
    boolean flag=userService.removeStarMolo(deleteMoloEntity);
    if (flag){
    return     R.ok();
    }else return R.error();
}


/**
 *
 * ━━━━━━神兽出没━━━━━━
 * 　　 ┏┓     ┏┓
 * 　　┏┛┻━━━━━┛┻┓
 * 　　┃　　　　　 ┃
 * 　　┃　　━　　　┃
 * 　　┃　┳┛　┗┳  ┃
 * 　　┃　　　　　 ┃
 * 　　┃　　┻　　　┃
 * 　　┃　　　　　 ┃
 * 　　┗━┓　　　┏━┛　Code is far away from bug with the animal protecting
 * 　　　 ┃　　　┃    神兽保佑,代码无bug
 * 　　　　┃　　　┃
 * 　　　　┃　　　┗━━━┓
 * 　　　　┃　　　　　　┣┓
 * 　　　　┃　　　　　　┏┛
 * 　　　　┗┓┓┏━┳┓┏┛
 * 　　　　 ┃┫┫ ┃┫┫
 * 　　　　 ┗┻┛ ┗┻┛
 */
/**
 * 　　　　　　　 ┏┓　　　┏┓
 * 　　　　　　　┏┛┻━━━━━┛┻┓
 * 　　　　　　　┃　　　　　　┃ 　
 * 　　　　　　　┃　　　━　　 ┃
 * 　　　　　　　┃　＞　　＜　 ┃
 * 　　　　　　　┃　　　　　　 ┃
 * 　　　　　　　┃... ⌒ ... ┃
 * 　　　　　　　┃　　　　　　┃
 * 　　　　　　　┗━┓　　　┏━┛
 * 　　　　　　　　 ┃　　　┃　Code is far away from bug with the animal protecting　　　　　　　　　　
 * 　　　　　　　　 ┃　　　┃   神兽保佑,代码无bug
 * 　　　　　　　　 ┃　　　┃　　　　　　　　　　　
 * 　　　　　　　　 ┃　　　┃  　　　　　　
 * 　　　　　　　　 ┃　　　┃
 * 　　　　　　　　 ┃　　　┃　　　　　　　　　　　
 * 　　　　　　　　 ┃　　　┗━━━┓
 * 　　　　　　　　 ┃　　　　　　　┣┓
 * 　　　　　　　　 ┃　　　　　　　┏┛
 * 　　　　　　　　 ┗┓┓┏━┳┓┏┛
 * 　　　　　　　　　┃┫┫　┃┫┫
 * 　　　　　　　　　┗┻┛　┗┻┛
 */

    /**
     *　　　　　　　 ┏┓　 ┏┓+ +
     *　　　　　　　┏┛┻━━━┛┻┓ + +
     *　　　　　　　┃　　　　　　┃ 　
     *　　　　　　　┃　　　━　　 ┃ ++ + + +
     *　　　　　　 ████━████  ┃+
     *　　　　　　　┃　　　　　　　┃ +
     *　　　　　　　┃　　　┻　　　┃
     *　　　　　　　┃　　　　　　┃ + +
     *　　　　　　　┗━┓　　　┏━┛
     *　　　　　　　　 ┃　　　┃　　　　　　　　　　　
     *　　　　　　　　 ┃　　　┃ + + + +
     *　　　　　　　　 ┃　　　┃　　　　Code is far away from bug with the animal protecting　　　　　　　
     *　　　　　　　　 ┃　　　┃ + 　　　　神兽保佑,代码无bug　　
     *　　　　　　　　 ┃　　　┃
     *　　　　　　　　 ┃　　　┃　　+　　　　　　　　　
     *　　　　　　　　 ┃　 　 ┗━━━┓ + +
     *　　　　　　　　 ┃ 　　　　   ┣┓
     *　　　　　　　　 ┃ 　　　　　 ┏┛
     *　　　　　　　　 ┗┓┓┏━┳┓┏┛ + + + +
     *　　　　　　　　  ┃┫┫ ┃┫┫
     *　　　　　　　　  ┗┻┛ ┗┻┛+ + + +
     */
//汪航写的，错了别找我
//上传
@PostMapping("/user/Upload")
public R insertMolo(@Param("token") String token, @RequestParam("file") MultipartFile file, @Param("type") int type) throws IOException {
    User user=userService.getUserByToken(token);
    if (user==null){
        return R.error();
    }
    if (file == null|| file.isEmpty()) {
        return R.error();
    }
    String content = new String(file.getBytes());
    Molo molo=new Molo(null,user.getUserId(),type,file.getOriginalFilename().substring(0,file.getOriginalFilename().lastIndexOf(".")) ,content,0);
    boolean flag=userService.insertMolo(user,molo);
    if(flag){
        return R.ok();
    }
    return R.error();
}
}

