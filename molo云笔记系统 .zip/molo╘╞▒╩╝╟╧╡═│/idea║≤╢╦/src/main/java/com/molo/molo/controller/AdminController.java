package com.molo.molo.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.molo.molo.entity.*;
import com.molo.molo.service.*;
import com.molo.molo.vo.PX;
import com.molo.molo.vo.R;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@CrossOrigin(origins = {"http://127.0.0.1:8080"},allowCredentials = "true")
public class AdminController {
    @Autowired
    MolologService molologService;
    @Autowired
    UserlogService userlogService;
    @Autowired
    UserService userService;
    @Autowired
    ExamineService examineService;
    @Autowired
    AdminService adminService;
    @Autowired
    MoloService moloService;

    //登录
    @GetMapping("/admin/login")  //管理员登录
    public R login(String adminAccount, String adminPassword){
        System.out.println("login");
        return R.ok( adminService.login(adminAccount,adminPassword));
    }

    //mololog管理
    @GetMapping("/log/allMoloLog")  //获取全部molo日志
    public R allMoloLog() {
        LambdaQueryWrapper<Mololog> wrapper = new LambdaQueryWrapper<>();
        //根据创建日期降序排序
        wrapper.orderByDesc(Mololog::getMolologTime);
        return R.ok(molologService.list(wrapper));
    }

    @GetMapping("/moloLog/searchMololog")  //分页多条件查询mololog
    public R searchMololog(@RequestParam Map<String,Object> map){
        PX PX = molologService.searchMololog(map);
        return R.ok(PX);//R对象封装的是P分页对象
    }

    //userlog管理
    @GetMapping("/log/allUserLog")  //获取全部user日志
    public R allUserLog() {
        LambdaQueryWrapper<Userlog> wrapper = new LambdaQueryWrapper<>();
        //根据创建日期降序排序
        wrapper.orderByDesc(Userlog::getUserlogTime);
        return R.ok(userlogService.list(wrapper));
    }

    @GetMapping("/userLog/searchUserlog")  //分页多条件查询用户日志
    public R searchUserlog(@RequestParam Map<String,Object> map){
        PX PX = userlogService.searchUserlog(map);
        return R.ok(PX);//R对象封装的是P分页对象
    }

    //用户管理
    @GetMapping("/user/allUser")  //获取全部用户
    public R allUsers() { return R.ok(userService.list());}

    @PutMapping("/user/updateUser")  //修改用户
    public R updateUser(@RequestBody User user) { return R.ok(userService.updateById(user));}

    @GetMapping("/user/searchUser")  //分页多条件查询用户
    public R searchUser(@RequestParam Map<String,Object> map){ //形参接收传来的多条件: 用户id userId , 用户类型userTypeId 模糊查询,用户状态userStatus
        PX PX = userService.searchUser(map);
        return R.ok(PX);//R对象封装的是P分页对象
    }

    @DeleteMapping("/user/deleteUser/{userId}")  //删除用户
    public R deleteUser(@PathVariable Integer userId) {
//        删除该用户所创建的molo
        LambdaQueryWrapper<Molo> queryWrapper=new LambdaQueryWrapper<>();
        queryWrapper.eq(Molo::getMoloOwnerId,userId);
        System.out.println(moloService.remove(queryWrapper)+"删除molo");


        return R.ok(userService.removeById(userId));}

    @PostMapping("/user/addUser")  //新增用户
    public R addUser(@RequestBody User user){ //RequestBody作用在方法参数上,传来json数据会封装至teacher对象中
        return R.ok(userService.save(user));
    }

    @PutMapping("/user/ban")  //封禁用户
    public R ban(@RequestBody User user) {
        user.setUserStatus(0);
        return R.ok(userService.updateById(user));
    }

    @PutMapping("/user/relieve")  //解除封禁
    public R relieve(@RequestBody User user) {
        System.out.println(user);
        user.setUserStatus(1);
        return R.ok(userService.updateById(user));
    }

    //申请管理
    @GetMapping("/examine/allExamine")  //查看所有申请
    public R allExamine() {
        LambdaQueryWrapper<Examine> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Examine::getExamineStatus,"0");
        return R.ok(examineService.list(wrapper));
    }

    @PutMapping("/examine/allExamine/agree")  //同意申请
    public R agree(@RequestBody Examine examine) {
        examine.setExamineStatus(1);
        User user = new User();
        if(examine.getExamineType()==1) {  //当申请类型为1时，同意账号申请
            user.setUserName(examine.getExamineUsername());  //设置用户名
            user.setUserPassword(examine.getExaminePassword());  //设置密码
            user.setUserStatus(1);  //设置用户状态
            user.setUserTypeId(1);
            addUser(user);  //将其插入用户数据表
            return R.ok(examineService.updateById(examine));
        }else if(examine.getExamineType()==2) {  //当申请类型为2时，同意用户申请为up
            LambdaQueryWrapper<User> wrapper = new LambdaQueryWrapper<>();
            wrapper.eq(User::getUserName,examine.getExamineUsername());  //在用户表中查找用户名为申请用户名的用户
            User u = userService.getOne(wrapper);
            if(u!=null) {
                u.setUserTypeId(2);  //将其用户类型设置成up
                updateUser(u);  //保存设置
            }
            return R.ok(examineService.updateById(examine));

        }else if(examine.getExamineType()==3) {  //当申请类型为3时，同意即将用户解除封禁
            LambdaQueryWrapper<User> wrapper = new LambdaQueryWrapper<>();
            wrapper.eq(User::getUserName,examine.getExamineUsername());  //在用户表中查找用户名为申请用户名的用户
            User u = userService.getOne(wrapper);
            if(u!=null) {
                u.setUserStatus(1);  //将其状态设置为1，即正常状态
                updateUser(u);  //保存设置
            }
            return R.ok(examineService.updateById(examine));
        }
        else return R.error();
    }

    //molo管理
    @GetMapping("/molo/allMolo")  //获取所有molo
    public R allMolo() { return R.ok(moloService.list());}

    @PostMapping("/molo/addMolo")  //添加molo
    public R addMolo(@RequestBody Molo molo) { return R.ok(moloService.save(molo));}

    @PutMapping("/molo/updateMolo")  //修改molo
    public R updateMolo(@RequestBody Molo molo) { return R.ok(moloService.updateById(molo));}

    @DeleteMapping("/molo/delMolo/{moloId}")  //删除molo
    public R delMolo(@PathVariable Integer moloId) { return R.ok(moloService.removeById(moloId));}

    @GetMapping("/molo/searchMolo")  //分页多条件查询molo
    public R searchMolo(@RequestParam Map<String,Object> map){ //形参接收传来的多条件: molo创建者id   molo类型id
        PX PX = moloService.searchMolo(map);
        return R.ok(PX);//R对象封装的是P分页对象
    }
}
