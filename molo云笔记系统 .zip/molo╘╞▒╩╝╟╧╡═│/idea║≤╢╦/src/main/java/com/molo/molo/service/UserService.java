package com.molo.molo.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.molo.molo.entity.DeleteMoloEntity;
import com.molo.molo.entity.Molo;
import com.molo.molo.entity.StarMoloEntity;
import com.molo.molo.entity.User;
import com.baomidou.mybatisplus.extension.service.IService;
import com.molo.molo.vo.P;
import com.molo.molo.vo.PX;

import java.util.List;
import java.util.Map;

/**
 * @author Alee
 * @description 针对表【user】的数据库操作Service
 * @createDate 2023-07-20 15:43:51
 */
public interface UserService extends IService<User> {

    boolean havaSameNameUser(User user);

    boolean regist(User user);
    public User login(User user);

    boolean updateUser(User user);

    boolean insertMolo(User user, Molo molo);

    User getUserByToken(String token);

    boolean deleteMolo(String token, int id);

    Molo viewMolo(String token, int id);

    boolean updateMolo(User user, Molo molo);

    boolean applyForUP(User user);


    boolean appeal(User user);

    Page getPrivateMolo(P p);

    Page getPublicMolo(P p);

    Object getLatestMolo();

    List getAllPrivateMolo(String token);

    boolean starMolo(StarMoloEntity starMolo);

    List getStarMolo(String token);

    boolean removeStarMolo(DeleteMoloEntity deleteMoloEntity);

    PX searchUser(Map<String, Object> map);
}
