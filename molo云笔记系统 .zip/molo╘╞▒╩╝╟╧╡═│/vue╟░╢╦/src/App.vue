<template>
  <div id="app">
    <el-row class="bg-header clearfix">
      <el-col :span="24">
        <el-row>
          <el-col :span="20" :offset="2">
            <div>
              <Header />
            </div>
          </el-col>
        </el-row>
      </el-col>
    </el-row>
    <keep-alive :include="['Home','MyEditor']">
    <router-view></router-view>      
    </keep-alive>


    <!-- 页脚 -->
    <el-row id="footer">
      <el-col :span="6" :offset="2">
        <h3 class="el-icon-notebook-1" style="font-weight: 600;">MOLO</h3>
      </el-col><br>
	  <el-col :span="4" class="el-icon-s-tools" style="padding-left: 155px;">
	    <el-button class="glydl" type="text" @click="adminVisible = true" >管理员登录</el-button>
	    </el-col>
    </el-row>

    <!-- 管理员登录界面 -->
    <el-dialog
      :modal-append-to-body="false"
      title="管理员登录"
      center
      :visible.sync="adminVisible"
      width="30%">
      <el-form label-width="80px">
      <el-form-item label="账号">
          <el-input v-model="adminName"></el-input>
        </el-form-item>
        <el-form-item label="密码">
          <el-input v-model="password" show-password></el-input>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="adminVisible = false">取 消</el-button>
        <el-button type="primary" @click.prevent="adminLogin">登 录</el-button>
      </span>
    </el-dialog>

    <!-- 返回顶部按钮 -->
    <el-backtop :bottom="100">
      <div
        style="
           {
            height: 100%;
            width: 100%;
            background-color: #ff5100;
            box-shadow: 0 0 6px rgba(0, 0, 0, 0.12);
            text-align: center;
            line-height: 40px;
            color: #1989fa;
            border-radius: 30px;
          }
        "
      >
        UP
      </div>
    </el-backtop>

  </div>
</template>

<script>
import Home from "./components/Home";
import Header from "./components/Header";
export default {
  name: "App",
  components: {
    Home,
    Header,
  },
  data() {
    return {
      adminVisible: false,
	  headerVisible:"",//控制头部显示
      adminName:'',
      password:''

    };
  },
  methods:{
    adminLogin() {
      this.$axios({
        method: "GET",
        url: "/admin/login",
		params:{
			adminAccount: this.adminName,
			adminPassword: this.password
		}
      }).then((res) => {
          if (res.data.code===200){
			  this.adminVisible = false,
			  this.headerVisible = false;
            this.$message({
            message: res.data.msg,
            type: 'success'
            });
            this.$router.push({
              path: "/admin",
            });            
          }else{
            this.$message.error("用户名或密码错误");            
          }
        })
      this.adminVisible = false
    },
    quit() {
		console.log("an");
      this.headerVisible = true
        this.$router.push({
            path: "/",
        });            
    },
	
  },
  mounted() {
    this.headerVisible=true
	
  }
};
</script>

<style>
* {
  padding: 0;
  margin: 0;
  box-sizing: border-box;
  /* font-size: 14px; */
}
#app {
  background-color: rgb(245, 244, 246);
}

a {
  /* 去除<a>下划线 */
  text-decoration: none;
  color: rgb(149, 62, 21);
}
.headerTop{
  padding-top: 77px;
}

.bg-header {
  z-index: 100;
  /* vertical-align:middle; */
  position: fixed;
  text-align: center;
  width: 100%;
  height: 66px;
  line-height: 66px;
  box-shadow: 0px 8px 10px -15px #000;
  background-color: #fff;
}
.clearfix::before,
.clearfix::after {
  content: "";
  display: table;
  clear: both;
}

#new-notes {
  margin-top: 63px;
}
#hot-notes {
  margin-top: 26px;
}
#footer{
	height: ;
	width: 100%;
  padding-top: 26px;
  opacity: .7;
}
.actionRoute{
  padding: 2px;
  border-radius: 4px;
  background-color: #f5bda3;
}
.glydl{
  color: #000;
  margin-top: -10px;
  font-size: 16px;
}
</style>
