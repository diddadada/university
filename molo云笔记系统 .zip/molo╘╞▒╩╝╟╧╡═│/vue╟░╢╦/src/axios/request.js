import axios from 'axios'

const http = axios.create({
	baseURL:"http://127.0.0.1:8100",  //请求的java后端的接口基本地址
	timeout:5000,
	changeOrigin:true,
	withCredentials:true  //是否允许携带cookie
})

export default http;