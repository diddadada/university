import Vue from 'vue';
import ElementUI from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';
import axios from 'axios';
//引入VueRouter
import VueRouter from 'vue-router';
//引入路由器（对象）
import router from './router';
import App from './App.vue';

Vue.config.productionTip = false
Vue.use(ElementUI)
Vue.use(VueRouter)
Vue.prototype.$axios = axios

axios.defaults.baseURL = "http://127.0.0.1:8100"

new Vue({
  render: h => h(App),
  router: router,
  beforeCreate() {
   Vue.prototype.$bus = this //安装全局事件总线
  }
}).$mount('#app')
