//引入路由
import VueRouter from "vue-router";
//引入组件
import Home from "../components/Home"
import MyEditor from "../pages/MyEditor"
import Login from "../pages/Login"
import MyNotes from "../pages/MyNotes"
import LookAndEditorNote from "../pages/LookAndEditorNote"
import QueryNotes from "../pages/QueryNotes.vue"
import Admin from "../pages/Admin"
import AdminUsers from "../pages/adminSys/AdminUsers"
import FoundPage from "../pages/userSys/FoundPage"
import Personal from "../pages/userSys/Personal"
import Commodity from "../pages/userSys/Commodity"
import PublishCommodity from "../pages/userSys/PublishCommodity"
import NotePlaza from "../pages/NotePlaza"
import AdminNote from "../pages/adminSys/AdminNotes"
import AdminLostGoods from "../pages/adminSys/AdminLostGoods"
import AdminCloudShop from "../pages/adminSys/AdminCloudShop"
import CommodityDetails from '../pages/userSys/CommodityDetails'
import MyOrder from '../pages/userSys/MyOrder'

 const router =  new VueRouter({
    routes: [
        {
            path: '/',
            component: Home
        },
        {
            path: '/myEditor',
            component: MyEditor
        },
        {
            path: '/login',
            component: Login
        },
        {
            path: '/my-notes',
            component: MyNotes,
        },
        {
            name: 'look-note',
            path: '/lookAndEditorNote/:id',
            component: LookAndEditorNote,
        },
        {
            name: 'querynote',
            path: '/query-note',
            component: QueryNotes,
        },
        {
            path: '/admin',
            component: Admin,
            children: [
                {
                    path: 'admin-users',
                    component: AdminUsers
                },
                {
                    path: 'admin-notes',
                    component: AdminNote
                },
                {
                    path: 'admin-lostGoods',
                    component: AdminLostGoods
                },
                {
                    path: 'admin-cloudShop',
                    component: AdminCloudShop
                }
            ]
        },
        {
            path: '/found-page',
            component: FoundPage,
        },
        {
            path: '/personal',
            component: Personal,
        },
        {
            path: '/commodity',
            component: Commodity,
        },
        {
            path: '/publish-commodity',
            component: PublishCommodity,
        },
        {
            path: '/note-plaza',
            component: NotePlaza,
        },
        {
            path: '/commodity-details',
            component: CommodityDetails,
        },
        {
            path: '/my-order',
            component: MyOrder,
        },
    ]
})

// // 全局前置路由守卫，表示在每次切换路由之前调用，针对所有的路由
// router.beforeEach((to, from, next)=>{                         // to表示去哪个路由，from表示来自哪个路由，next表示放行
//     // 可加判断条件进行放行
//     if(to.path !== '/login' && to.path !=="/"){                                 // 判断要去的路由条件
//         if(localStorage.getItem('user01') == null){
//         	// 缓存中这个参数如果不是'atguigu'则进入登录重新登陆
//         	// 登录成功把这个值存储在缓存中
//             next('/login')                                           
//         } else{
//         	next()
//     	}
//     }
//     else{
//         next()
//     }
// })
export default router
