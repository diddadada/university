<template>
  <el-row>
    <el-col :span="18" :offset="3">
      <div class="note-div">
        <el-row id="note-list">
          <el-col :span="2">
            <span class="font-title">笔记广场</span>
          </el-col>
        </el-row>
		
		
		
		
		
		
		
		
<div style="padding-left: 10px;">
	<el-popover style=""
	    placement="center"
	    width=""
		
	    trigger="manual"
	    v-model="visible">
		<div>
			<!-- markdown area -->
			<el-col :span="16" >
			  <div id="editor-div">
			    <div style="border: 1px solid #ccc ;width: 1350px; height: 400pxpx;">
			      <Toolbar
			        style="border-bottom: 1px solid #ccc"
			        :editor="editor"
			        :defaultConfig="toolbarConfig"
			        :mode="mode"
			      />
			      <Editor
			        style="height: 500px; overflow-y: hidden"
			        v-model="currentContent"
			        :defaultConfig="editorConfig"
			        :mode="mode"
			        @onCreated="onCreated"
			      />
			    </div>
				<div>
					
					<el-input v-model="currentTitle" placeholder="新标题" style="width: 300px;"></el-input>
					<el-button @click="closeMolo()" style="margin: 10px;">关闭</el-button>
				</div>
	
			  </div>
			</el-col>
		</div>
	
		<span slot="footer" class="dialog-footer">
		</span>
	  </el-popover>
</div>
		
		
		
		
		
		
		
		
        <el-row id="host-note-div">
          <el-col :span="20" id="note" v-for="n in moloList">
           <el-container>
             <el-main style="width: 650px;">
               <h4 style="font-size: 15px">{{ n.moloTitle }}</h4>
               <p style="font-size: 12px; color: darkgray" v-html="n.moloContent">
                 
               </p>
             </el-main>
             <el-row>
               <el-col :span="12" :offset="12" style="margin-top: 22px">
                 <el-button type="primary" icon="el-icon-reading" @click="viewMolo(n.moloId,n.moloContent,n.moloTitle,n.moloTypeId)"></el-button>
               </el-col>
               <el-col :span="12" :offset="12" style="margin-top: 12px">
                 <el-popconfirm title="确认收藏？" @confirm="starMolo(n.moloId)">
                 <el-button type="danger" icon="el-icon-star-off" slot="reference" style="background-color: #53d9a1;border-color: #53d9a1;"></el-button>
                 </el-popconfirm>
               </el-col>
             </el-row>
           </el-container>
            </el-container>
          </el-col>
          <el-col :span="24" class="page">
            <!-- 分页 -->
             <el-pagination
			    v-model:current-page="pageNum"
			          v-model:page-size="pageSize"
			          :background=null
					  :page-count="pages"
			          layout="prev, pager, next, jumper"
			          @current-change="getPublicMolo1"
               />
          </el-col>
        </el-row>
      </div>
    </el-col>
  </el-row>
</template>

<script>
	// star的实现
	// 1.显示内容之前，从数据库的star表中读取对应用户的所有satr列表
	// 
	import { Editor, Toolbar } from "@wangeditor/editor-for-vue";
	import userApi from '../api/userApi.js'
	export default {
		  components: { Editor, Toolbar },
  name: "NotePlaza",
  data() {
    return {
		currentId:null,
		currentTitle:'',
		visible: false,
		currentContent:'',
		moloList: [],
		userId: JSON.parse(localStorage.getItem("user01")).userId,
		// 容量
		pageSize:4,
		// 当前页数
		pageNum:1,
				// 记录数：
		total:null,
		// 页数
		pages:null,
		
		editor: null,
		html: "",
		toolbarConfig: {},
		editorConfig: { 
		  placeholder: "请输入内容...",
		  MENU_CONF: {
		    'uploadImage': {
		      // 上传图片的配置
		        server: 'http://8.130.37.232:8089/upload/image',
		        fieldName: 'file',
		            // 上传错误，或者触发 timeout 超时
		        onError(file, err, res) {
		            alert("图片上传出错~")
		        },
		    }
		  }
		},
		mode: "default", // or 'simple'
		// ----------------------------------------------
		headerObj: {
		  noteId: "0",
		},
		

    };
  },

  methods: {
	  starMolo(moloId){
		  userApi.starMolo({
			  "token":localStorage.getItem("token"),
			  "moloId":moloId
		  }).then(resp=>{
			  if(resp.data.code==200){
				  alert("成功")
			  }else{
				  alert("已收藏")
			  }
		  })
	  },
	  viewMolo(moloId,moloContent,moloTitle,moloType){
	  	console.log(this.currentType)
	  	console.log(moloType)
	  	this.currentType=moloType
	  	this.currentId=moloId
	  	this.visible=true
	  	this.currentContent=moloContent
	  	this.currentTitle=moloTitle
	  },
	  closeMolo(){
	  	this.visible=false

	  	
	  },
	  onCreated(editor) {
	    this.editor = Object.seal(editor); // 一定要用 Object.seal() ，否则会报错
	  },
	  getPublicMolo1(val){
		  this.pageNum=val
		  console.log({"pageNum":this.pageNum,"pageSize":this.pageSize})

	  	userApi.getPublicMolo({"pageNum":this.pageNum,"pageSize":this.pageSize}).then(resp=>{
	  	if(resp.data.code==200){
	  		this.moloList=resp.data.data.records
	  			this.total=resp.data.data.total
	  			this.pageNum=resp.data.data.current
	  			this.pages=resp.data.data.pages
	  			console.log(this.total)
	  			console.log(this.pageNum)
	  			console.log(this.pageSize)
	  			console.log(this.pages)
	  		console.log(resp.data.data)
	  	}else{
	  
	  	}
	  	console.log(resp.data)
	  	})
	  },
	  getPublicMolo(p){
	  	userApi.getPublicMolo(p).then(resp=>{
	  	if(resp.data.code==200){
	  		this.moloList=resp.data.data.records
			this.total=resp.data.data.total
			this.pageNum=resp.data.data.current
			this.pages=resp.data.data.pages
			console.log(this.total)
			console.log(this.pageNum)
			console.log(this.pageSize)
			console.log(this.pages)
	  		console.log(resp.data.data)
	  	}else{
	  
	  	}
	  	console.log(resp.data)
	  	})
	  },
    getNoteList() {
      this.$axios({
        method: "GET",
        url: "/notes/getAllNotes",
      }).then((res) => {
        if (res.data.code == 10000) {
          this.noteList = res.data.data;
        } else {
          this.$message.error("保存失败");
        }
      });
    },
    handleCurrentChange(val) {
      this.$axios({
        method: "GET",
        url: "/notes/getAllNotes",
        params: {
          currentPage: val,
        },
      }).then((res) => {
        if (res.data.code == 10000) {
          this.noteList = res.data.data.records;
          this.page.total = res.data.data.total;
          this.page.size = res.data.data.size;
        } else {
          this.$message.error("查询出错~");
        }
      });
    },
  },

  mounted() {
    this.getPublicMolo({"pageNum":this.pageNum,"pageSize":this.pageSize})
  },
};
</script>

<style scoped>
.note-div {
  margin-top: 86px;
  padding-top: 1px;
  background-color: white;
  border-radius: 10px;
}

#note-list {
  margin-top: 12px;
  margin-left: 30px;
  border-bottom: 2px solid rgb(242, 243, 239);
  margin-bottom: 6px;
}
#el-min {
  padding: 8px;
}

#note {
  margin-left: 20px;
  margin-top: 7px;
  border-top: 2px solid rgb(242, 243, 239);
  border-bottom: 2px solid rgb(242, 243, 239);
}
#host-note-div {
  margin-left: 12px;
  box-shadow: 2px 2px 6px -5px #000;
}
.el-container {
  height: 136px;
  box-shadow: 0px 8px 10px -15px #000;
}
#note-img {
  width: 160px;
  height: 90px;
}
.font-title {
  font-size: 16px;
  font-weight: 600;
}
#lookbutton{
  background-color: rgb(245,189,163);
  font-size: 18px;
}
.page{
  margin: 36px;
  text-align: center;
}
</style>
