<template>
  <el-row id="myeditor-div">
    <el-col :span="6">
      <el-card v-if="note.userId==userId" class="box-card">
        <div class="text item">
          <el-form
            :model="note"
            :rules="rules"
            ref="noteForm"
            label-width="100px"
            class="demo-ruleForm"
            size="small"
          >
            <el-form-item label="笔记名称" prop="title">
              <el-input v-model="note.title"></el-input>
            </el-form-item>

            <!-- 笔记属性 -->
            <el-form-item label="笔记属性">
              <el-radio-group v-model="note.noteState">
                <el-radio label="2">私有</el-radio>
                <el-radio label="0">免费分享</el-radio>
                <el-radio label="1">收费分享</el-radio>
              </el-radio-group>
            </el-form-item>
            
            <!-- 售价 -->
            <el-form-item v-if="note.noteState == 1" prop="price">
              <el-input v-model.trim="note.price" placeholder="请输入金额">
                <template slot="append">元</template>
              </el-input>
            </el-form-item>

            <!-- 笔记封面 -->
            <el-form-item label="笔记封面">
              <el-upload
                class="upload-demo"
                ref="upload"
                :headers="headerObj"
                action="http://8.130.37.232:8089/upload/up"
                list-type="picture"
                :auto-upload="false"
                :file-list="notePic"
                :limit="1"
              >
                <el-button size="small" type="primary">点击上传</el-button>
              </el-upload>
            </el-form-item>
            <!-- 笔记简介 -->
            <el-form-item label="笔记简介">
              <el-input
                type="textarea"
                placeholder="请输入内容"
                v-model="note.noteIntro"
                maxlength="100"
                show-word-limit
              >
              </el-input>
            </el-form-item>

            <el-form-item>
              <el-button type="primary" v-if="!flagEndale" @click="enableEditor">修改笔记</el-button>
              <el-button type="primary" v-if="flagEndale" @click="enableEditor">不做修改</el-button>
              <el-button @click="updateNote">保存笔记</el-button>
            </el-form-item>
          </el-form>
        </div>
      </el-card>

    </el-col>
    <el-col :span="5" v-if="note.userId!=userId">
      <el-row type="flex" class="row-bg" justify="end">
      <el-card class="box-card">
        <!-- 点赞 -->
        <i class="el-icon-thumb" @click="likeNote" :class="isLike" style="font-size: 30px"></i><span>{{countLike}}</span>
        <br>

        <i class="el-icon-star-off" style="font-size: 30px"></i>
      </el-card>
      </el-row>

    </el-col>

    <!-- 富文本编辑区 -->
    <el-col :span="16">
      <div id="editor-div">
        <!-- style="border: 1px solid #ccc" -->
        <div >
          <Toolbar
            v-show="flagEndale"
            style="border-bottom: 1px solid #ccc"
            :editor="editor"
            :defaultConfig="toolbarConfig"
            :mode="mode"
          />
          <Editor
            style="overflow-y: hidden"
            v-model="note.content"
            :defaultConfig="editorConfig"
            :mode="mode"
            @onCreated="onCreated"
          />
        </div>
      </div>
    </el-col>
    <!-- 二维码 -->
    <el-col :span="16" :offset="8" id="charge_div" v-if="!isBuy">
      <h3 style="color:#F56C6C">这是收费笔记，只能查看50%的内容，请购买后查看完整笔记哦~</h3>
      <br>
      
      <div v-if="buyig">
        <div class="qrcode" ref="qrCodeUrl"></div>
        <br>
        <p style="margin-left: 82px;color:green"><b>请用微信扫码完成支付哦~~</b></p>
      </div>

      <br>
      <div v-if="!isBuy">
        <span>《{{note.title}}》 </span><span style="color:red"><b>{{note.price}}￥</b></span>
        <!-- <br>
        <br> -->
       <el-button type="success" size="mini" style="margin-left: 36px;" @click="buyNote">购买</el-button> 
      </div>

    </el-col>
  </el-row>
</template>

<script>
import Vue from "vue";
import { Editor, Toolbar } from "@wangeditor/editor-for-vue";
import QRCode from 'qrcodejs2'

export default Vue.extend({
  name: "LookAndEditorNote",
  components: { Editor, Toolbar },
  data() {
    var checkPrice = (rule, value, callback) => {
          if (!value) { 
            return callback(new Error('金额不能为空'));
          }
          let perice = Number(value)
          setTimeout(() => {
            if (Number.isNaN(perice)) {
              callback(new Error('请输入正确的金额'));
            }else{
              callback();
            }
          }, 500);
        };
    return {
      editor: null,
      html: "",
      toolbarConfig: {},
      editorConfig: {
         placeholder: "加载中...",
         MENU_CONF: {
          'uploadImage': {
            // 上传图片的配置
              server: 'http://8.130.37.232:8089/upload/image',
              fieldName: 'file',
                  // 上传错误，或者触发 timeout 超时
              onError(file, err, res) {
                  alert("图片上传出错~")
              },
          }
        }
       },
      mode: "default", // or 'simple'
      flagEndale: false,
      // ----------------------------------------------
      note: {
        noteId: "",
        userId:"",
        title: "",
        notePicture: "",
        noteIntro: "",
        content: "",
        createTime: "",
        updateTime: "",
        noteState: "",
        price: "",
        readTotal: "",
      },
      headerObj: {
        noteId: "",
      },
      inputPrice: "",
      notePic: [{name: '笔记封面', url: ''}],

      rules: {
        title: [
          { required: true, message: "请输入笔记名称", trigger: "blur" },
          {
            min: 2,
            max: 30,
            message: "长度在 2 到 30 个字符",
            trigger: "blur",
          },
        ],
        price: [
          { validator: checkPrice, trigger: 'blur' }
        ],
      },
      userId: JSON.parse(localStorage.getItem("user01")).userId,
      countLike:"",
      // 动态绑定样式
      isLike:{
        bg_color:false
      },

      // 标记是否已经购买笔记
      isBuy:false,
      // 标记是否购买成功
      buy_ok:false,
      //正在购买
      buyig:false,
      // 二维码Url
      payUrl:"",
      // 购买笔记的订单号
      orderID:"",

    };
  },

  computed:{
    checkBuy:{
      get(){
      if(this.note.noteState=="1"){
        return true
      }else{
        return false
      }        
      }
    }
  },

  methods: {
    onCreated(editor) {
      this.editor = Object.seal(editor); // 一定要用 Object.seal() ，否则会报错
    },

    // 获取笔记内容
    getNote() {
      this.$axios({
        method: "GET",
        url: "/notes/getNote",
        params: {
          noteId: this.headerObj.noteId,
          userId: JSON.parse(localStorage.getItem("user01")).userId,
        },
      }).then((res) => {
        if (res.data.code == 10000) {
          this.isBuy = true
          this.note = res.data.data;
          this.notePic[0].url = this.note.notePicture

          // 收费笔记，检查是否已经购买
        }else if(res.data.code == 10011){
          this.isBuy = false
          this.note = res.data.data;
          this.checkBuyNot()
        }
         else {
          this.$message.error("查询笔记出错");
        }
      });
    },
// 检查是否购买了该笔记
    checkBuyNot(){
        this.$axios({
        method: "GET",
        url: "/buy-note/check_buyNote",
        params: {
          noteId: this.headerObj.noteId,
          userId: JSON.parse(localStorage.getItem("user01")).userId,
        },
      }).then( res => {
          if(res.data.code == 10000){
            this.isBuy = true
            this.readVipNote()
          }else{
            this.isBuy = false
          }
      })
    },

    readVipNote(){
      this.$axios({
        method: "GET",
        url: "/buy-note/readVipNote",
        params: {
          noteId: this.headerObj.noteId,
        },
      }).then( res => {
        if (res.data.code == 10000) {
          this.note = res.data.data;
        }
        })
    },

    // 编辑器可修改和不可修改之间切换
    enableEditor() {
      const editor = this.editor; // 获取 editor 实例
      if (editor == null) return;
      if (this.flagEndale) {
        editor.disable();
        this.flagEndale = false;
      } else {
        editor.enable();
        this.flagEndale = true;
      }
    },

    // 修改笔记
      updateNote() {
      this.$axios({
        method: "POST",
        url: "/notes/update-note",
        data: {
          ...this.note
        },
      }).then((res) => {
        if(res.data.code==10000){
          this.headerObj.noteId=this.note.noteId
          this.$refs.upload.submit() 
          this.$message({
          message: '恭喜你，笔记保存成功',
          type: 'success'
        });
        }else{
          this.$message.error("保存失败");          
        }
      })
    },

    // 获取点赞数
    getLike(){
        this.$axios({
        method: "GET",
        url: "/like-note/getLike",
        params: {
          noteId: this.headerObj.noteId,
        },
      }).then(res => {
        if (res.data.code == 10000) {
          this.countLike = res.data.data;
        } else {
          this.$message.error("查询出错");
        }
      });

    },

    // 检测是否点过赞了
    checkLike(){
      this.$axios({
        method:'GET',
        url:"/like-note/checkLike",
        params:{
          noteId: this.headerObj.noteId,
          userId: JSON.parse(localStorage.getItem("user01")).userId
        }
      }).then(res=>{
        if(res.data.code==10000){
          this.isLike.bg_color=true
        }else{
          this.isLike.bg_color=false
        }
      })

    },

    // 给笔记点赞或取消点赞
    likeNote(){
      if(this.isLike.bg_color===false){
        this.$axios({
          method:'GET',
          url:"/like-note/setLikeNote",
          params:{
            noteId: this.headerObj.noteId,
            userId: JSON.parse(localStorage.getItem("user01")).userId
          }
        }).then(res=>{
          if(res.data.code==10000){
            this.isLike.bg_color = true
            this.getLike()
          }
        })
      }else{
          this.$axios({
          method:'GET',
          url:"/like-note/deleteLike",
          params:{
            noteId: this.headerObj.noteId,
            userId: JSON.parse(localStorage.getItem("user01")).userId
          }
        }).then(res=>{
          if(res.data.code==10000){
            this.isLike.bg_color = false
            this.getLike()
          }
        })
      }
    },
    creatQrCode() {
      setTimeout(() => {
      var qrcode = new QRCode(this.$refs.qrCodeUrl, {
      text: this.payUrl, // 需要转换为二维码的内容
      width: 160,
      height: 160,
      colorDark: '#000000',
      colorLight: '#ffffff',
      correctLevel: QRCode.CorrectLevel.H
      })
　　　}, 0)
    },

// 建立websocket连接
    getMyWebsocket(){
      var webSocketUrl = "ws://8.130.37.232:8089/webSocket/"+ this.orderID;
      var websocket = new WebSocket( webSocketUrl );
      //只要后端通过websocket向此连接发消息就会触发onmessage事件
      websocket.onmessage = (event)=> {
         this.$message({
          message: event.data,
          type: 'success'
        });
        this.isBuy = true
        this.readVipNote()
        //修改余额（当然此方式不好QAQ)
        this.setBalance()
      }

    },

// 购买笔记
    buyNote(){
      this.$axios({
        method:'POST',
        url:"/buy-note/buy",
        params:{
          noteName:this.note.title,
          price:this.note.price
        },
        data:{
          noteId: this.headerObj.noteId,
          userId: JSON.parse(localStorage.getItem('user01')).userId
        }
      }).then( res =>{
        if(res.data.code == 10000){
          this.payUrl = res.data.data.code_url
          this.orderID = res.data.data.orderId
          this.buyig = true
          this.creatQrCode() 
          // 生成二维码后与后端的websocket服务器进行连接
          this.getMyWebsocket()     
        }
      })
    },

    setBalance(){
        this.$axios({
        method:'POST',
        url:"/buy-note/set_balance",
        data:{
          userId: this.note.userId,
          price: this.note.price
        }
      }).then(res=>{
        if(res.data.code==10000){
          console.log("修改余额成功~");
        }else{
          console.log("修改余额失败~");
        }
      })
    },

  },

  mounted() {
    //获取路由传过来的笔记ID
    this.headerObj.noteId = this.$route.params.id;
    this.getNote();
    //页面挂载完毕 然后禁止编辑
    setTimeout(() => {
      const editor = this.editor; // 获取 editor 实例
      if (editor == null) return;
      editor.disable();
    }, 500);
    //获取点赞总数
    this.getLike()
    // 检测是否已经点赞了
    this.checkLike()

  },

  beforeDestroy() {
    const editor = this.editor;
    if (editor == null) return;
    editor.destroy(); // 组件销毁时，及时销毁编辑器
  },
});
</script>

<style scoped>
#myeditor-div {
  padding-top: 80px;
}
#editor-div {
  margin-top: 20px;
  margin-right: 20px;
}
.box-card {
  margin-top: 20px;
  margin-left: 30px;
  margin-right: 20px;
}
.w-e-full-screen-container {
  top: 60px;
}

/* 上传封面 */
.avatar-uploader .el-upload {
  border: 1px dashed #39a0e9;
  border-radius: 6px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
}
.avatar-uploader .el-upload:hover {
  border-color: #409eff;
}
.avatar-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  width: 178px;
  height: 178px;
  line-height: 178px;
  text-align: center;
}
.avatar {
  width: 178px;
  height: 178px;
  display: block;
}
.bg_color{
  color: crimson;
}
#charge_div{
  margin-top: 10px;
}
.qrcode{
  width: 160px;
  height: 160px;
  overflow: hidden;
  margin-left: 90px;
}
#buyok{
  width: 326px;
  height: 326px;
}
</style>

<style src="@wangeditor/editor/dist/css/style.css"></style>
