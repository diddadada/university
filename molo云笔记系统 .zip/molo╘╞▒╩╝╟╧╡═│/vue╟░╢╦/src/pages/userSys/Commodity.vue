<template>
  <el-row id="found-page">
    <el-col class="found-div" :span="20" :offset="2">
      <el-col :span="22" :offset="1">
        <h3 id="swzl">云端小卖场</h3>
      </el-col>
      <el-col :span="24">
        <el-row>
          <el-col
            :span="4"
            v-for="info in information"
            :key="info.infoId"
            :offset="1"
            id="lostgoods"
          >
            <el-card :body-style="{ padding: '0px' }">
                <el-image
                    style="width: 100px; height: 100px"
                    :src="info.infoPicture"
                    fit="scale-down">
                </el-image>
              <div style="padding: 14px">
                <span><b>标题：{{ info.infoName }}</b></span>
                <p>描述：<span style="color:rgb(120, 120, 120);font-size: 13px">{{ info.infoDesc }}</span></p>
                <p>价格：<span style="color:red">{{ info.infoPrice }}</span></p>
                <br>
                <el-button size="mini" type="primary" @click="Infodetils(info.infoId)">详情</el-button>
                <el-button size="mini" type="success" @click="showDialog(info)">购买</el-button>

              </div>
            </el-card>
          </el-col>

          <el-dialog
            title="请确认信息"
            :visible.sync="dialogVisible"
            width="30%"
            >

            <div class="buy_div">
              <p>商品名称：{{info.infoName}}</p>
              <p>商品简介：{{info.infoDesc}}</p>
              <p>价格：<strong style="color:red">{{info.infoPrice}}￥</strong></p>
              数量：<el-input-number size="mini" v-model="num" :min="1"></el-input-number>
              <hr>
              <br>
              <h4>请填写信息</h4>
              <p>姓名：{{user.nickname}}</p>
              <el-form :model="userForm" ref="userForm2" label-width="79px" size="mini" >
                <el-form-item 
                  label="联系电话"
                  prop="phone"
                  :rules="[
                    { required: true, message: '联系电话不能为空'},
                  ]"
                >
                <el-input v-model="userForm.phone"></el-input>
                </el-form-item>
                <el-form-item
                  label="收货地址"
                  prop="address"
                  :rules="[
                    { required: true, message: '收货地址不能为空'},
                  ]"
                >
                  <el-input v-model="userForm.address"></el-input>
                </el-form-item>
              </el-form>        
            </div>
            <span slot="footer" class="dialog-footer">
              <el-button @click="dialogVisible = false">取 消</el-button>
              <el-button type="primary" @click="buyInfo('userForm2',info)">确 定</el-button>
            </span>
          </el-dialog>

        </el-row>
      </el-col>
    </el-col>
  </el-row>
</template>

<script>
export default {
  name: "Commodity",
  data() {
    return {
      information: [
        {
          infoId: "1",
          infoName: "2",
          userId: "10086",
          infoDesc: "sss",
          infoPicture: "",
          infoPrice: "202",
        },
      ],

      info:{},
      num:1,

      userForm:{
        address: "",
        phone: "",
      },
      user: JSON.parse(localStorage.getItem("user01")),
      dialogVisible: false,


    };
  },
  methods: {
    getInformation() {
      this.$axios({
        method: "GET",
        url: "/information-note/get-information",
      }).then((res) => {
        if (res.data.code == 10000) {
          this.information = res.data.data;
        } else {
          this.$message({
          showClose: true,
          message: '查询出错',
          type: 'error'
        });
        }
      });
    },

    Infodetils(infoId){
      this.$router.push({
        path:"/commodity-details",
        query:{
          infoId:infoId
        }
      })
    },
    showDialog(info_01){
      this.info = info_01
      this.dialogVisible =true

    },

    buyInfo(formName,info){
      this.$refs[formName].validate((valid) => {
        if (valid) {
          this.$axios({
            url:"/order-info/buyGoods",
            method:"POST",
            data:{
              goodsId:info.infoId,
              userId: this.user.userId,
              price: info.infoPrice,
              count: this.num,
              address: this.userForm.address,
              seller: info.userId,
              name: this.user.nickname,
              synopsis: info.infoName,
              contactWay: this.userForm.phone,
              pic: info.infoPicture

            }
          }).then(res =>{
            if(res.data.code == 10000){
              this.$message.success("购买成功！")
              this.dialogVisible = false
            }else{
              this.$message.error(res.data.msg)
            }
          })
        } else {
          console.log('error submit!!');
          return false;
        }
      });

      
    },

  },
  mounted() {
    this.getInformation()
  },
};
</script>

<style>
#found-page {
  padding-top: 77px;
}

.found-div {
  padding-top: 16px;
  background-color: white;
}
#swzl {
  padding-bottom: 3px;
  margin-bottom: 10px;
  border-bottom: 1px solid;
}
#lostgoods {
  margin-bottom: 19px;
}
</style>