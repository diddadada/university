<template>
  <el-row id="found-page">
    <el-col class="found-div" :span="20" :offset="2">
      <el-col :span="20" :offset="1">
        <h3 id="swzl">失物招领公告栏</h3>
      </el-col>
      <el-col :span="2" id="swzl2"
        ><span @click="dialogFormVisible = true">发布公告</span></el-col
      >
      <el-col :span="24">
        <el-row>
          <el-col
            :span="4"
            v-for="good in GoodsData"
            :key="good.lostGoodsId"
            :offset="1"
            id="lostgoods"
          >
            <el-card :body-style="{ padding: '0px' }">
              <img :src="good.pic" class="image" />
              <div style="padding: 14px">
                <span
                  ><b>标题：{{ good.title }}</b></span
                >
                <p>描述:{{ good.synopsis }}</p>
                <p>电话:{{ good.telephone }}</p>
                <p>时间:{{ good.createdTime.slice(0, 10) }}</p>
                <br />
                <el-button
                  v-if="good.userId == userId"
                  type="primary"
                  size="mini"
                  style="margin-right: 10px"
                  @click="updateLostGoodsButton(good.lostGoodsId)"
                  >修改公告</el-button
                >

                <el-popconfirm
                  v-if="good.userId == userId"
                  @confirm="deleteLostGoods(good.lostGoodsId)"
                  title="确定要将该公告删除吗？"
                >
                  <el-button type="danger" size="mini" slot="reference"
                    >删除公告</el-button
                  >
                </el-popconfirm>
              </div>
            </el-card>
          </el-col>
        </el-row>
      </el-col>
    </el-col>

    <el-col :span="2">
      <el-dialog title="发布失物招领公告" :visible.sync="dialogFormVisible">
        <el-form :model="Form01" label-position="right">
          <el-form-item label="标题" :label-width="formLabelWidth">
            <el-input v-model="Form01.title"
                      maxlength="50"
                      show-word-limit 
            ></el-input>
          </el-form-item>
          <el-form-item label="联系电话" :label-width="formLabelWidth">
            <el-input v-model="Form01.telephone"
                      maxlength="20"
                      show-word-limit
            ></el-input>
          </el-form-item>
          <el-form-item label="物品描述" :label-width="formLabelWidth">
            <el-input
              type="textarea"
              :rows="2"
              placeholder="请输入内容"
              v-model="Form01.synopsis"
              maxlength="1000"
              show-word-limit
            >
            </el-input>
          </el-form-item>

          <el-form-item label="时间" :label-width="formLabelWidth">
            <el-date-picker
              v-model="Form01.createdTime"
              type="date"
              placeholder="选择日期"
            >
            </el-date-picker>
          </el-form-item>

          <el-row>
            <el-col :span="3" :offset="2"
              >封面图片：<br /><br /><br /><br
            /></el-col>
            <el-col :span="6" :offset="1">
              <el-upload
                class="avatar-uploader"
                ref="uploadLostGoodsPic"
                :headers="headerObj"
                action="http://8.130.37.232:8089/lost-goods/setLostGoodsPic"
                :file-list="filePic"
                list-type="picture"
                :auto-upload="false"
              >
                <img
                  v-if="!filePic"
                  :src="Form01.pic"
                  class="avatar"
                  width="100"
                />
                <i v-else class="el-icon-plus avatar-uploader-icon"></i>
              </el-upload>
            </el-col>
            <el-col :span="4" :offset="1" v-if="Form01.pic"
              >点击图片进行更换</el-col
            >
          </el-row>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button @click="dialogFormVisible = false">取 消</el-button>
          <el-button type="primary" @click="announce">确 定</el-button>
        </div>
      </el-dialog>
    </el-col>
    <el-col :span="2">
      <el-dialog title="修改失物招领公告" :visible.sync="goodsFormVisible">
        <el-form :model="goods" label-position="right">
          <el-form-item label="标题" :label-width="formLabelWidth">
            <el-input v-model="goods.title"
                      maxlength="50"
                      show-word-limit 
             ></el-input>
          </el-form-item>
          <el-form-item label="联系电话" :label-width="formLabelWidth">
            <el-input v-model="goods.telephone" 
                      maxlength="20"
                      show-word-limit 
            ></el-input>
          </el-form-item>
          <el-form-item label="物品描述" :label-width="formLabelWidth">
            <el-input
              type="textarea"
              :rows="2"
              placeholder="请输入内容"
              v-model="goods.synopsis"
              maxlength="1000"
              show-word-limit 
            >
            </el-input>
          </el-form-item>

          <el-form-item label="时间" :label-width="formLabelWidth">
            <el-date-picker
              v-model="goods.createdTime"
              type="date"
              placeholder="选择日期"
            >
            </el-date-picker>
          </el-form-item>

          <el-row>
            <el-col :span="3" :offset="2"
              >封面图片：<br /><br /><br /><br
            /></el-col>
            <el-col :span="6" :offset="1">
          <el-upload
            class="avatar-uploader"
            ref="uploadLostGoods"
            :headers="headerObj"
            action="http://8.130.37.232:8089/lost-goods/setLostGoodsPic"
            :show-file-list="false"
            :on-success="handleAvatarSuccess"
          >
            <img v-if="goods.pic" :src="goods.pic" class="avatar" width="100" />
            <i v-else class="el-icon-plus avatar-uploader-icon"></i>
          </el-upload>

            </el-col>
            <el-col :span="4" :offset="1" v-if="goods.pic"
              >点击图片进行更换</el-col
            >
          </el-row>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button @click="goodsFormVisible = false">取 消</el-button>
          <el-button type="primary" @click="updateLostGoods()">保 存</el-button>
        </div>
      </el-dialog>
    </el-col>
  </el-row>
</template>

<script>
export default {
  name: "FoundPage",
  data() {
    return {
      GoodsData: [
        {
          lostGoodsId: "",
          userId: "",
          telephone: "",
          synopsis: "",
          pic: "",
          createdTime: "",
          title: "",
        },
      ],
      Form01: {
        lostGoodsId: "",
        userId: JSON.parse(localStorage.getItem("user01")).userId,
        telephone: "",
        synopsis: "",
        pic: "",
        createdTime: "",
        title: "",
      },
      goods: {
        lostGoodsId: "",
        userId: "",
        telephone: "",
        synopsis: "",
        pic: "",
        createdTime: "",
        title: "",
      },
      formLabelWidth: "120px",
      dialogFormVisible: false,
      goodsFormVisible: false,
      filePic: [],
      headerObj: {
        lostGoodsId: "",
      },
      userId: JSON.parse(localStorage.getItem("user01")).userId,
    };
  },

  methods: {
    getGoodsList() {
      this.$axios({
        method: "GET",
        url: "/lost-goods/getLostGoodsList",
      }).then((res) => {
        if (res.data.code == 10000) {
          this.GoodsData = res.data.data;
        } else {
          this.$message.error("保存失败");
        }
      });
    },
    announce() {
      this.dialogFormVisible = false;
      this.$axios({
        method: "POST",
        url: "/lost-goods/setLostGoods",
        data: {
          ...this.Form01,
        },
      }).then((res) => {
        if (res.data.code == 10000) {
          this.headerObj.lostGoodsId = res.data.data;
          this.$refs.uploadLostGoodsPic.submit();
          this.$message({
            message: res.data.msg,
            type: "success",
          });
          this.getGoodsList()
        } else {
          this.$message({
            showClose: true,
            message: "发布出错~",
            type: "error",
          });
        }
      });
    },
    deleteLostGoods(lostGoodsId) {
      this.$axios({
        method: "GET",
        url: "/lost-goods/deleteLostGoods",
        params: {
          lostGoodsId,
        },
      }).then((res) => {
        if (res.data.code == 10000) {
          this.$message({
            message: "删除失物招领成功~",
            type: "success",
          });
          this.getGoodsList();
        } else {
          this.$message({
            showClose: true,
            message: "删除失败~",
            type: "error",
          });
        }
      });
    },
    // 将数据筛选出来，显示在对话框上
    updateLostGoodsButton(lostGoodsId) {
      this.goodsFormVisible = true;
      let obj = this.GoodsData.find( e =>{
        return e.lostGoodsId==lostGoodsId
      })
      this.goods = obj
      this.headerObj.lostGoodsId = obj.lostGoodsId
    },
    updateLostGoods(){
      this.goodsFormVisible = false;
      // 发送修改的请求到后端
      this.$axios({
        method: "POST",
        url: "/lost-goods/updateLostGoods",
        data: {
          ...this.goods
        },
      }).then((res) => {
        if(res.data.code == 10000){
            this.$message({
            message: "修改成功~",
            type: "success",
          });
        }else{
            this.$message({
            showClose: true,
            message: "修改失败~",
            type: "error",
          });
        }
      }).catch(res=>{
          this.$message({
          showClose: true,
          message: "出错啦~",
          type: "error",
          });
      });
    },
    handleAvatarSuccess(res, file) {
      this.goods.pic = URL.createObjectURL(file.raw);
    },
  },
  mounted() {
    this.getGoodsList();
  },
};
</script>

<style scoped>
#found-page {
  padding-top: 77px;
}
.image {
  width: 100%;
  display: block;
}
.found-div {
  padding-top: 16px;
  background-color: white;
}
#swzl {
  padding-bottom: 3px;
  margin-bottom: 10px;
  border-bottom: 1px solid;
}
#lostgoods {
  margin-bottom: 19px;
  /* margin-left: 9px; */
}
#swzl2 {
  font-weight: 600;
  padding-left: 32px;
  padding-bottom: 7px;
  border-bottom: 1px solid;
}
</style>