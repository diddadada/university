<template>
  <el-row id="found-page">
    <el-col class="found-div" :span="20" :offset="2">
      <el-col :span="22" :offset="1">
        <el-container>
          <el-aside width="120px">
            <el-image
              style="width: 100px; height: 100px"
              :src="user.photo"
              fit="scale-down"
            >
            </el-image>
          </el-aside>
          <el-main>
            <el-row>
              <el-col :span="8" class="yhxx">
                <p>用户名：{{ user.nickname }}</p>
                <p>云笔记账号：{{ user.account }}</p>
                <el-col :span="11" > 账户余额：<span style="color:red">{{ user.balance }}</span> </el-col>
                <el-col :span="2" :offset="1"
                  ><el-button type="success" size="mini" id="tixian"
                    >提现</el-button
                  ></el-col
                >
              </el-col>

              <el-col :span="12">
                <el-button type="primary" @click="dialogFormVisible = true"
                  >上架新的实体资料</el-button
                >
              </el-col>

              <el-dialog
                title="上架新实体资料"
                :visible.sync="dialogFormVisible"
              >
                <el-form :model="form" :rules="rules" ref="publish" label-position="right">
                  <el-form-item label="标题" prop="infoName" :label-width="formLabelWidth">
                    <el-input
                      v-model="form.infoName"
                      maxlength="20"
                      show-word-limit
                    ></el-input>
                  </el-form-item>
                  <el-form-item label="物品描述" :label-width="formLabelWidth">
                    <el-input
                      type="textarea"
                      :rows="2"
                      placeholder="请输入内容"
                      v-model="form.infoDesc"
                      maxlength="1000"
                      show-word-limit
                    >
                    </el-input>
                  </el-form-item>
                  <el-form-item label="价格" prop="infoPrice" :label-width="formLabelWidth">
                    <el-input
                      v-model="form.infoPrice"
                      autocomplete="off"
                    ></el-input>
                  </el-form-item>
                  <el-form-item label="库存量" :label-width="formLabelWidth">
                    <el-input-number size="mini" v-model="form.count" :min="1"></el-input-number>
                  </el-form-item>

                  <el-row>
                    <el-col :span="3" :offset="2"
                      >封面图片：<br /><br /><br /><br
                    /></el-col>
                    <el-col :span="6" :offset="1">
                      <el-upload
                        class="avatar-uploader"
                        ref="uploadPic"
                        :headers="headerObj"
                        action="http://8.130.37.232:8089/information-note/publishCommodityPic"
                        :file-list="filePic"
                        list-type="picture"
                        :auto-upload="false"
                      >
                        <img
                          v-if="!filePic"
                          :src="form.infoPicture"
                          class="avatar"
                          width="100"
                        />
                        <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                      </el-upload>
                    </el-col>
                    <el-col :span="4" :offset="1" v-if="form.infoPicture"
                      >点击图片进行更换</el-col
                    >
                  </el-row>
                  <el-row>
                    <el-col :span="22" :offset="2"> 更多详情图片： </el-col>
                    <el-col :span="14" :offset="2">
                      <br />
                      <el-upload
                        class="upload-demo"
                        multiple
                        ref="uploadPicList"
                        :headers="headerObj"
                        action="http://8.130.37.232:8089/information-note/savePicList"
                        :on-success = "successUpload"
                        :on-change = "uploadChange"
                        :file-list="pic_List"
                        list-type="picture"
                        :auto-upload="false"
                      >
                        <el-button size="small" type="primary"
                          >点击上传</el-button
                        >
                        <div slot="tip" class="el-upload__tip">
                          只能上传jpg/png文件，且不超过500kb
                        </div>
                      </el-upload>
                    </el-col>
                  </el-row>
                </el-form>
                <div slot="footer" class="dialog-footer">
                  <el-button @click="dialogFormVisible = false"
                    >取 消</el-button
                  >
                  <el-button type="primary" @click="publishCommodtiy('publish')"
                    >确 定</el-button
                  >
                </div>
              </el-dialog>

              <!-- 修改实体资料信息 -->
              <el-dialog
                title="修改实体资料信息"
                :visible.sync="upInfoVisible"
              >
                <el-form :model="upInfoObj" :rules="rules" ref="puInfo" label-position="right">
                  <el-form-item label="标题" prop="infoName" :label-width="formLabelWidth">
                    <el-input
                      v-model="upInfoObj.infoName"
                      maxlength="20"
                      show-word-limit
                    ></el-input>
                  </el-form-item>
                  <el-form-item label="物品描述" :label-width="formLabelWidth">
                    <el-input
                      type="textarea"
                      :rows="2"
                      placeholder="请输入内容"
                      v-model="upInfoObj.infoDesc"
                      maxlength="1000"
                      show-word-limit
                    >
                    </el-input>
                  </el-form-item>
                  <el-form-item label="价格" prop="infoPrice" :label-width="formLabelWidth">
                    <el-input
                      v-model="upInfoObj.infoPrice"
                      autocomplete="off"
                    ></el-input>
                  </el-form-item>
                  <el-form-item label="库存量" :label-width="formLabelWidth">
                    <el-input-number size="mini" v-model="upInfoObj.count" :min="1"></el-input-number>
                  </el-form-item>

                  <el-row>
                    <el-col :span="3" :offset="2"
                      >封面图片：<br /><br /><br /><br
                    /></el-col>
                    <el-col :span="6" :offset="1">
                      <el-upload
                        class="avatar-uploader"
                        ref="upPic"
                        :headers="headerObj"
                        action="http://8.130.37.232:8089/information-note/publishCommodityPic"
                        :file-list="filePic"
                        list-type="picture"
                        :auto-upload="false"
                      >
                        <img
                          v-if="upInfoObj.infoPicture"
                          :src="upInfoObj.infoPicture"
                          class="avatar"
                        />
                        <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                      </el-upload>
                    </el-col>
                    <el-col :span="4" :offset="1" v-if="upInfoObj.infoPicture"
                      >点击图片进行更换</el-col
                    >
                  </el-row>
                  <el-row>
                    <el-col :span="22" :offset="2"> 更多详情图片： </el-col>
                    <el-col :span="14" :offset="2">
                      <br />
                      <el-upload
                        class="upload-demo"
                        multiple
                        ref="upPicList"
                        :headers="headerObj"
                        action="http://8.130.37.232:8089/information-note/savePicList"
                        :on-success="upSuccess"
                        :on-remove="removePic"
                        :file-list="pic_List"
                        list-type="picture"
                        :auto-upload="false"
                      >
                        <el-button size="small" type="primary"
                          >点击上传</el-button
                        >
                        <div slot="tip" class="el-upload__tip">
                          只能上传jpg/png文件,点击X删除图片
                        </div>
                      </el-upload>
                    </el-col>
                  </el-row>
                </el-form>
                <div slot="footer" class="dialog-footer">
                  <el-button @click="upInfoVisible = false">取 消</el-button>
                  <el-button type="primary" @click="upCommodtiy('puInfo')">确 定</el-button>
                </div>
              </el-dialog>
            </el-row>
          </el-main>
        </el-container>
      </el-col>

      <el-col :span="23" :offset="1">
        <br />
        <h3 id="swzl">我的商品</h3>
      </el-col>
      <el-col :span="24">
        <el-row>
          <el-col
            :span="4"
            v-for="info in information"
            :key="info.infoId"
            :offset="1"
            id="lostgoods"
          >
            <el-card :body-style="{ padding: '0px' }">
              <el-image
                style="width: 100px; height: 100px"
                :src="info.infoPicture"
                fit="scale-down"
              >
              </el-image>
              <div style="padding: 14px">
                <span
                  ><b>标题：{{ info.infoName }}</b></span
                >
                <p>
                  描述：<span
                    style="color: rgb(120, 120, 120); font-size: 13px"
                    >{{ info.infoDesc }}</span
                  >
                </p>
                <p>
                  价格：<span style="color: red">{{ info.infoPrice }}</span>
                </p>
                <br />
                <el-button 
                size="mini" 
                type="primary" 
                style="margin-right: 30px"
                @click="getInformationDetails(info.infoId)"
                  >修改</el-button>
                <el-popconfirm
                  @confirm="deleteInfo(info.infoId)"
                  title="下架会将该商品的资料删除，前定要下架吗？"
                >
                  <el-button size="mini" type="success" slot="reference"
                    >下架</el-button
                  >
                </el-popconfirm>
              </div>
            </el-card>
          </el-col>
        </el-row>
      </el-col>
    </el-col>
  </el-row>
</template>

<script>
export default {
  name: "PublishCommodity",
  data() {
      var checkPrice = (rule, value, callback) => {
        if (!value) { 
          return callback(new Error('金额不能为空'));
        }
        let perice = Number(value)
        setTimeout(() => {
          if (Number.isNaN(perice)) {
            callback(new Error('请输入正确的金额'));
          }else{
            callback();
          }
        }, 500);
      };
    return {
      information: [
        {
          infoId: "",
          infoName: "",
          userId: "",
          infoDesc: "",
          infoPicture: "",
          infoPrice: "",
          count:1,
        },
      ],
      user: JSON.parse(localStorage.getItem("user01")),
      formLabelWidth: "120px",
      dialogFormVisible: false,
      upInfoVisible: false,
      form: {
        infoName: "",
        infoDesc: "",
        infoPicture: "",
        infoPrice: "",
        count:1,
      },
      headerObj: {
        infoId: "",
      },
      pic_List: [],
      filePic: [],
      isUpload:[],
      uploadSuccess:false,
      rules: {
        infoName: [
          { required: true, message: "请输入商品名称", trigger: "blur" },
          {
            min: 2,
            max: 30,
            message: "长度在 2 到 30 个字符",
            trigger: "blur",
          },
        ],
        infoPrice: [
          { required: true, validator: checkPrice, trigger: 'blur' }
        ],
      },
      upInfoObj:{
          infoId: "",
          infoName: "",
          userId: "",
          infoDesc: "",
          infoPicture: "",
          infoPrice: "",
          count:1,
      },
    };
  },
  methods: {
    getInformation() {
      this.$axios({
        method: "GET",
        url: "/information-note/get-Myinformation",
        params: {
          userId: this.user.userId,
        },
      }).then((res) => {
        if (res.data.code == 10000) {
          this.information = res.data.data;
        } else {
          this.$message({
            showClose: true,
            message: "查询出错",
            type: "error",
          });
        }
      });
    },
// 上架新的实体资料
    publishCommodtiy(publish) {
      this.$refs[publish].validate((valid) => {  
          if (valid) {
            this.dialogFormVisible = false;
            this.$axios({
              method: "POST",
              url: "/information-note/publishCommodity",
              data: {
                infoName: this.form.infoName,
                infoDesc: this.form.infoDesc,
                infoPrice: this.form.infoPrice,
                count: this.form.count,
                userId: JSON.parse(localStorage.getItem("user01")).userId,
              },
            }).then((res) => {
              if (res.data.code == 10000) {
                this.headerObj.infoId = res.data.data;
                this.$refs.uploadPic.submit();
                if (this.isUpload.length>0){
                  this.$refs.uploadPicList.submit();
                }
                if(this.uploadSuccess)
                  location.reload();               
                  this.$message({
                    message: "发布商品成功~",
                    type: "success",
                  });
              } else {
                this.$message.error(res.data.msg);
              }
            });
          }else{
            console.log('error submit!!');
            return false;
          }
          })

    },
    deleteInfo(infoId) {
      this.$axios({
        method: "GET",
        url: "/information-note/soldOut",
        params: {
          infoId,
        },
      }).then((res) => {
        if (res.data.code == 10000) {
          this.$message({
            message: "商品下架成功~",
            type: "success",
          });
          this.getInformation();
        } else {
          this.$message({
            showClose: true,
            message: "下架失败~",
            type: "error",
          });
        }
      });
    },
    // 获取个人信息
    getUserInfo(){
      this.$axios({
        method: "GET",
        url: "/users/get-user",
        params: {
          userId: JSON.parse(localStorage.getItem("user01")).userId,
        },
      }).then((res) => {
        if (res.data.code == 10000) {
          this.user = res.data.data;
          this.headerObj.userId = res.data.data.userId
        } else {
          this.$message.error(res.data.msg);
        }
      });
    },
    successUpload(res){
      this.uploadSuccess = true
      
    },
    upSuccess(res){
      this.upInfoVisible = false;
      this.$message.success("修改商品成功")
    },

    uploadChange(file,fileList){
      this.isUpload = fileList
    },

    getInformationDetails(infoId) {
      this.$axios({
        method: "GET",
        url: "/information-note/infoDetails",
        params:{
            infoId
        }
      }).then((res) => {
        if (res.data.code == 10000) {
          this.upInfoObj = res.data.data.informationNote;
          let listPic =  res.data.data.informationPicList
          listPic.forEach(e =>{
            e.url = e.infoPicUrl
          })
          this.pic_List = listPic;

          setTimeout(() => {
            this.upInfoVisible = true
          }, 500);
        } else {
          this.$message({
          showClose: true,
          message: '查询出错',
          type: 'error'
        });
        }
      });
    },
    removePic(file){
      this.$axios({
      method: "GET",
      url: "/information-note/removePic",
      params:{
          picId: file.id
      }
    }).then(res =>{
      if(res.data.code == 10001){
        this.$message.error("删除失败")
      }
    })

    },

    // 修改实体资料信息
    upCommodtiy(refName) {
      this.$refs[refName].validate((valid) => {  
          if (valid) {
            this.$axios({
              method: "POST",
              url: "/information-note/upCommodity",
              data: {
                ...this.upInfoObj
              },
            }).then((res) => {
              if (res.data.code == 10000) {
                this.headerObj.infoId = this.upInfoObj.infoId;
                this.$refs.upPic.submit();
                if (this.$refs.upPicList.uploadFiles.length>0){
                  this.$refs.upPicList.submit();
                }
                  location.reload();               
              } else {
                this.$message.error(res.data.msg);
              }
            });
          }else{
            console.log('error submit!!');
            return false;
          }
          })
    },

  },
  mounted() {
    this.getInformation();
    this.getUserInfo();
  },
};
</script>

<style scoped>
#found-page {
  padding-top: 77px;
}

.found-div {
  padding-top: 26px;
  background-color: white;
}
#swzl {
  padding-bottom: 3px;
  margin-bottom: 10px;
  border-bottom: 1px solid;
}
#lostgoods {
  margin-bottom: 19px;
}
.avatar-uploader .el-upload {
  border: 1px dashed #d9d9d9;
  border-radius: 6px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
}
.avatar-uploader .el-upload:hover {
  border-color: #409eff;
}
.avatar-uploader-icon {
  font-size: 26px;
  color: #8c939d;
  width: 78px;
  height: 30px;
  line-height: 36px;
  text-align: center;
}
.avatar {
  width: 80px;
  height: 100%;
  display: block;
}
.yhxx{
  line-height: 26px;
}
</style>