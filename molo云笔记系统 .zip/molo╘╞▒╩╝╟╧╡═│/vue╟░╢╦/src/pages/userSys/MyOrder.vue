<template>
  <el-row>
    <el-col :span="6" :offset="11" class="myBill"
      ><strong>我 的 账 单</strong></el-col
    >
    <el-col :span="21" :offset="2">
      <el-table
        ref="multipleTable"
        :data="tableData"
        tooltip-effect="dark"
        style="width: 100%"
        @selection-change="handleSelectionChange"
      >
        <el-table-column type="selection" width="55"> </el-table-column>
        <el-table-column label="账单ID" width="80">
          <template slot-scope="scope">{{ scope.row.orderId }}</template>
        </el-table-column>
        <el-table-column label="封 面" width="160">
          <template slot-scope="scope"
            ><img :src="scope.row.pic" width="70" alt=""
          /></template>
        </el-table-column>
        <el-table-column prop="synopsis" label="商品名称" width="190">
        </el-table-column>
        <el-table-column prop="contactWay" label="联系电话" width="160">
        </el-table-column>
        <el-table-column prop="count" label="数量" width="70">
        </el-table-column>
        <el-table-column label="总价" width="90">
          <template slot-scope="scope"><span style="color: red">{{scope.row.price}}</span></template>
        </el-table-column>
        <el-table-column label="时间" width="160">
            <template slot-scope="scope">{{scope.row.createdTime | formatTime}}</template>
        </el-table-column>
        <el-table-column prop="address" label="收货地址" show-overflow-tooltip>
        </el-table-column>
      </el-table>
    </el-col>
    <el-col :span="2" :offset="20">
      <br />
      <el-popconfirm title="您确定要删除这些账单信息吗？" @confirm="deleteBill">
        <el-button slot="reference" type="info" :disabled="isEmpty"
          ><i class="el-icon-delete"></i>&nbsp;删除</el-button
        >
      </el-popconfirm>
    </el-col>
  </el-row>
</template>

<script>
export default {
  data() {
    return {
      tableData: [],
      isEmpty: true,
      selectObj: [],
      picLics: []
    };
  },
  methods: {
    handleSelectionChange(val) {
      this.selectObj = [];
      // 将选中的账单id存起来
      val.forEach((e) => {
        this.selectObj.push(e.orderId);
      });

      if (val.length > 0) {
        this.isEmpty = false;
      } else {
        this.isEmpty = true;
      }
    },
    getMyBill() {
      this.$axios({
        method: "GET",
        url: "/order-info/myOrder",
        params: {
          userId: JSON.parse(localStorage.getItem("user01")).userId,
        },
      }).then((res) => {
        if (res.data.code == 10000) {
          this.tableData = res.data.data;
        } else {
          this.$message.error(res.data.msg);
        }
      });
    },
    deleteBill() {
      this.$axios({
        method: "GET",
        url: "/order-info/delBill",
        params: {
          idList: this.selectObj.toString(),
        },
      }).then((res) => {
        if (res.data.code == 10000) {
          this.getMyBill();
          this.$message.success(res.data.msg);
        } else {
          this.$message.error(res.data.msg);
        }
      });
    },

  },
  mounted() {
    this.getMyBill();
  },

  filters: {
    formatTime(time){
        let str = String(time) || ' '
        return str.substring(0,10)
    },
  }
};
</script>

<style>
.myBill{
    margin-top: 86px;
    margin-bottom: 20px;
    font-size: 18px;
    color: rgb(238, 123, 23);
}
</style>