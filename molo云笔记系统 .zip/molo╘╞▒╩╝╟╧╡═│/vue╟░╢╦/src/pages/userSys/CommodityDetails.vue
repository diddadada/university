<template>
  <el-row id="found-page">
    <el-col class="found-div" :span="20" :offset="2">
      <el-col :span="22" :offset="1">
        <h3 id="swzl">云端小卖场</h3>
      </el-col>
      <el-col :span="6" :offset="11"><strong style="color:red">商品详情</strong></el-col>
      <el-col :span="19" :offset="5" class="sqxq">
        <img width="100" :src="information.infoPicture"></img>
        <p>名称：{{information.infoName}}</p>
        <p>简介：{{information.infoDesc}}</p>
        <p>价格：<strong style="color:red;">{{information.infoPrice}}￥</strong></p>
        <p>库存量：{{information.count}}</p>
        <p>详情图片：</p>
      </el-col>
        <el-row>
            <el-col :span="8" v-for="item in infoPicList" :key="item.id" class="pic">
                 <img width="360" :src="item.infoPicUrl" alt="详情图片">                  
            </el-col>
        </el-row>
    <el-col :span="24" class="button_div">

      <el-popover
        placement="top"
        width="360"
        v-model="visible">
        <h3>请确认信息</h3>
        <hr>
        <br>
        <div class="buy_div">
          <p>商品名称：{{information.infoName}}</p>
          <p>商品简介：{{information.infoDesc}}</p>
          <p>价格：<strong style="color:red">{{information.infoPrice}}￥</strong></p>
          数量：<el-input-number size="mini" v-model="num" :min="1"></el-input-number>
          <hr>
          <br>
          <p>姓名：{{user.nickname}}</p>
          <el-form :model="userForm" ref="userForm" label-width="79px" size="mini" >
            <el-form-item 
              label="联系电话"
              prop="phone"
              :rules="[
                { required: true, message: '联系电话不能为空'},
              ]"
            >
            <el-input v-model="userForm.phone"></el-input>
            </el-form-item>
            <el-form-item
              label="收货地址"
              prop="address"
              :rules="[
                { required: true, message: '收货地址不能为空'},
              ]"
            >
              <el-input v-model="userForm.address"></el-input>
            </el-form-item>
          </el-form>        
        </div>
        <div style="text-align: right; margin: 0">
          <el-button size="mini" type="info" @click="visible = false">取消</el-button>
          <el-button type="primary" size="mini" @click="submitForm('userForm')">确定</el-button>
        </div>
        <el-button type="danger" slot="reference">立即购买</el-button>
      </el-popover>

    </el-col>

    </el-col>

  </el-row>
</template>

<script>
export default {
  data() {
    return {
        user: JSON.parse(localStorage.getItem("user01")),
        information: {
            infoId: "",
            infoName: "",
            userId: "",
            infoDesc: "",
            infoPicture: "",
            infoPrice: "",
            },
        infoPicList:[],
        infoId: this.$route.query.infoId,
        visible: false,
        num:1,

        userForm:{
          address: "",
          phone: "",
        },
    };
  },
  methods: {
    getInformation() {
      this.$axios({
        method: "GET",
        url: "/information-note/infoDetails",
        params:{
            infoId:this.infoId
        }
      }).then((res) => {
        if (res.data.code == 10000) {
          this.information = res.data.data.informationNote;
          this.infoPicList = res.data.data.informationPicList;
        } else {
          this.$message({
          showClose: true,
          message: '查询出错',
          type: 'error'
        });
        }
      });
    },
    submitForm(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          this.$axios({
            url:"/order-info/buyGoods",
            method:"POST",
            data:{
              count: this.num,
              goodsId:this.information.infoId,
              userId: this.user.userId,
              price: this.information.infoPrice,
              address: this.userForm.address,
              seller: this.information.userId,
              name: this.user.nickname,
              synopsis: this.information.infoName,
              contactWay: this.userForm.phone,
            }
          }).then(res =>{
            if(res.data.code == 10000){
              this.getInformation()
              this.$message.success(res.data.msg)
              this.visible = false
            }else{
              this.$message.error(res.data.msg)
            }
          })

          
        } else {
          console.log('error submit!!');
          return false;
        }
      });
    },

  },
  mounted() {
    this.getInformation()
  },
};
</script>

<style>
#found-page {
  padding-top: 77px;
}

.found-div {
  padding-top: 16px;
  background-color: white;
}
#swzl {
  padding-bottom: 3px;
  margin-bottom: 10px;
  border-bottom: 1px solid;
}
#lostgoods {
  margin-bottom: 19px;
}
.pic{
    /* margin-left: 6px; */
    border: 1px solid rgb(208, 216, 208);
}
.button_div{
  margin-top: 20px;
  border-top: 1px solid orange;
  text-align: center;
  padding-top: 30px;
  padding-bottom: 50px;
}
.buy_div{
  line-height: 26px;
}

</style>