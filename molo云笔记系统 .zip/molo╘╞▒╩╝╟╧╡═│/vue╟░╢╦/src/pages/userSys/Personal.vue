<template>
  <el-row id="personal-div">
    <el-col :span="20" :offset="4"><h3>个人中心</h3></el-col>
    <el-col :span="16" :offset="4" >
		<el-col :span="24">&nbsp;</el-col>
      <el-col :span="3" :offset="8" 
        >账号：<el-input
          v-model="user.account"
          disabled
        ></el-input
      ></el-col>
      <el-col :span="5" :offset="1" 
        >新密码：<el-input type="password" 
          v-model="user.nickname"
          :disabled="enableEditor"
        ></el-input
      ></el-col>
      <el-col :span="5" :offset="1"
        >再次确认：<el-input type="password"
          v-model="user.email"
          :disabled="enableEditor"
        ></el-input
      ></el-col>
      <el-col :span="24">&nbsp;</el-col>
      <el-col :span="24">&nbsp;</el-col>
      <el-col :span="4" :offset="8"
        ><el-button type="primary" plain @click="changeInfo"
          >修改信息</el-button
        ></el-col
      >
      <el-col :span="3"
        ><el-button type="primary" plain @click="saveInfo"
          >保存信息</el-button
        ></el-col
      >
    </el-col>
  </el-row>
</template>

<script>
	import userApi from '../../api/userApi.js'
export default {
  data() {
    return {
      enableEditor: true,
      user: {
        userId: "",
        account: localStorage.getItem("userName"), //账号
        nickname: "", // 昵称
        sex: "",
        photo: "", //头像
        email: "",
      },
      headerObj: {
        userId: "",
      },
    };
  },
  methods: {
    changeInfo() {
      this.enableEditor = !this.enableEditor ;
    },
    saveInfo() {
		if(this.user.email!=this.user.nickname){
			alert("两次密码不相同，请重新输入")
		}else{
			userApi.updateUser({
				"token":localStorage.getItem("token"),
				"userPassword":this.user.email
			}).then(resp=>{
				if(resp.data.code==200){
					alert("成功")
				}else{
					alert("失败")
				}
			})
			
		}
    },
    //限制头像上传的图片大小
    beforeAvatarUpload(file) {
      const isJPG = file.type === "image/jpeg";
      const isLt2M = file.size / 1024 / 1024 < 2;
    },
    handleAvatarSuccess(res, file) {
      localStorage.setItem("userPhoto", res.data);
      this.user.photo = URL.createObjectURL(file.raw);
      location.reload()
    },
    getUserInfo(){
      this.$axios({
        method: "GET",
        url: "/users/get-user",
        params: {
          userId: JSON.parse(localStorage.getItem("user01")).userId,
        },
      }).then((res) => {
        if (res.data.code == 10000) {
          this.user = res.data.data;
          this.headerObj.userId = res.data.data.userId
        } else {
          this.$message.error(res.data.msg);
        }
      });
    },
  },
  mounted() {
    this.getUserInfo()
  },
};
</script>

<style>
#personal-div {
  padding-top: 90px;
}
.per {
  border-radius: 4px;
  margin-top: 6px;
  background-color: white;
  padding-top: 70px;
  padding-bottom: 70px;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
}
</style>