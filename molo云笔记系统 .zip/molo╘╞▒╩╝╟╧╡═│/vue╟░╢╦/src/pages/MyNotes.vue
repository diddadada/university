<template>
	
	
	<!-- 
	 /**
	 *
	 * ━━━━━━神兽出没━━━━━━
	 * 　　 ┏┓     ┏┓
	 * 　　┏┛┻━━━━━┛┻┓
	 * 　　┃　　　　　 ┃
	 * 　　┃　　━　　　┃
	 * 　　┃　┳┛　┗┳  ┃
	 * 　　┃　　　　　 ┃
	 * 　　┃　　┻　　　┃
	 * 　　┃　　　　　 ┃
	 * 　　┗━┓　　　┏━┛　Code is far away from bug with the animal protecting
	 * 　　　 ┃　　　┃    神兽保佑,代码无bug
	 * 　　　　┃　　　┃
	 * 　　　　┃　　　┗━━━┓
	 * 　　　　┃　　　　　　┣┓
	 * 　　　　┃　　　　　　┏┛
	 * 　　　　┗┓┓┏━┳┓┏┛
	 * 　　　　 ┃┫┫ ┃┫┫
	 * 　　　　 ┗┻┛ ┗┻┛
	 */
	 /**
	  * 　　　　　　　 ┏┓　　　┏┓
	  * 　　　　　　　┏┛┻━━━━━┛┻┓
	  * 　　　　　　　┃　　　　　　┃ 　
	  * 　　　　　　　┃　　　━　　 ┃
	  * 　　　　　　　┃　＞　　＜　 ┃
	  * 　　　　　　　┃　　　　　　 ┃
	  * 　　　　　　　┃... ⌒ ... ┃
	  * 　　　　　　　┃　　　　　　┃
	  * 　　　　　　　┗━┓　　　┏━┛
	  * 　　　　　　　　 ┃　　　┃　Code is far away from bug with the animal protecting　　　　　　　　　　
	  * 　　　　　　　　 ┃　　　┃   神兽保佑,代码无bug
	  * 　　　　　　　　 ┃　　　┃　　　　　　　　　　　
	  * 　　　　　　　　 ┃　　　┃  　　　　　　
	  * 　　　　　　　　 ┃　　　┃
	  * 　　　　　　　　 ┃　　　┃　　　　　　　　　　　
	  * 　　　　　　　　 ┃　　　┗━━━┓
	  * 　　　　　　　　 ┃　　　　　　　┣┓
	  * 　　　　　　　　 ┃　　　　　　　┏┛
	  * 　　　　　　　　 ┗┓┓┏━┳┓┏┛
	  * 　　　　　　　　　┃┫┫　┃┫┫
	  * 　　　　　　　　　┗┻┛　┗┻┛
	  */
	 
	 /**
	  *　　　　　　　 ┏┓　 ┏┓+ +
	  *　　　　　　　┏┛┻━━━┛┻┓ + +
	  *　　　　　　　┃　　　　　　┃ 　
	  *　　　　　　　┃　　　━　　 ┃ ++ + + +
	  *　　　　　　 ████━████  ┃+
	  *　　　　　　　┃　　　　　　　┃ +
	  *　　　　　　　┃　　　┻　　　┃
	  *　　　　　　　┃　　　　　　┃ + +
	  *　　　　　　　┗━┓　　　┏━┛
	  *　　　　　　　　 ┃　　　┃　　　　　　　　　　　
	  *　　　　　　　　 ┃　　　┃ + + + +
	  *　　　　　　　　 ┃　　　┃　　　　Code is far away from bug with the animal protecting　　　　　　　
	  *　　　　　　　　 ┃　　　┃ + 　　　　神兽保佑,代码无bug　　
	  *　　　　　　　　 ┃　　　┃
	  *　　　　　　　　 ┃　　　┃　　+　　　　　　　　　
	  *　　　　　　　　 ┃　 　 ┗━━━┓ + +
	  *　　　　　　　　 ┃ 　　　　   ┣┓
	  *　　　　　　　　 ┃ 　　　　　 ┏┛
	  *　　　　　　　　 ┗┓┓┏━┳┓┏┛ + + + +
	  *　　　　　　　　  ┃┫┫ ┃┫┫
	  *　　　　　　　　  ┗┻┛ ┗┻┛+ + + +
	  */-->
	<el-row>
		
		
		<div style="margin-left: 238px;position: fixed;top: 100px; z-index: 10;">
			
			
			<el-popover style=""
			    placement="center"
			    width=""
				
			    trigger="manual"
			    v-model="visible"
				style="margin-left:100px ;">
				<div>
					<!-- markdown area -->
					<el-col :span="16" >
					  <div id="editor-div">
					    <div style="border: 1px solid #ccc ;width: 1350px; height: 700px;">
					      <Toolbar
					        style="border-bottom: 1px solid #ccc"
					        :editor="editor"
					        :defaultConfig="toolbarConfig"
					        :mode="mode"
					      />
					      <Editor
					        style="height: 600px; overflow-y: hidden"
					        v-model="currentContent"
					        :defaultConfig="editorConfig"
					        :mode="mode"
					        @onCreated="onCreated"
					      />
					    </div>
						<div>
							
							<el-input v-model="currentTitle" placeholder="新标题" style="width: 300px;"></el-input>
							<el-radio-group v-model="this.currentType" >
							  <el-radio :label="1">私有</el-radio>
							  <el-radio :label="2">公开</el-radio>
							</el-radio-group>
							<el-button @click="change1()" v-if="this.currentOwner==1" v-show="userType==2">切换类型</el-button>
							<el-button @click="closeMolo()" style="margin: 10px;">关闭</el-button>
							<el-button @click="saveMolo()"  style="margin: 10px;" v-if="this.currentOwner==1">保存</el-button>
						</div>
			
					  </div>
					</el-col>
				</div>
			
				<span slot="footer" class="dialog-footer">
				</span>
			  </el-popover>
			
			
		</div>

		<el-col :span="18" :offset="3">
			<div class="note-div">
				<el-row id="host-note-div">
					<el-collapse v-model="activeNames">
						<el-collapse-item name="1">
							
							
							
							

							<template slot="title">
								<strong>我 的 笔 记 </strong>
							</template>
							
							
							
							
							
							
							
							
							
							
							<!--  -->
<!-- 
								<div>
									<el-input v-model="input" placeholder="请输入内容" style="width: 20%;margin-left: 40px;margin-right: 10px;"></el-input>
									<el-button icon="el-icon-s-promotion" @click="searchByContent()"></el-button>
								</div> -->
							
							

							
							
							
							
							
							
							  
							  
							  
							  
							
							
							
							
							
							
							<el-col :span="20" id="note" v-for="n in moloList">
								<el-container>
									<el-main style="width: 650px;">
										<h4 style="font-size: 15px">{{ n.moloTitle }}</h4>
										<p style="font-size: 12px; color: darkgray" v-html="n.moloContent">

										</p>
									</el-main>
									<el-row>
										<el-col :span="12" :offset="12" style="margin-top: 22px">
											<el-button type="primary" icon="el-icon-reading"
												@click="viewMolo(n.moloId,n.moloContent,n.moloTitle,n.moloTypeId,1)"></el-button>
										</el-col>
										<el-col :span="12" :offset="12" style="margin-top: 12px">
											<el-popconfirm title="确定要删除这本笔记吗？" @confirm="deleteNote(n.moloId)">
												<el-button type="danger" icon="el-icon-delete"
													slot="reference"></el-button>
											</el-popconfirm>
										</el-col>
									</el-row>
								</el-container>
							</el-col>
						</el-collapse-item>
						<div style="margin-left: 450px;"> 
						<el-pagination v-model:current-page="p.pageNum" 
						v-model:page-size="p.pageSize" 
						
						:background=null
						:page-count="pages" layout="prev, pager, next, jumper"
						@current-change="getPrivateMolo1" /></div>


						<el-collapse-item name="2">
							<template slot="title">
								<strong>Star</strong>
							</template>
							
							
							
							
							
							
							
							
				<!-- 			
							<el-popover style=""
							    placement="center"
							    width=""
								
							    trigger="manual"
							    v-model="visible1">
								<div>
									<el-col :span="16" >
									  <div id="editor-div">
									    <div style="border: 1px solid #ccc ;width: 1350px; height: 400pxpx;">
									      <Toolbar
									        style="border-bottom: 1px solid #ccc"
									        :editor="editor"
									        :defaultConfig="toolbarConfig"
									        :mode="mode"
									      />
									      <Editor
									        style="height: 530px; overflow-y: hidden"
									        v-model="currentContent"
									        :defaultConfig="editorConfig"
									        :mode="mode"
									        @onCreated="onCreated"
									      />
									    </div>
										<div>
											
											<el-input v-model="currentTitle" placeholder="新标题" style="width: 300px;"></el-input>
											<el-radio-group v-model="this.currentType" >
											  <el-radio :label="1">私有</el-radio>
											  <el-radio :label="2">公开</el-radio>
											</el-radio-group>
											<el-button @click="closeMolo2()" style="margin: 10px;">关闭</el-button>
										</div>
							
									  </div>
									</el-col>
								</div>
							
								<span slot="footer" class="dialog-footer">
								</span>
							  </el-popover>
							 -->
							
							
							
							
							
							
							
							
							
							
							
							
							
							
							
							
							
							
							<el-col :span="20" id="note" v-for="n in starMoloList">
								<el-container>
									<el-main style="width: 650px;">
										<h4 style="font-size: 15px">{{ n.molo.moloTitle }}</h4>
										<p style="font-size: 12px; color: darkgray" v-html="n.molo.moloContent">
							
										</p>
									</el-main>
									<el-row>
										<el-col :span="12" :offset="12" style="margin-top: 22px">
											<el-button type="primary" icon="el-icon-reading"
												@click="viewMolo(n.molo.moloId,n.molo.moloContent,n.molo.moloTitle,n.molo.moloTypeId,2)"></el-button>
										</el-col>
										<el-col :span="12" :offset="12" style="margin-top: 12px">
											<el-popconfirm title="确定要移除这本笔记吗？" @confirm="removeStarMolo(n.molo.moloId)">
												<el-button type="danger" icon="el-icon-star-off" slot="reference" style="background-color: #ff4e51;border-color: #ff4e51;"></el-button>
											</el-popconfirm>
										</el-col>
									</el-row>
								</el-container>
							</el-col>
						</el-collapse-item>

					</el-collapse>
					<el-col :span="3"> </el-col>
				</el-row>
			</div>
		</el-col>
	</el-row>
</template>

<script>
	import { Editor, Toolbar } from "@wangeditor/editor-for-vue";
	import userApi from '../api/userApi.js'
	export default {
		  components: { Editor, Toolbar },
		name: "MyNotes",
		data() {
			return {
				currentSearch:'',
				      input: '',
				searchTitle:'',
				searchContent:'',
				currentOwner:null,
				
				starMoloList:[],
				userType:localStorage.getItem("userTypeId"),
				currentType:1,
				currentId:null,
				currentTitle:'',
				visible1:false,
				
				visible: false,
				currentContent:'',
				  dialogVisible: false,
				activeNames: ['1', '2'],
				moloList: [],
				p: {
					"pageNum": 1,
					"pageSize": 4,
					"token": localStorage.getItem("token"),
					"moloContent":this.currentContent
				},
				pages: null,
				boughtNoteList: [],
				editor: null,
				html: "",
				toolbarConfig: {},
				editorConfig: { 
				  placeholder: "请输入内容...",
				  MENU_CONF: {
				    'uploadImage': {
				      // 上传图片的配置
				        server: 'http://8.130.37.232:8089/upload/image',
				        fieldName: 'file',
				            // 上传错误，或者触发 timeout 超时
				        onError(file, err, res) {
				            alert("图片上传出错~")
				        },
				    }
				  }
				},
				mode: "default", // or 'simple'
				// ----------------------------------------------
				headerObj: {
				  noteId: "0",
				},
			};
		},

		methods: {
			searchByContent(){
				this.p.currentContent=this.input
				this.getPrivateMolo()
				
			},
			removeStarMolo(id){
				userApi.removeStarMolo({
					"token":localStorage.getItem("token"),
					"id":id
				}).then(resp=>{
					if(resp.data.code==200){
						alert("成功")
						this.getStarMolo()
					}else{
						alert("失败")
					}
				})
			},
			change1(){
				console.log(this.currentType+"before")
				if(this.currentType==2){
					this.currentType=1
				}else{
					this.currentType=2
				}
				console.log(this.currentType+"after")
			},
			getStarMolo(){
				let x=localStorage.getItem("token")
				
					userApi.getStarMolo(localStorage.getItem("token")).then(resp=>{
						this.starMoloList=resp.data.data
						console.log(this.starMoloList)
					})
			},
			saveMolo(){
				userApi.updateMolo({
					"token":localStorage.getItem("token"),
					"id":this.currentId,
					"title":this.currentTitle,
					"content":this.currentContent,
					"type":this.currentType
				}).then(resp=>{
					if(resp.data.code==200){
						alert("修改成功")
						this.closeMolo(s)
					}else{
						alert("修改失败")
					}
				})
				
			},
			closeMolo(){
				this.visible=false

				
			},
			closeMolo2(){
				this.visible1=false
			},
			onCreated(editor) {
			  this.editor = Object.seal(editor); // 一定要用 Object.seal() ，否则会报错
			},
			viewMolo(moloId,moloContent,moloTitle,moloType,currentOwner){
				this.currentOwner=currentOwner
				this.currentType=moloType
				this.currentId=moloId
				this.visible=true
				this.currentContent=moloContent
				this.currentTitle=moloTitle
			},
			viewMolo2(moloId,moloContent,moloTitle,moloType){
				this.currentType=moloType
				this.currentId=moloId
				this.visible1=true
				this.currentContent=moloContent
				this.currentTitle=moloTitle
			},
			handleClose(done) {
			        this.$confirm('确认关闭？')
			          .then(_ => {
			            done();
			          })
			          .catch(_ => {});
			      },
			getPrivateMolo1(val) {
				this.p.pageNum = val
				userApi.getPrivateMolo(this.p).then(resp => {
					if (resp.data.code == 200) {

						this.moloList = resp.data.data.records
						this.pages = resp.data.data.pages
					} else {

					}

				})

			},
			getPrivateMolo() {
				userApi.getPrivateMolo(this.p).then(resp => {
					if (resp.data.code == 200) {
						this.moloList = resp.data.data.records
						this.pages = resp.data.data.pages
						console.log(resp.data.data)
					} else {

					}
					console.log(resp.data)
				})
			},
			lookNote(noteId, content) {
				this.$router.push({
					name: '',
					params: {
						id: noteId
					}
				})
			},
			// 删除笔记
			deleteNote(moloId) {
				console.log(moloId)
				userApi.deleteMolo({
					"token": localStorage.getItem("token"),
					"id": moloId
				}).then(resp => {
					if (resp.data.code == 200) {
						this.getPrivateMolo()
						this.getStarMolo()
					} else {

					}
					console.log(resp.data)
				})

			},
		},

		mounted() {
			this.getPrivateMolo();
			this.getStarMolo()
		},
	};
</script>

<style scoped>
	.note-div {
		margin-top: 86px;
		padding-top: 1px;
		background-color: white;
		border-radius: 10px;
	}

	#note-list {
		margin-top: 12px;
		margin-left: 30px;
		border-bottom: 2px solid rgb(242, 243, 239);
		margin-bottom: 6px;
	}

	#el-min {
		padding: 8px;
	}

	#note {
		margin-left: 20px;
		margin-top: 7px;
		border-top: 2px solid rgb(242, 243, 239);
		border-bottom: 2px solid rgb(242, 243, 239);
	}

	#host-note-div {
		margin-left: 12px;
		box-shadow: 2px 2px 6px -5px #000;
	}

	.el-container {
		height: 136px;
		box-shadow: 0px 8px 10px -15px #000;
	}

	#note-img {
		width: 160px;
		height: 90px;
	}

	.font-title {
		font-size: 16px;
		font-weight: 600;
	}
</style>