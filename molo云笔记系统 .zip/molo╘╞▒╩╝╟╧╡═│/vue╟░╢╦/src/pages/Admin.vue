<template>

  <el-container id="admin-login" style="height: 700px; border: 1px solid #eee">
    <el-aside width="300px" style="background-color: rgb(238, 241, 246)">
      <el-menu :default-openeds="['1']" style="margin-top:21px;" active-text-color="#ff5110">
        <el-submenu index="1">
          <template slot="title"
            ><i class="el-icon-message"></i>云笔记管理系统</template>
          <el-menu-item-group :default-active="'1-1'">
            <el-menu-item @click="adminUser" index="1-1">用户管理</el-menu-item>
            <el-menu-item @click="adminNote" index="1-2">用户申请</el-menu-item>
            <el-menu-item @click="adminCloudShop" index="1-3">用户日志</el-menu-item>
            <el-menu-item @click="adminLostGoods" index="1-4">笔记日志</el-menu-item>
          </el-menu-item-group>
        </el-submenu>
      </el-menu>
    </el-aside>
    <el-main> 
<!--      <h1 class="welcome" v-show="welcome">校园云笔记管理系统</h1>
	  	  <p v-show="welcome">这里是云笔记管理系统</p>
		  <p v-show="welcome">欢迎欢迎</p> -->
      <el-container>
      <router-view></router-view>
    </el-container>    
    </el-main>

  </el-container>
</template>

<script>
export default {
  name:"Admin",
  data() {
    return { 
      welcome:true
    };
  },
  methods: {
    adminUser(){
      this.welcome=false
      this.$router.push({
        path:'/admin/admin-users'
      },() => {})
    },
    adminNote(){
      this.welcome=false
      this.$router.push({
        path:'/admin/admin-notes'
      },() => {})
    },
    adminLostGoods(){
      this.welcome=false
      this.$router.push({
        path:'/admin/admin-lostGoods'
      },() => {})
    },
    adminCloudShop(){
      this.welcome=false
      this.$router.push({
        path:'/admin/admin-cloudShop'
      },() => {})
    },
  },
  mounted() {
    this.adminUser()
  },
};
</script>

<style scoped>
.el-header {
  background-color: #b3c0d1;
  color: #333;
  line-height: 60px;
}

.el-aside {
  color: #333;
}

#admin-login{
    padding-top: 70px;
}
.welcome{
  margin-top: 100px;
  margin-left: 300px;
  color:red
}
</style>