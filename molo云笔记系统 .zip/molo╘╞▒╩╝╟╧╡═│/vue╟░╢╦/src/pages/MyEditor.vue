<template>
  <el-row id="myeditor-div">
    <el-col :span="6">
      <el-card class="box-card">
        <div class="text item">
          <el-form
            :model="noteForm"
            :rules="rules"
            ref="noteForm"
            label-width="100px"
            class="demo-ruleForm"
            size="small"
          >
            <el-form-item label="笔记名称">
              <el-input v-model="moloTitle"></el-input>
            </el-form-item>

            <!-- 笔记属性 -->
            <el-form-item label="笔记属性">
              <el-radio-group v-model="noteForm.notType">
                <el-radio label="1">私有</el-radio>
                <el-radio label="2" v-if="userType==2">公开</el-radio>
              </el-radio-group>
			  <el-button v-if="userType==1" @click="applyForUP()">申请UP</el-button>
            </el-form-item>
			
<!--            上传笔记封面
            <el-form-item label="从本地上传" prop="intro">
              <el-upload
                class="upload-demo"
                ref="upload"
                :headers="headerObj"
                action="http://8.130.37.232:8089/upload/up"
                list-type="picture"
                :auto-upload="false"
                :limit="1"
              >
                <el-button size="small" type="primary">点击上传</el-button>
              </el-upload>
            </el-form-item> -->
            <!-- 笔记简介 -->
            </el-form-item>

            <el-form-item>
              <el-button type="primary"
               @click="insertMolo()">保存</el-button>
              <el-button @click="resetForm('noteForm')">重置</el-button>
            </el-form-item>
          </el-form>
        </div>
      </el-card>
    </el-col>

    <!-- 富文本编辑区 -->
    <el-col :span="16">
      <div id="editor-div">
        <div style="border: 1px solid #ccc">
          <Toolbar
            style="border-bottom: 1px solid #ccc"
            :editor="editor"
            :defaultConfig="toolbarConfig"
            :mode="mode"
          />
          <Editor
            style="height: 550px; overflow-y: hidden"
            v-model="moloContent"
            :defaultConfig="editorConfig"
            :mode="mode"
            @onCreated="onCreated"
          />
        </div>
      </div>
    </el-col>
  </el-row>
</template>

<script>
import Vue from "vue";
import { Editor, Toolbar } from "@wangeditor/editor-for-vue";
import userApi from '../api/userApi.js'

export default Vue.extend({
  components: { Editor, Toolbar },
  data() {
    var checkPrice = (rule, value, callback) => {
          if (!value) { 
            return callback(new Error('金额不能为空'));
          }
          let perice = Number(value)
          setTimeout(() => {
            if (Number.isNaN(perice)) {
              callback(new Error('请输入正确的金额'));
            }else{
              callback();
            }
          }, 500);
        };
    return {
		userType:localStorage.getItem("userTypeId"),
		moloTitle:null,
		moloContent:null,
      editor: null,
      html: "",
      toolbarConfig: {},
      editorConfig: { 
        placeholder: "请输入内容...",
        MENU_CONF: {
          'uploadImage': {
            // 上传图片的配置
              server: 'http://8.130.37.232:8089/upload/image',
              fieldName: 'file',
                  // 上传错误，或者触发 timeout 超时
              onError(file, err, res) {
                  alert("图片上传出错~")
              },
          }
        }
      },
      mode: "default", // or 'simple'
      // ----------------------------------------------
      headerObj: {
        noteId: "0",
      },
      noteForm: {
        title: "",
        notType: "2",
        // 笔记简介
        textarea: "",
        price:"",
      },

      rules: {
       
        price: [
          { validator: checkPrice, trigger: 'blur' }
        ],
      },
    };
  },
  methods: {
    onCreated(editor) {
      this.editor = Object.seal(editor); // 一定要用 Object.seal() ，否则会报错
    },
	insertMolo(){
		userApi.insertMolo(localStorage.getItem("token"),this.moloTitle,this.moloContent,this.noteForm.notType).then(resp=>{
			console.log(resp.data)
			alert("成功")
		})
	},
	
	
	
	applyForUP(){
		userApi.applyForUP(localStorage.getItem("token")).then(resp=>{
			if(resp.data.code==200){
				alert("请求成功，请耐心等待审核")
			}else{
				alert("失败")
			}
		})
	},

	
    
// 创建笔记
    saveNote(noteForm) {
      this.$refs[noteForm].validate((valid) => {  
          if (valid) {
            if(this.html == '<p><br></p>'){
              this.$message.error("笔记内容不能为空哦！")
              return
            }
            this.$axios({
              method: "POST",
              url: "/notes/save-note",
              data: {
                userId: JSON.parse(localStorage.getItem("user01")).userId,
                title: this.noteForm.title,
                content:this.html,
                noteIntro:this.noteForm.textarea,
                noteState: this.noteForm.notType,
                price:this.noteForm.price
              },
            }).then((res) => {
              if(res.data.code==10000){
                this.headerObj.noteId=res.data.data
                this.$refs.upload.submit()  
                this.$message({
                message: '恭喜你，笔记保存成功',
                type: 'success'
              });
                this.$router.push({
                name:'look-note',
                params:{
                  id:res.data.data
                }
              })
              }else{
                this.$message.error("保存失败");          
              }
            })
          } else {
            console.log('error submit!!');
            return false;
          }
        });

    },
    resetForm(formName) {
      this.$refs[formName].resetFields();
    },
  },

  mounted() {
        // 模拟 ajax 请求，异步渲染编辑器
  },
  beforeDestroy() {
    const editor = this.editor;
    if (editor == null) return;
    editor.destroy(); // 组件销毁时，及时销毁编辑器
  },
});
</script>

<style scoped>
#myeditor-div {
  padding-top: 80px;
}
#editor-div {
  margin-right: 20px;
}
.box-card {
  margin-top: 20px;
  margin-left: 30px;
  margin-right: 20px;
}
.w-e-full-screen-container {
  top: 60px;
}

/* 上传封面 */
.avatar-uploader .el-upload {
  border: 1px dashed #39a0e9;
  border-radius: 6px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
}
.avatar-uploader .el-upload:hover {
  border-color: #409eff;
}
.avatar-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  width: 178px;
  height: 178px;
  line-height: 178px;
  text-align: center;
}
.avatar {
  width: 178px;
  height: 178px;
  display: block;
}
</style>

<style src="@wangeditor/editor/dist/css/style.css"></style>
