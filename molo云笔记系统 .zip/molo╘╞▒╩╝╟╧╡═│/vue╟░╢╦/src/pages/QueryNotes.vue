<template>
  <el-row>
    <el-col :span="18" :offset="3">
      <div class="note-div">
        <el-row id="note-list">
          <el-col :span="2">
            <span class="font-title">搜索结果</span>
          </el-col>
        </el-row>
        <el-row id="host-note-div">
          <el-col :span="20" id="note" v-for="n in noteList" :key="n.noteId">
            <el-container>
              <el-aside width="160px">
                <el-image
                  style="width: 160px; height: 90px"
                  :src="n.notePicture"
                  fit="fit"
                ></el-image>
              </el-aside>
              <el-main>
                <h4 style="font-size: 16px">{{ n.title }}</h4>
                <p style="font-size: 13px; color: darkgray">
                  {{ n.noteIntro }}
                </p>
                <el-row>
                  <el-col :span="24">
                    创建时间：<i class="el-icon-timer">{{
                      n.createTime.slice(0, 10)
                    }}</i>
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :span="24">
                    更新时间：<i v-if="n.updateTime" class="el-icon-timer">{{
                      n.updateTime.slice(0,10)
                      }}</i>
                  </el-col>
                </el-row>
              </el-main>
              <el-row>
                <el-col :span="12" :offset="12" style="margin-top: 22px">
                  <el-button
                    type="primary"
                    icon="el-icon-reading"
                    @click="lookNote(n.noteId, n.content)"
                  ></el-button>
                </el-col>
                <el-col :span="12" :offset="12" style="margin-top: 12px">
                  <el-popconfirm
                    title="确定要删除这本笔记吗？"
                    @confirm="deleteNote(n.noteId)"
                  >
                    <el-button
                      type="danger"
                      icon="el-icon-delete"
                      slot="reference"
                    ></el-button>
                  </el-popconfirm>
                </el-col>
              </el-row>
            </el-container>
          </el-col>
          <el-col :span="3"> </el-col>
        </el-row>
      </div>
    </el-col>
  </el-row>
</template>

<script>
import pubsub from 'pubsub-js'
export default {
  name: "QueryNotes",
  data() {
    return {
      noteList: [
        {
          noteId: "",
          title: "",
          notePicture: "",
          noteIntro: "",
          content: "",
          createTime: "",
          updateTime: "",
          noteState: "",
          readTotal: "",
        },
      ],
      // queryString: this.$route.query.queryStr,
    };
  },

  methods: {
    lookNote(noteId, content) {
      this.$router.push({
        name: "look-note",
        params: {
          id: noteId,
        },
      });
    },
    // 删除笔记
    deleteNote(noteId) {
      this.$axios({
        method: "GET",
        url: "/notes/delete-note",
        params: {
          noteId,
        },
      }).then((res) => {
        if (res.data.code == 10000) {
          this.$message({
            message: res.data.msg,
            type: "success",
          });
          location.reload();
        } else {
        this.$message({
          showClose: true,
          message: '删除失败',
          type: 'error'
        });
        }
      });
    },
  },
  mounted() {
    this.pubId = pubsub.subscribe('notes',(msgName,data)=>{
      this.noteList = data
    })

  },
};
</script>

<style scoped>
.note-div {
  margin-top: 86px;
  padding-top: 1px;
  background-color: white;
  border-radius: 10px;
}

#note-list {
  margin-top: 12px;
  margin-left: 30px;
  border-bottom: 2px solid rgb(242, 243, 239);
  margin-bottom: 6px;
}
#el-min {
  padding: 8px;
}

#note {
  margin-left: 20px;
  margin-top: 7px;
  border-top: 2px solid rgb(242, 243, 239);
  border-bottom: 2px solid rgb(242, 243, 239);
}
#host-note-div {
  margin-left: 12px;
  box-shadow: 2px 2px 6px -5px #000;
}
.el-container {
  height: 136px;
  box-shadow: 0px 8px 10px -15px #000;
}
#note-img {
  width: 160px;
  height: 90px;
}
.font-title {
  font-size: 16px;
  font-weight: 600;
}
</style>
