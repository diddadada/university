<template>
  <el-main>
    <el-breadcrumb separator="/">
      <el-breadcrumb-item>用户日志</el-breadcrumb-item>
    </el-breadcrumb>
	
<!-- 	<el-form :inline="true" :model="search" class="demo-form-inline">
		<el-form-item label="">
			<el-input clearable v-model="search.id" placeholder="编号" size="10"></el-input>
		</el-form-item>
		<el-form-item label="">
			<el-input clearable v-model="search.teacherName" placeholder="老师姓名"></el-input>
		</el-form-item>
		<el-form-item label="">
			<el-select clearable v-model="search.status" placeholder="状态">
				<el-option v-for="s in statusList" :key="s.id" :label="s.text" :value="s.id"></el-option>
			</el-select>
		</el-form-item>
		<el-form-item>
			<el-button type="primary" @click="selectTeacherList()">查询</el-button>
			
			<el-button type="warning" @click="dialogFormVisible = true;teacher={}">新增</el-button>
		</el-form-item>
	</el-form> -->
	
    <el-table :data="information">
      <el-table-column type="index" label="序号" width="110"> </el-table-column>
      <el-table-column prop="userId" label="用户ID" width="120"> </el-table-column>
      <el-table-column prop="userlogDescription" label="描述" width="130"> </el-table-column>
      <el-table-column prop="userlogTime" label="时间" width="300"> </el-table-column>
<!--      <el-table-column label="操作"> -->
<!--        <template slot-scope="scope"> -->
<!--          <el-popconfirm @confirm="deleteInfo(scope.row.infoId)" title="确定要删除该用户吗？">
            <el-button size="mini" type="danger" slot="reference">删除</el-button>
          </el-popconfirm> -->
<!--      </template> -->
<!--      </el-table-column> -->
    </el-table>
  </el-main>
</template>

<script>
export default {
  data() {
    return {
      information: [],
    };
  },
  methods: {
    //获取全部实体资料
    getInformation() {
      this.$axios({
        method: "GET",
        url: "/log/allUserLog",
      }).then((res) => {
        if (res.data.code == 200) {
			console.log(res.data.data);
          this.information = res.data.data;
        } else {
          this.$message({
          showClose: true,
          message: '查询出错',
          type: 'error'
        });
        }
      });
    },
	
  },
  mounted() {
    this.getInformation()
  },
};
</script>

<style>
</style>