<template>
  <el-main>
    <el-breadcrumb separator="/">

      <el-breadcrumb-item>笔记管理</el-breadcrumb-item>
    </el-breadcrumb>
    <el-table :data="tableData">
      <el-table-column type="index" label="序号" width="110"> </el-table-column>
      <el-table-column prop="examineUsername" label="申请人" width="160"> </el-table-column>
	  <el-table-column prop="examineType" label="类型" width="100">
	  		<template slot-scope="scope">
	  					<el-column v-if="scope.row.examineType==1">申请账号</el-column>
	  					<el-column v-if="scope.row.examineType==2" >申请成为up</el-column>
						<el-column v-if="scope.row.examineType==3" >申诉</el-column>
	  		</template> </el-table-column>
<!--      <el-table-column prop="examineType" label="类型" width="130"> </el-table-column> -->
      <el-table-column label="操作">
        <template slot-scope="scope">
			<el-button size="mini" type="success"  @click="agree(scope.row)">同 意</el-button>
          </el-popconfirm>
      </template>
      </el-table-column>
    </el-table>
  </el-main>
</template>

<script>
export default {
  data() {
    return {
		examine:{},//用于新增或修改
      tableData: [],
    };
  },
  methods: {
    getNoteList() {
      this.$axios({
        method: "GET",
        url: "/examine/allExamine",
      }).then((res) => {
        if (res.data.code == 200) {
          this.tableData = res.data.data;
		  console.log(res.data.data);
          // // 将状态码012转换为中文
          // for (let index = 0; index < this.tableData.length; index++) {
          //   if(this.tableData[index].examineType=='1'){
          //     this.tableData[index].examineType="申请账号"
          //   }else if(this.tableData[index].examineType=='2'){
          //     this.tableData[index].examineType="申请成为up"
          //   }else{
          //     this.tableData[index].examineType="申诉"
          //   }
          // }

        } else {
          this.$message.error("查询失败");
        }
      });
    },
	agree(examine) {
		console.log(examine);
	  this.$axios({
	    method: "PUT",
	    url: "/examine/allExamine/agree/",
		 data: {
			 "examineId":examine.examineId,
			 "examineStatus":examine.examineStatus,
			 "examineType":examine.examineType,
			 "examinePassword":examine.examinePassword,
			 "examineUsername":examine.examineUsername
		    }
	  }).then((res) => {
	      if (res.data.code===200){
	        this.$message({
	        message: res.data.msg,
	        type: 'success'
	        });
			 location.reload()
	        this.$router.push({
	          path: "/admin/admin-notes",
	        });            
	      }else{
	        this.$message.error("同意失败");            
	      }
	    })
	  this.updateU = false
	},
  },
  mounted() {
    this.getNoteList()

  },
};
</script>

<style scoped>
.el-button{
  margin-left: 10px;
}
</style>