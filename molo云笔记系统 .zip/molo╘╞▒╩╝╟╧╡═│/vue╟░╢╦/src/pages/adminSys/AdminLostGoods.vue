<template>
  <el-main>
    <el-breadcrumb separator="/">

      <el-breadcrumb-item>molo日志</el-breadcrumb-item>
    </el-breadcrumb>
    <el-table :data="information">
      <el-table-column type="index" label="序号" width="140"> </el-table-column>
      <el-table-column prop="moloId" label="笔记id" width="120"> </el-table-column>
      <el-table-column prop="molologDescription" label="描述" width="120"> </el-table-column>
      <el-table-column prop="molologTime" label="时间" width="300"> </el-table-column>
     <!-- <el-table-column label="操作">
        <template slot-scope="scope">
          <el-popconfirm @confirm="handleDelete(scope.row.lostGoodsId)" title="确定要删除该用户吗？">
            <el-button size="mini" type="danger" slot="reference">删除</el-button>
          </el-popconfirm>
      </template>
      </el-table-column> -->
    </el-table>
  </el-main>
</template>

<script>
export default {
  data() {
    return {
      information: [],
    };
  },
  methods: {
    // handleDelete(lostGoodsId){
    //   this.$axios({
    //     method: "GET",
    //     url: "/lost-goods/deleteLostGoods",
    //     params:{
    //       lostGoodsId
    //     }
    //   }).then((res) => {
    //     if (res.data.code == 10000) {
    //       this.$message(res.data.msg);
    //       this.getGoodsList()
    //     } else {
    //       this.$message.error("查询失败");
    //     }
    //   });
    // },
    //获取全部实体资料
    getGoodsList() {
      this.$axios({
        method: "GET",
        url: "/log/allMoloLog",
      }).then((res) => {
        if (res.data.code == 200) {
    		console.log(res.data.data);
          this.information = res.data.data;
        } else {
          this.$message({
          showClose: true,
          message: '查询出错',
          type: 'error'
        });
        }
      });
    },
  },
  mounted() {
    this.getGoodsList()

  },
};
</script>

<style>
</style>