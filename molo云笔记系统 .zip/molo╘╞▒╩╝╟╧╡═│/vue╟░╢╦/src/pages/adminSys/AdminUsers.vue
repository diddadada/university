<template>
  <el-main>
    <el-breadcrumb separator="/">

      <el-breadcrumb-item>用户管理</el-breadcrumb-item>
    </el-breadcrumb>
    <el-table :data="tableData">
      <el-table-column type="index" label="序号" width="110"> </el-table-column>
      <el-table-column prop="userName" label="用户名" width="160"> </el-table-column>
      <el-table-column prop="userTypeId" label="用户类型" width="160">
		  <template slot-scope="scope">
					<el-tag v-if="scope.row.userTypeId==1">普通用户</el-tag>
					<el-tag v-if="scope.row.userTypeId==2" type="success">up用户</el-tag>
		</template> </el-table-column> 
      <el-table-column prop="userStatus" label="用户状态" width="100">
		<template slot-scope="scope">
					<el-tag v-if="scope.row.userStatus==0">封禁</el-tag>
					<el-tag v-if="scope.row.userStatus==1" type="success">正常</el-tag>
		</template> </el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-popconfirm @confirm="deleteUser(scope.row.userId)" title="确定要删除该用户吗？">
            <el-button size="mini" type="danger" slot="reference">删除</el-button>
          </el-popconfirm>
		    <el-button size="mini" type="success"  @click="updateU = true;user.userId = scope.row.userId">修改</el-button>
			<el-popconfirm @confirm="ban(scope.row)" title="确定要封禁该用户吗？">
			<el-button v-if="scope.row.userStatus==1" size="mini" type="info" slot="reference">封禁</el-button>
			</el-popconfirm>
			<el-popconfirm @confirm="relieve(scope.row)" title="确定要解除该用户的封禁吗？">
			<el-button v-if="scope.row.userStatus==0" size="mini" type="warning" slot="reference">解封</el-button>
			</el-popconfirm>
      </template>
      </el-table-column>
    </el-table>
	<!-- 用户修改界面 -->
	   <el-dialog
	     :modal-append-to-body="false"
	     title="用户修改"
	     center
	     :visible.sync="updateU"
	     width="30%">
	     <el-form label-width="80px">
	     <el-form-item label="用户名">
	         <el-input v-model="user.userName"></el-input>
	       </el-form-item>
		   <el-form-item label="用户类型">
		       <el-select v-model="user.userTypeId" placeholder="请选择">
		           <el-option
		             v-for="item in typeList"
		             :label="item.text"
		             :value="item.id">
		           </el-option>
		         </el-select>
		     </el-form-item>
			 <el-form-item label="用户状态">
			     <el-select v-model="user.userStatus" placeholder="请选择">
			         <el-option
			           v-for="item in statusList"
			           :label="item.text"
			           :value="item.id">
			         </el-option>
			       </el-select>
			   </el-form-item>
	     </el-form>
	     <span slot="footer" class="dialog-footer">
	       <el-button @click="updateU = false">取 消</el-button>
	       <el-button type="primary" @click.prevent="updateUser(user)">修 改</el-button>
	     </span>
	   </el-dialog>
  </el-main>
</template>

<script>
export default {
  data() {
    return {
		user:{},//用于新增或修改
		updateU: false,//显示新增框
		tableData: [],
		statusList: [ //下拉框绑定用户状态
			{
				id: 0,
				text: "封禁"
			},
			{
				id: 1,
				text: "正常"
			}
		],
		typeList: [ //下拉框绑定用户状态
			{
				id: 1,
				text: "普通用户"
			},
			{
				id: 2,
				text: "up用户"
			}
		]
    };
  },
  methods: {
    getUserList() {
      this.$axios({
        method: "GET",
        url: "/user/allUser",
      }).then((res) => {
        if (res.data.code == 200) {
          this.tableData = res.data.data;
		  // console.log(this.tableData);
        } else {
          this.$message.error("查询失败");
        }
      });
    },
	
    deleteUser(userId){
		console.log(userId);
      this.$axios({
        method:"DELETE",
        url: "/user/deleteUser/"+userId,
      }).then((res) => {
        if (res.data.code == 200) {
		 this.$message({
	     message: res.data.msg,
	     type: 'success'
	     });
		  location.reload()
	     this.$router.push({
	       path: "/admin/admin-users",
	     });  
        } else {
          this.$message.error("删除失败");
        }
      });
    },
	ban(user){
		console.log(user);
	  this.$axios({
	    method:"PUT",
	    url: "/user/ban",
		data:{
			"token":user.token,
			"userId":user.userId,
			"userName":user.userName,
			"userPassword":user.userPassword,
			"userStatus":user.userStatus,
			"userTypeId":user.userStatus
		},
	  }).then((res) => {
	    if (res.data.code == 200) {
	     this.$message({
	     message: res.data.msg,
	     type: 'success'
	     });
		  location.reload()
	     this.$router.push({
	       path: "/admin/admin-users",
	     });            
	    } else {
	      this.$message.error("操作失败");
	    }
	  });
	},
	relieve(user){
		console.log(user);
	  this.$axios({
	    method:"PUT",
	    url: "/user/relieve",
		data:{
			"token":user.token,
			"userId":user.userId,
			"userName":user.userName,
			"userPassword":user.userPassword,
			"userStatus":user.userStatus,
			"userTypeId":user.userTypeId
		},
	  }).then((res) => {
	    if (res.data.code == 200) {
	      this.$message({
	      message: res.data.msg,
	      type: 'success'
	      });
		  location.reload()
	      this.$router.push({
	        path: "/admin/admin-users",
	      });            
	    } else {
	      this.$message.error("操作失败");
	    }
	  });
	},
	updateUser(user) {
		console.log(user);
	  this.$axios({
	    method: "PUT",
	    url: "/user/updateUser",
		data:{
			"token":user.token,
			"userId":user.userId,
			"userName":user.userName,
			"userPassword":user.userPassword,
			"userStatus":user.userStatus,
			"userTypeId":user.userTypeId
		},
	  }).then((res) => {
	      if (res.data.code===200){
			  this.updateU = false,
	        this.$message({
	        message: res.data.msg,
	        type: 'success'
	        });
			location.reload()
	        this.$router.push({
	          path: "/admin/admin-users",
	        });            
	      }else{
	        this.$message.error("修改错误");            
	      }
	    })
	  this.updateU = false
	},
  },
  mounted() {
    this.getUserList()

  },
};
</script>

<style>
</style>