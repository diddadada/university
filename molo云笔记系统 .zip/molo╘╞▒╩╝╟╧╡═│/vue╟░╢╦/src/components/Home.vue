<template>
<div>
	
	

    <el-container>
      <el-aside width="250px">
        <!-- 云端小卖部 -->
        <el-row>
          <el-col :span="4" :offset="10">
            <CloudShop />
          </el-col>
        </el-row>
        <!-- 失物招领 -->
        <el-row>
          <el-col :span="4" :offset="10">
            <Found />
          </el-col>
        </el-row>
      </el-aside>
      <el-main>
        <!-- 最新笔记 -->
        <el-row>
          <el-col :span="19" :offset="1" id="new-notes">
            <NewNotes />
          </el-col>
        </el-row>
        <!-- 热门笔记 -->
        <el-row>
          <el-col :span="19" :offset="1" id="hot-notes">
            <HotNotes />
          </el-col>
        </el-row>
      </el-main>
    </el-container>

</div>
</template>

<script>
import Header from "./Header";
import CloudShop from "./CloudShop";
import Found from "./Found";
import NewNotes from "./NewNotes";
import HotNotes from "./HotNotes";
export default {
  name: "Home",
  components: {
    Header,
    CloudShop,
    Found,
    NewNotes,
    HotNotes,

  },
  data() {
    return {

      
    };
  },
  methods:{
			
  }
};
</script>

<style>
#new-notes {
  margin-top: 63px;
}
#hot-notes {
  margin-top: 26px;
}
</style>
