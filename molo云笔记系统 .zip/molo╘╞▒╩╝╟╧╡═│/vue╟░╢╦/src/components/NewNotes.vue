<template>
  <div class="note-div">
	  <el-popover style=""
	      placement="center"
	      width=""
	  	
	      trigger="manual"
	      v-model="visible"
	  	style="margin-left:100px ;">
	  	<div>
	  		<!-- markdown area -->
	  		<el-col :span="16" >
	  		  <div id="editor-div" >
	  		    <div style="border: 1px solid #ccc ;width: 1200px; height: 650px;">
	  		      <Toolbar
	  		        style="border-bottom: 1px solid #ccc"
	  		        :editor="editor"
	  		        :defaultConfig="toolbarConfig"
	  		        :mode="mode"
	  		      />
	  		      <Editor
	  		        style="height: 550px; overflow-y: hidden;"
	  		        v-model="currentContent"
	  		        :defaultConfig="editorConfig"
	  		        :mode="mode"
	  		        @onCreated="onCreated"
	  		      />
	  		    </div>
	  			<div>
	  				
	  				<el-input v-model="currentTitle" placeholder="新标题" style="width: 300px;"></el-input>
	  				<el-button @click="closeMolo()" style="margin: 10px;">关闭</el-button>
	  			</div>
	  
	  		  </div>
	  		</el-col>
	  	</div>
	  
	  	<span slot="footer" class="dialog-footer">
	  	</span>
	    </el-popover>
    <el-row id="note-list">
      <el-col :span="2">
        <span class="font-title">推荐</span>
      </el-col>
    </el-row>
	
	


    <el-row id="host-note-div">
      <el-col :span="11" id="note" v-for="n in moloList" :key="n.noteId">
        <div @click="viewMolo(n.moloId,n.moloContent,n.moloTitle,n.moloTypeId,2)">
			<el-container >
				<el-card shadow="hover" style="width: 100%;">
					<h4>{{n.moloTitle.slice(0,20)}}</h4>
					<p v-html="n.moloContent.slice(0,300)"></p>
				</el-card>
			</el-container>
        </div>
      </el-col>
    </el-row>
  </div>
</template>

<script>
	import { Editor, Toolbar } from "@wangeditor/editor-for-vue";
	import userApi from '../api/userApi.js'
export default {
		  components: { Editor, Toolbar },
  name: "NewNotes",
  data() {
    return {
		visible:false,
		editor: null,
		html: "",
		toolbarConfig: {},
		editorConfig: { 
		  placeholder: "请输入内容...",
		  MENU_CONF: {
		    'uploadImage': {
		      // 上传图片的配置
		        server: 'http://8.130.37.232:8089/upload/image',
		        fieldName: 'file',
		            // 上传错误，或者触发 timeout 超时
		        onError(file, err, res) {
		            alert("图片上传出错~")
		        },
		    }
		  }
		},
		mode: "default", // or 'simple'
		// ----------------------------------------------
		headerObj: {
		  noteId: "0",
		},
		currentOwner:null,
		
		starMoloList:[],
		userType:localStorage.getItem("userTypeId"),
		currentType:1,
		currentId:null,
		currentTitle:'',
		visible1:false,
		
		visible: false,
		currentContent:'',
		  dialogVisible: false,
		activeNames: ['1', '2'],
      moloList: [],
	  p:{"pageNum":1,"pageSize":8,"token":""}
    };
  },
  methods: {
	  closeMolo(){
	  	this.visible=false
	  
	  	
	  },
	  closeMolo2(){
	  	this.visible1=false
	  },
	  onCreated(editor) {
	    this.editor = Object.seal(editor); // 一定要用 Object.seal() ，否则会报错
	  },
	  viewMolo(moloId,moloContent,moloTitle,moloType,currentOwner){
	  	this.currentOwner=currentOwner
	  	this.currentType=moloType
	  	this.currentId=moloId
	  	this.visible=true
	  	this.currentContent=moloContent
	  	this.currentTitle=moloTitle
	  },
    getNewNotes(p){
		this.p.token=localStorage.getItem("token")
		userApi.getPublicMolo(p).then(resp=>{
		if(resp.data.code==200){

			this.moloList=resp.data.data.records
			console.log(this.moloList)
		}else{
		}
		console.log(resp.data)
		})
    },
  },
  mounted() {
    this.getNewNotes(this.p)
  },
};
</script>

<style scoped>
.note-div {
  padding-top: 1px;
  background-color: white;
  border-radius: 10px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, .12), 0 0 6px rgba(0, 0, 0, .04)
}

#note-list {
  margin-top: 12px;
  margin-left: 30px;
  border-bottom: 2px solid rgb(242, 243, 239);
  margin-bottom: 6px;
}
#el-min {
  padding: 8px;
}

#note {
  margin-left: 20px;
  margin-top: 7px;
  border: 2px solid rgb(242, 243, 239);
}
#host-note-div {
  margin-left: 9px;
  height: 650px;
  /* box-shadow: 2px 2px 6px -5px #000; */
  /* box-shadow: 0 2px 4px rgba(0, 0, 0, .12), 0 0 6px rgba(0, 0, 0, .04) */
}
.el-container {
  height: 136px;
  /* box-shadow: 2px 2px 6px -5px #000; */
  box-shadow: 0 2px 4px rgba(0, 0, 0, .12), 0 0 6px rgba(0, 0, 0, .04)
}
#note-img {
  width: 160px;
  height: 90px;
}
.font-title {
  font-size: 16px;
  font-weight: 600;
}
</style>
