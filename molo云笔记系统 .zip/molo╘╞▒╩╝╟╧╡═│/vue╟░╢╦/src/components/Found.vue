<template>
<!--  <div class="found-div">
  </div> -->
</template>

<script>
export default {
  name: "Found",
  data() {
    return {
    };
  },
  methods: {

  },
};
</script>

<style scoped>
.found-div {
  margin-top: 28px;
  padding-bottom: 12px;
  width: 256px;
  margin-left: -20px;
  background-color: white;
  box-shadow: 2px 2px 6px -5px #000;
  border-radius: 10px;
}

ul {
  margin: 0;
  padding: 0;
}

li {
  margin: 0;
  padding: 0;
  list-style: none; /*去掉li左侧的点*/
}
#goods-img {
  width: 60px;
}
.goods {
  border-top: 2px solid rgb(242, 243, 239);
  border-bottom: 2px solid rgb(242, 243, 239);
  margin-top: 4px;
  /* background-color: orange; */
}
#good-title {
  color: #d36008;
  font-weight: 600;
  display: inline-block;
  margin-left: 5%;
  margin-bottom: 2px;
  
}
.more {
  color: #349696;
  margin-left: 73px;
}
#img-good {
  width: 66px;
  height: 70px;
  margin-top: 5px;
}
</style>