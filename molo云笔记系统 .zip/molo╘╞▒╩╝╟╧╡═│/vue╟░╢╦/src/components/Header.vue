<template>
  <el-row class="head-nav">
    <el-col :span="3">
      <div>
        <router-link class="el-icon-notebook-1" id="nav-icon" to="/"
          >MOLO</router-link
        >
      </div>
    </el-col>
    <el-col :span="2">
      <div>
        <router-link active-class="actionRoute" to="/myEditor" style="color: #ff5500;"
          >写笔记</router-link
        >
      </div>
    </el-col>

    <el-col :span="2">
      <div>
        <router-link active-class="actionRoute" to="/my-notes"style="color: #ff5500;"
          >我的笔记</router-link
        >
      </div>
    </el-col>

    <el-col :span="2">
      <router-link active-class="actionRoute" to="/note-plaza"style="color: #ff5500;"
        >笔记广场</router-link
      >
    </el-col>
<!--   <el-col :span="5" :offset="3">
      <el-input
        placeholder="请输入内容并按回车~"
        prefix-icon="el-icon-search"
        v-model="inputSearch"
        @keyup.enter.native="queryNotes"
      >
      </el-input>
    </el-col> -->

    

    <!-- 导航栏右侧 -->
    <el-col :span="2" :offset="4" v-if="!isLogin" >
      <router-link to="/login">登录 | 注册</router-link>
    </el-col>
    <el-col :span="1" :offset="2">
      <!-- 名称 -->
      <div class="avatar" v-if="isLogin">
        {{user.userName}}
      </div>
    </el-col>
    <el-col :span="2" :offset="1" v-if="isLogin">
      <!-- 下拉菜单 -->
      <el-dropdown @command="handleCommand" trigger="click">
        <span class="el-dropdown-link">
          {{ user.nickname }}<i class="el-icon-arrow-down el-icon--right"></i>
        </span>
        <el-dropdown-menu slot="dropdown">
          <el-dropdown-item command="a">个人中心</el-dropdown-item>
          <el-dropdown-item command="e" divided>退出登录</el-dropdown-item>
        </el-dropdown-menu>
      </el-dropdown>
    </el-col>
  </el-row>
</template>

<script>
import pubsub from "pubsub-js";
export default {
  name: "Header",
  data() {
    return {
      isLogin: JSON.parse(localStorage.getItem("user01")).userId,
      user: JSON.parse(localStorage.getItem("user01")),
      inputSearch: "",
      noteList: [
        {
          noteId: "",
          title: "",
          notePicture: "",
          noteIntro: "",
          content: "",
          createTime: "",
          updateTime: "",
          noteState: "",
          readTotal: "",
        },
      ],
    };
  },
  methods: {
    handleCommand(command) {
      // 个人中心
      if (command === "a") {
        this.$router.push({
          path: "/personal",
        });
      }
      // 退出登录
      else if (command === "e") {
        localStorage.removeItem("user01");
		localStorage.removeItem("token");
		localStorage.removeItem("userTypeId");
        location.reload();
      }
      //售卖系统
      else if (command === "d") {
        this.$router.push(
          {
            path: "/publish-commodity",
          },
          () => {}
        );
      }
      // 我的订单
      else if (command === "c") {
        this.$router.push(
          {
            path: "/my-order",
          },
          () => {}
        );
      }
    },
    getNoteList() {
      this.$axios({
        method: "GET",
        url: "/notes/query-note",
        params: {
          query: this.inputSearch,
        },
      }).then((res) => {
        if (res.data.code == 10000) {
          this.noteList = res.data.data;
        } else {
          this.$message({
            showClose: true,
            message: "没有相关结果",
            type: "error",
          });
        }
      });
    },

    queryNotes() {
      this.getNoteList();
      let path = this.$route.path;
      pubsub.publish("notes", this.noteList);
      if (path != "/query-note") {
        this.$router.push(
          {
            name: "querynote",
          },
          () => {}
        );
      }
    },
  },
  mounted() {
    this.$bus.$on("isLogin", (data, us) => {
      this.isLogin = data;
      this.user.name = us.name;
    });
  },
};
</script>

<style scoped>
#nav-icon {
  color: #ff5100;
  font-size: 21px;
  font-weight: 600;
}
.avatar {
  display: inline-block;
  margin-top: 0px;
  margin-left: 90px;
}

#img-head {
  text-align: center;
  width: 31px;
  height: 31px;
}
</style>