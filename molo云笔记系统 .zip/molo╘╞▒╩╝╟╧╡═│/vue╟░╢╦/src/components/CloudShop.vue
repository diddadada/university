<template>
</template>

<script>
export default {
  name: "CloudShop",
  data() {
    return {
    };
  },
  methods: {

  },
};
</script>

<style scoped>
.shop {
  margin-top: 86px;
  padding-bottom: 12px;
  width: 256px;
  margin-left: -20px;
  background-color: white;
  box-shadow: 2px 2px 6px -5px #000;
  border-radius: 10px;
}
.found {
  height: 200px;
  background-color: aqua;
}
#goods-img {
  width: 60px;
}
.goods {
  border-top: 2px solid rgb(242, 243, 239);
  border-bottom: 2px solid rgb(242, 243, 239);
  margin-top: 4px;
  /* background-color: orange; */
}
#good-title {
  color: #349696;
  font-weight: 600;
  display: inline-block;
  margin-left: 5%;
  margin-bottom: 2px;
  margin-top: 4px;
}
.more {
  color: #349696;
  margin-left: 100px;
}
#img-good {
  width: 66px;
  height: 70px;
  margin-top: 5px;
}
</style>