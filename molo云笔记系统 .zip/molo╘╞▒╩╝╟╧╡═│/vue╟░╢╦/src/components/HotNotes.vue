<template>
  <div class="note-div">

  </div>
</template>

<script>
	import userApi from '../api/userApi.js'
export default {
  name: "HotNotes",
  data() {
    return {
      moloList1: [],
	  p:{"pageNum":1,"pageSize":4,"token":"24544ff4-5915-41b6-8fb3-513c4231dd1a1690183306063"}
    };
  },
  methods: {
    getNewNotes(p){
		userApi.getPublicMolo(p).then(resp=>{
		if(resp.data.code==200){
			this.moloList1=resp.data.data.records
			console.log(this.moloList)
		}else{
		}
		console.log(resp.data)
		})
    },
  },
  mounted() {
    this.getNewNotes(this.p)
  },
};
</script>

<style scoped>
.note-div {
  padding-top: 1px;
  background-color: white;
  border-radius: 10px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, .12), 0 0 6px rgba(0, 0, 0, .04)
}

#note-list {
  /* margin: 10px; */
  margin-top: 12px;
  margin-left: 30px;
  border-bottom: 2px solid rgb(242, 243, 239);
  margin-bottom: 6px;
}
#el-min {
  padding: 8px;
}

#note {
  margin-left: 20px;
  margin-top: 7px;
  border-top: 2px solid rgb(242, 243, 239);
  border-bottom: 2px solid rgb(242, 243, 239);
}
#host-note-div {
  margin-left: 12px;
}
.el-container {
  height: 136px;
  box-shadow: 0px 8px 10px -15px #000;
}
#note-img {
  width: 160px;
  height: 90px;
}
.font-title {
  font-size: 16px;
  font-weight: 600;
}
#host-note-div {
  margin-left: 9px;
  height: 319px;
  /* box-shadow: 2px 2px 6px -5px #000; */
  /* box-shadow: 0 2px 4px rgba(0, 0, 0, .12), 0 0 6px rgba(0, 0, 0, .04) */
}
</style>
