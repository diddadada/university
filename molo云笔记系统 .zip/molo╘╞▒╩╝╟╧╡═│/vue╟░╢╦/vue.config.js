const { defineConfig } = require('@vue/cli-service')
module.exports = defineConfig({
  transpileDependencies: true,
  lintOnSave:false //关闭语法检查  部署时记得先打开，然后改掉所以错误。
})
